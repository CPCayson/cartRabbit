import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { GoogleMap, useJsApiLoader, Marker } from '@react-google-maps/api';
import { FaMap, FaList, FaColumns, FaSortAmountDown, FaSortAmountUp } from 'react-icons/fa';

import CartList from './rides/CartList';
import CartDetails from './carts/CartDetails';
import Chat from './Chat';
import CarrotRating from './CarrotRating';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, collection, doc, getDoc, query, where, getDocs, addDoc, setDoc, updateDoc } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { getAuth } from 'firebase/auth';
import { getMessaging, getToken, onMessage } from 'firebase/messaging';
import { toast } from 'react-toastify';


const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
  authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
  databaseURL: process.env.REACT_APP_FIREBASE_DATABASE_URL,
  projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID,
  storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.REACT_APP_FIREBASE_APP_ID,
  measurementId: process.env.REACT_APP_FIREBASE_MEASUREMENT_ID
};

// Initialize Firebase only if it hasn't been initialized already
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// User Overview
export const getUserOverview = async (user) => {
  if (!user || !user.uid) {
    throw new Error('User is not authenticated');
  }

  const userDocRef = doc(db, 'users', user.uid);
  const userDoc = await getDoc(userDocRef);

  if (!userDoc.exists()) {
    throw new Error('User document does not exist');
  }

  const data = userDoc.data();
  return {
    walletBalance: data.walletBalance || 0,
    upcomingRides: data.upcomingRides || [],
    recentTransactions: data.recentTransactions || [],
  };
};

const messaging = getMessaging(app);

export const getFcmToken = async () => {
  try {
    const currentToken = await getToken(messaging, { vapidKey: process.env.REACT_APP_VAPID_KEY });
    if (currentToken) {
      console.log('FCM token:', currentToken);
      return currentToken;
    } else {
      console.log('No registration token available. Request permission to generate one.');
    }
  } catch (error) {
    console.error('An error occurred while retrieving token. ', error);
  }
};

onMessage(messaging, (payload) => {
  console.log('Message received. ', payload);
  toast.info(`${payload.notification.title}: ${payload.notification.body}`, {
    position: toast.POSITION.TOP_RIGHT,
    autoClose: 5000,
  });
});

// Ride Management
export const getCurrentRides = async (currentUser) => {
  if (!currentUser) return [];
  const userId = currentUser.uid;
  const ridesQuery = query(collection(db, 'rides'), where('hostId', '==', userId), where('status', '==', 'active'));
  const ridesSnapshot = await getDocs(ridesQuery);

  const rides = [];
  ridesSnapshot.forEach(doc => {
    rides.push({ id: doc.id, ...doc.data() });
  });
  return rides;
};

export const getPendingRequests = async (currentUser) => {
  if (!currentUser) return [];
  const userId = currentUser.uid;
  const requestsQuery = query(collection(db, 'bookings'), where('hostId', '==', userId), where('status', '==', 'pending'));
  const requestsSnapshot = await getDocs(requestsQuery);

  const requests = [];
  requestsSnapshot.forEach(doc => {
    requests.push({ id: doc.id, ...doc.data() });
  });
  return requests;
};

export const acceptRide = async (requestId) => {
  await updateDoc(doc(db, 'bookings', requestId), { status: 'accepted' });
};

export const rejectRide = async (requestId) => {
  await updateDoc(doc(db, 'bookings', requestId), { status: 'rejected' });
};

// Cart Management
export const getCartData = async (cartId) => {
  const cartDocRef = doc(db, 'carts', cartId);
  const cartDoc = await getDoc(cartDocRef);
  return cartDoc.exists() ? cartDoc.data() : {};
};

export const saveCartData = async (cartId, cartData) => {
  const cartDocRef = doc(db, 'carts', cartId);
  await setDoc(cartDocRef, cartData, { merge: true });
};

export const uploadImage = async (file) => {
  const storageRef = ref(storage, `cart-images/${file.name}`);
  await uploadBytes(storageRef, file);
  return await getDownloadURL(storageRef);
};

// Most Visited Places
export const getMostVisitedPlaces = async () => {
  const daySnapshot = await getDoc(doc(db, 'mostVisited', 'day'));
  const weekSnapshot = await getDoc(doc(db, 'mostVisited', 'week'));
  const timeSnapshot = await getDoc(doc(db, 'mostVisited', 'time'));
  return {
    day: daySnapshot.exists() ? daySnapshot.data().places : [],
    week: weekSnapshot.exists() ? weekSnapshot.data().places : [],
    time: timeSnapshot.exists() ? timeSnapshot.data().places : [],
  };
};

// Local Businesses
export const getLocalBusinesses = async () => {
  const businessesSnapshot = await getDocs(collection(db, 'localBusinesses'));
  const businesses = [];
  businessesSnapshot.forEach(doc => {
    businesses.push(doc.data());
  });
  return businesses;
};

// Host Overview
export const getHostOverview = async (currentUser) => {
  if (!currentUser) return { totalEarnings: 0, activeRides: 0, pendingRequests: 0 };
  const userId = currentUser.uid;
  const overviewData = await getDoc(doc(db, 'users', userId));
  return overviewData.exists() ? overviewData.data() : { totalEarnings: 0, activeRides: 0, pendingRequests: 0 };
};

// Current Rides for Host
export const getCurrentRidesHost = async (currentUser) => {
  if (!currentUser) return [];
  const userId = currentUser.uid;
  const ridesQuery = query(collection(db, 'rides'), where('hostId', '==', userId), where('status', '==', 'active'));
  const ridesSnapshot = await getDocs(ridesQuery);

  const rides = [];
  ridesSnapshot.forEach(doc => {
    rides.push({ id: doc.id, ...doc.data() });
  });
  return rides;
};

// Pending Ride Requests for Host
export const getPendingRequestsHost = async (currentUser) => {
  if (!currentUser) return [];
  const userId = currentUser.uid;
  const requestsQuery = query(collection(db, 'bookings'), where('hostId', '==', userId), where('status', '==', 'pending'));
  const requestsSnapshot = await getDocs(requestsQuery);

  const requests = [];
  requestsSnapshot.forEach(doc => {
    requests.push({ id: doc.id, ...doc.data() });
  });
  return requests;
};

// Ride Request Management for Host
export const acceptRideHost = async (requestId) => {
  await updateDoc(doc(db, 'bookings', requestId), { status: 'accepted' });
};

export const rejectRideHost = async (requestId) => {
  await updateDoc(doc(db, 'bookings', requestId), { status: 'rejected' });
};

// Carts Management
export const getCarts = async (currentUser) => {
  if (!currentUser) return [];
  const userId = currentUser.uid;
  const cartsQuery = query(collection(db, 'carts'), where('hostId', '==', userId));
  const cartsSnapshot = await getDocs(cartsQuery);

  const carts = [];
  cartsSnapshot.forEach(doc => {
    carts.push({ id: doc.id, ...doc.data() });
  });
  return carts;
};

export const updateCartStatus = async (cartId, status) => {
  await updateDoc(doc(db, 'carts', cartId), { status });
};

export const addOrUpdateCart = async (cart) => {
  if (cart.id) {
    await setDoc(doc(db, 'carts', cart.id), cart, { merge: true });
  } else {
    await addDoc(collection(db, 'carts'), cart);
  }
};

// Earnings Summary
export const getEarningsSummary = async (currentUser) => {
  if (!currentUser) return { daily: 0, weekly: 0, monthly: 0 };
  const userId = currentUser.uid;
  const earningsSnapshot = await getDoc(doc(db, 'earnings', userId));
  return earningsSnapshot.exists() ? earningsSnapshot.data() : { daily: 0, weekly: 0, monthly: 0 };
};

// Payout History
export const getPayoutHistory = async (currentUser) => {
  if (!currentUser) return [];
  const userId = currentUser.uid;
  const payoutsQuery = query(collection(db, 'payouts'), where('userId', '==', userId));
  const payoutsSnapshot = await getDocs(payoutsQuery);

  const payouts = [];
  payoutsSnapshot.forEach(doc => {
    payouts.push({ id: doc.id, ...doc.data() });
  });
  return payouts;
};

// Payout Requests
export const requestPayout = async (currentUser) => {
  if (!currentUser) return;
  const userId = currentUser.uid;
  await addDoc(collection(db, 'payoutRequests'), { userId, status: 'pending', createdAt: new Date() });
};

// Financial Reports
export const getFinancialReports = async (currentUser) => {
  if (!currentUser) return [];
  const userId = currentUser.uid;
  const reportsQuery = query(collection(db, 'financialReports'), where('userId', '==', userId));
  const reportsSnapshot = await getDocs(reportsQuery);

  const reports = [];
  reportsSnapshot.forEach(doc => {
    reports.push({ id: doc.id, ...doc.data() });
  });
  return reports;
};

// Profile Management
export const getProfile = async (currentUser) => {
  if (!currentUser) return {};
  const userId = currentUser.uid;
  const profileSnapshot = await getDoc(doc(db, 'users', userId));
  return profileSnapshot.exists() ? profileSnapshot.data() : {};
};

export const updateProfile = async (currentUser, profile) => {
  if (!currentUser) return;
  const userId = currentUser.uid;
  await setDoc(doc(db, 'users', userId), profile, { merge: true });
};

// Payment Methods
export const getPaymentMethods = async (currentUser) => {
  if (!currentUser) return [];
  const userId = currentUser.uid;
  const paymentMethodsQuery = query(collection(db, 'paymentMethods'), where('userId', '==', userId));
  const paymentMethodsSnapshot = await getDocs(paymentMethodsQuery);

  const paymentMethods = [];
  paymentMethodsSnapshot.forEach(doc => {
    paymentMethods.push({ id: doc.id, ...doc.data() });
  });
  return paymentMethods;
};

export const updatePaymentMethods = async (currentUser, methods) => {
  if (!currentUser) return;
  const userId = currentUser.uid;
  await setDoc(doc(db, 'paymentMethods', userId), { methods }, { merge: true });
};

// Notification Settings
export const getNotificationSettings = async (currentUser) => {
  if (!currentUser) return {};
  const userId = currentUser.uid;
  const notificationSettingsSnapshot = await getDoc(doc(db, 'notificationSettings', userId));
  return notificationSettingsSnapshot.exists() ? notificationSettingsSnapshot.data() : {};
};

export const updateNotificationSettings = async (currentUser, settings) => {
  if (!currentUser) return;
  const userId = currentUser.uid;
  await setDoc(doc(db, 'notificationSettings', userId), settings, { merge: true });
};

// Profile Data
export const getProfileData = async (profileType) => {
  const userId = auth.currentUser.uid;
  const profileDoc = await getDoc(doc(db, profileType === 'host' ? 'hosts' : 'users', userId));
  return profileDoc.exists() ? profileDoc.data() : {};
};

export const saveProfileData = async (profileType, data) => {
  const userId = auth.currentUser.uid;
  const profileDocRef = doc(db, profileType === 'host' ? 'hosts' : 'users', userId);
  const profileDoc = await getDoc(profileDocRef);

  if (profileDoc.exists()) {
    await updateDoc(profileDocRef, data);
  } else {
    await setDoc(profileDocRef, data);
  }
};

// Ride Status
export const getRideStatus = async (rideId) => {
  const rideDoc = await getDoc(doc(db, 'rides', rideId));
  return rideDoc.exists() ? rideDoc.data() : {};
};

// Ride Requests
export const getRideRequests = async () => {
  const rideRequestsSnapshot = await getDocs(collection(db, 'rideRequests'));
  const rideRequests = [];
  rideRequestsSnapshot.forEach(doc => {
    rideRequests.push({ id: doc.id, ...doc.data() });
  });
  return rideRequests;
};

export const confirmRide = async (rideId) => {
  const rideDoc = doc(db, 'rideRequests', rideId);
  await updateDoc(rideDoc, { status: 'confirmed' });
};

export {
  auth,
  db,
  storage,
};


const CartView = () => {
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: "YOUR_GOOGLE_MAPS_API_KEY",
    libraries: ['places']
  });

  const [viewMode, setViewMode] = useState('split');
  const [selectedCart, setSelectedCart] = useState(null);
  const [carts, setCarts] = useState([]);
  const [filters, setFilters] = useState({
    electric: false,
    ac: false,
    radio: false,
    storage: false
  });
  const [sortBy, setSortBy] = useState('distance');
  const [sortDirection, setSortDirection] = useState('asc');

  useEffect(() => {
    // Fetch carts data
    // This is a placeholder. Replace with actual API call.
    const fakeCarts = [
      {
        id: 1,
        cartName: "Speedy",
        cartModel: "ElectroCart 2000",
        capacity: 4,
        licensePlate: "EC2000",
        description: "Fast and eco-friendly",
        features: { electric: true, ac: true, radio: true, storage: false },
        distance: 2.5,
        time: 0.1,
        position: { lat: 30.3085, lng: -89.3304 }
      },
      // Add more fake carts as needed
    ];
    setCarts(fakeCarts);
  }, []);

  const filteredCarts = useMemo(() => {
    return carts.filter(cart => {
      return Object.entries(filters).every(([key, value]) => {
        return !value || cart.features[key];
      });
    });
  }, [carts, filters]);

  const sortedCarts = useMemo(() => {
    return [...filteredCarts].sort((a, b) => {
      if (sortDirection === 'asc') {
        return a[sortBy] - b[sortBy];
      } else {
        return b[sortBy] - a[sortBy];
      }
    });
  }, [filteredCarts, sortBy, sortDirection]);

  const toggleFilter = (filterName) => {
    setFilters(prev => ({ ...prev, [filterName]: !prev[filterName] }));
  };

  const toggleSort = (sortKey) => {
    if (sortBy === sortKey) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(sortKey);
      setSortDirection('asc');
    }
  };

  const handleCartClick = (cart) => {
    setSelectedCart(cart);
    setViewMode('split');
  };

  return (
    <div className="h-screen flex flex-col">
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <CarrotRating />
    </div>
      <header className="bg-gray-800 text-white p-4">
        <h1 className="text-2xl font-bold">Golf Cart Ride-Share</h1>
        <div className="flex justify-between mt-2">
          <div>
            {/* Filter buttons */}
            <button onClick={() => toggleFilter('electric')} className="mr-2">Electric</button>
            <button onClick={() => toggleFilter('ac')} className="mr-2">AC</button>
            <button onClick={() => toggleFilter('radio')} className="mr-2">Radio</button>
            <button onClick={() => toggleFilter('storage')}>Storage</button>
          </div>
          <div>
            {/* Sort buttons */}
            <button onClick={() => toggleSort('distance')} className="mr-2">
              Distance {sortBy === 'distance' && (sortDirection === 'asc' ? <FaSortAmountUp /> : <FaSortAmountDown />)}
            </button>
            <button onClick={() => toggleSort('time')}>
              Time {sortBy === 'time' && (sortDirection === 'asc' ? <FaSortAmountUp /> : <FaSortAmountDown />)}
            </button>
          </div>
        </div>
      </header>

      <div className="flex-grow flex">
        {viewMode !== 'map' && (
          <div className={`${viewMode === 'split' ? 'w-1/2' : 'w-full'} overflow-y-auto`}>
            {selectedCart ? (
              <CartDetails cart={selectedCart} />
            ) : (
              <CartList carts={sortedCarts} onCartClick={handleCartClick} />
            )}
          </div>
        )}
        {viewMode !== 'list' && (
          <div className={`${viewMode === 'split' ? 'w-1/2' : 'w-full'}`}>
            {isLoaded ? (
              <GoogleMap
                mapContainerStyle={{ width: '100%', height: '100%' }}
                center={{ lat: 30.3085, lng: -89.3304 }}
                zoom={14}
              >
                {sortedCarts.map(cart => (
                  <Marker
                    key={cart.id}
                    position={cart.position}
                    onClick={() => handleCartClick(cart)}
                  />
                ))}
              </GoogleMap>
            ) : (
              <div>Loading map...</div>
            )}
          </div>
        )}
      </div>

      {selectedCart && (
        <div className="fixed bottom-0 right-0 w-1/4 h-1/2 bg-white shadow-lg">
          <Chat cartId={selectedCart.id} />
        </div>
      )}

      <div className="fixed bottom-4 left-4">
        <button onClick={() => setViewMode('map')} className="mr-2">Map</button>
        <button onClick={() => setViewMode('list')} className="mr-2">List</button>
        <button onClick={() => setViewMode('split')}>Split</button>
      </div>
    </div>
  );
};

export default App1;