//npm install fs-extra replace-in-file chokidar
//node updateImports.js


const replace = require('replace-in-file');
const path = require('path');
const fs = require('fs');

const srcDir = path.join(__dirname, 'src');

// Function to get all JavaScript files in a directory recursively
const getAllFiles = (dir, ext, files = []) => {
  fs.readdirSync(dir).forEach(file => {
    const filePath = path.join(dir, file);
    if (fs.statSync(filePath).isDirectory()) {
      files = getAllFiles(filePath, ext, files);
    } else if (filePath.endsWith(ext)) {
      files.push(filePath);
    }
  });
  return files;
};

// Get all JavaScript files in the src directory
const jsFiles = getAllFiles(srcDir, '.js');

// Function to update imports in a single file
const updateImportsInFile = async (file) => {
  const options = {
    files: file,
    from: /import\s+['"]\.\.\/styles\//g,
    to: 'import \'styles/',
  };

  try {
    const results = await replace(options);
    console.log(`Updated imports in: ${results.filter(r => r.hasChanged).map(r => r.file).join(', ')}`);
  } catch (error) {
    console.error('Error occurred:', error);
  }
};

// Update imports in all JavaScript files
jsFiles.forEach(updateImportsInFile);
