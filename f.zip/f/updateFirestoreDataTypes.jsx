const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json'); // Path to your service account key

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://rabbit-2ba47-default-rtdb.firebaseio.com"
});

const db = admin.firestore();

const updateDataTypes = async () => {
  const usersRef = db.collection('users');
  const cartsRef = db.collection('carts');
  const chatMessagesRef = db.collection('chat_messages');
  const chatsRef = db.collection('chats');
  const notificationsRef = db.collection('notifications');
  const recentDestinationsRef = db.collection('recentDestinations');
  const ridesRef = db.collection('rides');

  // Helper function to update timestamps
  const updateTimestamp = (timestamp) => {
    return !(timestamp instanceof admin.firestore.Timestamp) ? admin.firestore.Timestamp.fromDate(new Date(timestamp)) : timestamp;
  };

  // Update Users Collection
  const updateUsers = async () => {
    const snapshot = await usersRef.get();
    snapshot.forEach(async (doc) => {
      const data = doc.data();

      if (data.age && typeof data.age === 'string') {
        data.age = parseInt(data.age, 10);
      }

      if (data.walletBalance && typeof data.walletBalance === 'string') {
        data.walletBalance = parseFloat(data.walletBalance);
      }

      if (data.createdAt) {
        data.createdAt = updateTimestamp(data.createdAt);
      }

      if (data.updatedAt) {
        data.updatedAt = updateTimestamp(data.updatedAt);
      }

      if (data.carts && Array.isArray(data.carts)) {
        data.carts = data.carts.map(cart => {
          if (cart.bookings && Array.isArray(cart.bookings)) {
            cart.bookings = cart.bookings.map(booking => {
              booking.startTime = updateTimestamp(booking.startTime);
              booking.endTime = updateTimestamp(booking.endTime);
              return booking;
            });
          }
          return cart;
        });
      }

      await usersRef.doc(doc.id).set(data, { merge: true });
    });
  };

  // Update Carts Collection
  const updateCarts = async () => {
    const snapshot = await cartsRef.get();
    snapshot.forEach(async (doc) => {
      const data = doc.data();

      if (data.createdAt) {
        data.createdAt = updateTimestamp(data.createdAt);
      }

      await cartsRef.doc(doc.id).set(data, { merge: true });
    });
  };

  // Update Chat Messages Collection
  const updateChatMessages = async () => {
    const snapshot = await chatMessagesRef.get();
    snapshot.forEach(async (doc) => {
      const data = doc.data();

      if (data.last_message_time) {
        data.last_message_time = updateTimestamp(data.last_message_time);
      }

      await chatMessagesRef.doc(doc.id).set(data, { merge: true });
    });
  };

  // Update Chats Collection
  const updateChats = async () => {
    const snapshot = await chatsRef.get();
    snapshot.forEach(async (doc) => {
      const data = doc.data();

      if (data.last_message_time) {
        data.last_message_time = updateTimestamp(data.last_message_time);
      }

      await chatsRef.doc(doc.id).set(data, { merge: true });
    });
  };

  // Update Notifications Collection
  const updateNotifications = async () => {
    const snapshot = await notificationsRef.get();
    snapshot.forEach(async (doc) => {
      const data = doc.data();

      if (data.createdAt) {
        data.createdAt = updateTimestamp(data.createdAt);
      }

      await notificationsRef.doc(doc.id).set(data, { merge: true });
    });
  };

  // Update Recent Destinations Collection
  const updateRecentDestinations = async () => {
    const snapshot = await recentDestinationsRef.get();
    snapshot.forEach(async (doc) => {
      const data = doc.data();

      if (data.location && !(data.location instanceof admin.firestore.GeoPoint)) {
        const [lat, lng] = data.location;
        data.location = new admin.firestore.GeoPoint(lat, lng);
      }

      await recentDestinationsRef.doc(doc.id).set(data, { merge: true });
    });
  };

  // Update Rides Collection
  const updateRides = async () => {
    const snapshot = await ridesRef.get();
    snapshot.forEach(async (doc) => {
      const data = doc.data();

      if (data.location && !(data.location instanceof admin.firestore.GeoPoint)) {
        const [lat, lng] = data.location;
        data.location = new admin.firestore.GeoPoint(lat, lng);
      }

      await ridesRef.doc(doc.id).set(data, { merge: true });
    });
  };

  await updateUsers();
  await updateCarts();
  await updateChatMessages();
  await updateChats();
  await updateNotifications();
  await updateRecentDestinations();
  await updateRides();

  console.log('Data types updated successfully.');
};

updateDataTypes().catch(console.error);
