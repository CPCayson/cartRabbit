// SetupPayment.js
import React from 'react';
import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

const SetupPayment = () => {
  const stripe = useStripe();
  const elements = useElements();

  const handleSubmit = async (event) => {
    event.preventDefault();

    const cardElement = elements.getElement(CardElement);

    const { setupIntent, error } = await stripe.confirmCardSetup(
      'your-setup-intent-client-secret',
      {
        payment_method: {
          card: cardElement,
        },
      }
    );

    if (error) {
      console.error(error);
    } else {
      console.log('SetupIntent:', setupIntent);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <CardElement />
      <button type="submit" disabled={!stripe}>Save Payment Method</button>
    </form>
  );
};

export default SetupPayment;
