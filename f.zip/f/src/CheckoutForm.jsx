import React, { useState, useEffect } from 'react';
import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

const CheckoutForm = ({ amount, onSuccess }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [errorMessage, setErrorMessage] = useState(null);
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const storedEmail = localStorage.getItem('userEmail');
    const storedPhone = localStorage.getItem('userPhone');
    if (storedEmail) setEmail(storedEmail);
    if (storedPhone) setPhone(storedPhone);
  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!stripe || !elements) {
      return;
    }

    setLoading(true);
    setErrorMessage(null);

    try {
      const response = await fetch('/create-payment-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('idToken')}` // Assuming you store the idToken in localStorage
        },
        body: JSON.stringify({
          amount: Math.round(amount * 100), // Convert to cents
          email,
          phone
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create payment intent');
      }

      const { clientSecret } = await response.json();

      const result = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement),
          billing_details: { email, phone }
        }
      });

      if (result.error) {
        setErrorMessage(result.error.message);
      } else if (result.paymentIntent.status === 'succeeded') {
        onSuccess();
      }
    } catch (error) {
      console.error('Error:', error);
      setErrorMessage(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4" aria-label="Checkout Form">
      <input
        type="email"
        value={email}
        onChange={(e) => {
          setEmail(e.target.value);
          localStorage.setItem('userEmail', e.target.value);
        }}
        placeholder="Email"
        className="w-full p-2 border border-gray-300 rounded"
        required
        aria-label="Email"
      />
      <input
        type="tel"
        value={phone}
        onChange={(e) => {
          setPhone(e.target.value);
          localStorage.setItem('userPhone', e.target.value);
        }}
        placeholder="Phone"
        className="w-full p-2 border border-gray-300 rounded"
        required
        aria-label="Phone"
      />
      <div className="p-4 bg-blue-600 rounded">
        <CardElement
          options={{
            style: {
              base: {
                fontSize: '16px',
                color: '#ffffff',
                '::placeholder': {
                  color: '#aab7c4',
                },
              },
              invalid: {
                color: '#9e2146',
              },
            },
          }}
        />
      </div>
      <button
        type="submit"
        disabled={!stripe || loading}
        className={`w-full p-2 rounded text-white ${loading ? 'bg-gray-400' : 'bg-blue-500 hover:bg-blue-600 transition duration-200'}`}
        aria-label="Pay Now"
      >
        {loading ? 'Processing...' : `Pay $${amount.toFixed(2)}`}
      </button>
      {errorMessage && <div className="text-red-500" aria-live="polite">{errorMessage}</div>}
    </form>
  );
};

export default CheckoutForm;
