import { getFcmToken } from './firebase';
import { doc, setDoc } from 'firebase/firestore';
import { getFirestore } from 'firebase/firestore';

const db = getFirestore();

const saveFcmToken = async (userId) => {
  const fcmToken = await getFcmToken();
  await setDoc(doc(db, 'users', userId), {
    fcmToken,
  }, { merge: true });
};

export default saveFcmToken;