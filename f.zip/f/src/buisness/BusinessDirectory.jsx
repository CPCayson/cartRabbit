import React, { useState } from 'react';
import '../styles/BusinessDirectory.scss';

const businesses = [
  // Your businesses data
];

const BusinessDirectory = ({ showMap, setShowMap }) => {
  const [filteredBusinesses, setFilteredBusinesses] = useState(businesses);

  const filterBy = (type) => {
    if (type === 'all') {
      setFilteredBusinesses(businesses);
    } else {
      setFilteredBusinesses(businesses.filter(business => business.type === type));
    }
  };

  const sortBy = (criteria) => {
    let sorted = [...filteredBusinesses];
    switch(criteria) {
      case 'name':
        sorted.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'rating':
        sorted.sort((a, b) => b.rating - a.rating);
        break;
      case 'type':
        sorted.sort((a, b) => a.type.localeCompare(b.type));
        break;
      default:
        break;
    }
    setFilteredBusinesses(sorted);
  };

  const BusinessTile = ({ business }) => (
    <div className="tile" data-type={business.type}>
      <h2>{business.name}</h2>
      <p>{business.type}</p>
      <p className="rating">★ {business.rating.toFixed(1)}</p>
      <p>{business.description}</p>
      <p>{business.address}</p>
      <p>{business.phone}</p>
    </div>
  );

  return (
    <div className={`business-directory ${showMap ? '' : 'show'}`}>
      <h1>Bay Saint Louis Business Directory</h1>
      <div className="filters">
        <button onClick={() => filterBy('all')}>All</button>
        <button onClick={() => filterBy('Restaurant')}>Restaurants</button>
        <button onClick={() => filterBy('Gift Shop')}>Gift Shops</button>
        <button onClick={() => filterBy('Hotel')}>Hotels</button>
        <button onClick={() => filterBy('Boutique')}>Boutiques</button>
      </div>
      <div className="sort">
        <button onClick={() => sortBy('name')}>Sort by Name</button>
        <button onClick={() => sortBy('rating')}>Sort by Rating</button>
        <button onClick={() => sortBy('type')}>Sort by Type</button>
      </div>
      <div className="grid">
        {filteredBusinesses.map((business, index) => (
          <BusinessTile key={index} business={business} />
        ))}
      </div>
      <button className="back-to-map" onClick={() => setShowMap(true)}>Back to Map</button>
    </div>
  );
};

export default BusinessDirectory;
