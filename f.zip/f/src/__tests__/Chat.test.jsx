import React from 'react';
import { render, screen } from '@testing-library/react';
import Chat from '../components/Chat';
import { AuthContext } from '../Authentication/AuthProvider';

test('renders Chat component', () => {
  const userId = 'user1';
  const hostId = 'host1';

  render(
    <AuthContext.Provider value={{ currentUser: { uid: userId } }}>
      <Chat userId={userId} hostId={hostId} />
    </AuthContext.Provider>
  );

  expect(screen.getByText('Mad Tea Party Chat')).toBeInTheDocument();
});
