import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import CartDetails from './CartDetails';

const mockCart = {
  cartName: 'Test Cart',
  cartModel: 'Model X',
  licensePlate: 'ABC1234',
  capacity: 4,
  time: 2,
  distance: 10,
  description: 'A test cart description.',
  features: {
    electric: true,
    ac: false,
    radio: true,
    storage: false,
  },
  position: {
    lat: 34.0522,
    lng: -118.2437,
  },
};

test('renders CartDetails component', () => {
  const { getByText } = render(<CartDetails cart={mockCart} />);
  expect(screen.getByText(/Test Cart/i)).toBeInTheDocument();
  expect(screen.getByText(/Model: Model X/i)).toBeInTheDocument();
  expect(screen.getByText(/License Plate: ABC1234/i)).toBeInTheDocument();
  expect(screen.getByText(/Capacity: 4 persons/i)).toBeInTheDocument();
  expect(screen.getByText(/Estimated Time: 120 mins/i)).toBeInTheDocument();
  expect(screen.getByText(/Distance: 10.00 km/i)).toBeInTheDocument();
  expect(screen.getByText(/A test cart description./i)).toBeInTheDocument();
});
