import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import axios from 'axios';
import UserProfile from './UserProfile';
import { getProfileData, saveProfileData } from '../../Firebase/firebase';

jest.mock('axios');
jest.mock('../../Firebase/firebase');

const profileData = {
  name: 'John Doe',
  birthdate: '1/1/1990',
  email: 'john@example.com',
  bio: 'Lorem ipsum dolor sit amet.',
  photo: null,
  stripeAccountId: '',
};

describe('UserProfile Component', () => {
  beforeEach(() => {
    getProfileData.mockResolvedValue(profileData);
  });

  it('fetches and displays profile data', async () => {
    render(<UserProfile profileType="user" />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();

    expect(await screen.findByText('Edit Profile')).toBeInTheDocument();
    expect(await screen.findByDisplayValue('John Doe')).toBeInTheDocument();
    expect(await screen.findByDisplayValue('1/1/1990')).toBeInTheDocument();
    expect(await screen.findByDisplayValue('john@example.com')).toBeInTheDocument();
    expect(await screen.findByDisplayValue('Lorem ipsum dolor sit amet.')).toBeInTheDocument();
  });

  it('displays error message if profile data fetch fails', async () => {
    getProfileData.mockRejectedValueOnce(new Error('Failed to fetch profile data'));
    render(<UserProfile profileType="user" />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();

    expect(await screen.findByText('Error fetching profile data: Failed to fetch profile data')).toBeInTheDocument();
  });

  it('validates and displays error messages for invalid inputs', async () => {
    render(<UserProfile profileType="user" />);
    expect(await screen.findByText('Edit Profile')).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'invalidemail' } });
    fireEvent.change(screen.getByLabelText('Birthdate'), { target: { value: '' } });
    fireEvent.click(screen.getByText('Save Changes'));

    expect(await screen.findByText('Invalid email address')).toBeInTheDocument();
    expect(await screen.findByText('Birthdate cannot be empty')).toBeInTheDocument();
  });

  it('submits form and displays success message', async () => {
    saveProfileData.mockResolvedValueOnce({});
    axios.post.mockResolvedValueOnce({ data: { id: 'stripe_account_id' } });
    render(<UserProfile profileType="user" />);
    expect(await screen.findByText('Edit Profile')).toBeInTheDocument();

    fireEvent.click(screen.getByText('Save Changes'));

    expect(await screen.findByText('Profile updated successfully')).toBeInTheDocument();
  });

  it('displays error message if form submission fails', async () => {
    saveProfileData.mockRejectedValueOnce(new Error('Failed to update profile'));
    render(<UserProfile profileType="user" />);
    expect(await screen.findByText('Edit Profile')).toBeInTheDocument();

    fireEvent.click(screen.getByText('Save Changes'));

    expect(await screen.findByText('Error updating profile: Failed to update profile')).toBeInTheDocument();
  });
});
