import React from 'react';
import { render, screen } from '@testing-library/react';
import HostDashboard from '../components/HostDashboard';
import { AuthContext } from '../Authentication/AuthProvider';

test('renders HostDashboard', () => {
  const user = { uid: '123', email: 'test@example.com' };
  const profile = { name: 'Test Host' };

  render(
    <AuthContext.Provider value={{ currentUser: user }}>
      <HostDashboard user={user} profile={profile} />
    </AuthContext.Provider>
  );

  expect(screen.getByText('Host Dashboard')).toBeInTheDocument();
  expect(screen.getByText('Profile Settings')).toBeInTheDocument();
  expect(screen.getByText('Cart Management')).toBeInTheDocument();
  expect(screen.getByText('Ride Requests')).toBeInTheDocument();
});
