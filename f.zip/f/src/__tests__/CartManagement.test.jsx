import React from 'react';
import { render, screen } from '@testing-library/react';
import CartManagement from '../components/CartManagement';
import { AuthContext } from '../Authentication/AuthProvider';

test('renders CartManagement', () => {
  const user = { uid: '123', email: 'test@example.com' };

  render(
    <AuthContext.Provider value={{ currentUser: user }}>
      <CartManagement user={user} />
    </AuthContext.Provider>
  );

  expect(screen.getByText('Manage Your Carts')).toBeInTheDocument();
});
