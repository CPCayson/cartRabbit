
Checklist of Functionalities and Tasks
Functionalities Implemented
Data Fetching:

Fetch user profile data from the backend (Firebase) using getProfileData.
Populate the form fields with the fetched data.
Profile Photo:

Display the user's profile photo or a default image if none is provided.
Allow the user to upload a new profile photo.
Resize the uploaded photo before saving using Pica.
Form Inputs:

Provide input fields for the user's name, age, email, and bio.
Ensure the inputs are pre-filled with existing data from the user's profile.
Form Validation:

Validate email format and age input.
Display error messages for invalid inputs.
Form Submission:

Save the updated profile data to the backend (Firebase) using saveProfileData.
Create a Stripe connected account if the user does not have one, using an Axios POST request.
User Feedback:

Display a loading state while fetching and saving data.
Show success or error messages after form submission using react-toastify and sweetalert2.
Popup Form:

Use SweetAlert2 to create an edit profile popup.
Include form fields and photo upload functionality within the popup.
Tasks Completed
 Set up state management for user data and loading state using useState.
 Fetch profile data on component mount using useEffect.
 Implement handleInputChange to manage form input changes.
 Implement handlePhotoChange and resizeImage to handle photo uploads and resizing.
 Add form validation for email and age inputs.
 Implement handleSubmit to save profile data and create a Stripe account if needed.
 Display loading state and error/success messages using react-toastify.
 Create a SweetAlert2 popup for editing the profile with form inputs and photo upload.
 Style the component using Tailwind CSS classes and custom styles.
Tasks to be Done
Styling:

Ensure the CSS styles match the provided design, especially for the profile popup.
Adjust styles for responsiveness and different screen sizes.
Error Handling:

Add more detailed error handling for Axios POST request to create a Stripe account.
Ensure that errors are properly displayed to the user if profile data fetch or save fails.
Testing:

Test the component for various scenarios like empty fields, invalid inputs, and large photo uploads.
Ensure the form validation works correctly.
Test the component's responsiveness on different devices.
Accessibility:

Ensure the component is accessible to users with disabilities (e.g., using proper labels and aria attributes).
Security:

Validate and sanitize inputs to prevent security vulnerabilities like XSS.
Ensure secure handling of user data, especially when uploading and processing photos.
Cancel Button:

Implement functionality to cancel the form editing and revert any changes if needed.
Optimization:

Optimize image resizing for performance.
Ensure the form submission is efficient and only sends necessary data.
Code Review:

Conduct a code review to ensure the code is clean, readable, and follows best practices