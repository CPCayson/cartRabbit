import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import CartDetails from './CartDetails';
import CartStats from './CartStats';
import { useAuth } from '../Authentication/AuthProvider';
import { getFirestore, doc, getDoc } from 'firebase/firestore';

jest.mock('../Authentication/AuthProvider');
jest.mock('firebase/firestore');

const mockCart = {
  cartName: 'Test Cart',
  cartModel: 'Model X',
  licensePlate: 'ABC1234',
  capacity: 4,
  time: 2,
  distance: 10,
  description: 'A test cart description.',
  features: {
    electric: true,
    ac: false,
    radio: true,
    storage: false,
  },
  position: {
    lat: 34.0522,
    lng: -118.2437,
  },
};

const mockStats = {
  totalRides: 100,
  totalEarnings: 5000,
  averageRating: 4.5,
};

beforeEach(() => {
  useAuth.mockReturnValue({ currentUser: { uid: 'testuser' } });
  getFirestore.mockReturnValue({});
  getDoc.mockResolvedValue({
    exists: () => true,
    data: () => mockStats,
  });
});

test('renders CartDetails and CartStats components together', async () => {
  render(
    <div>
      <CartDetails cart={mockCart} />
      <CartStats cartId="testcartid" />
    </div>
  );

  // Assert CartDetails
  expect(screen.getByText(/Test Cart/i)).toBeInTheDocument();
  expect(screen.getByText(/Model: Model X/i)).toBeInTheDocument();
  expect(screen.getByText(/License Plate: ABC1234/i)).toBeInTheDocument();
  expect(screen.getByText(/Capacity: 4 persons/i)).toBeInTheDocument();
  expect(screen.getByText(/Estimated Time: 120 mins/i)).toBeInTheDocument();
  expect(screen.getByText(/Distance: 10.00 km/i)).toBeInTheDocument();
  expect(screen.getByText(/A test cart description./i)).toBeInTheDocument();

  // Assert CartStats
  await waitFor(() => {
    expect(screen.getByText(/Total Rides:/i)).toBeInTheDocument();
    expect(screen.getByText(/100/i)).toBeInTheDocument();
    expect(screen.getByText(/Total Earnings:/i)).toBeInTheDocument();
    expect(screen.getByText(/\$5000/i)).toBeInTheDocument();
    expect(screen.getByText(/Average Rating:/i)).toBeInTheDocument();
    expect(screen.getByText(/4.5/i)).toBeInTheDocument();
  });
});
