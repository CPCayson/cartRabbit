import React from 'react';
import { render, screen } from '@testing-library/react';
import RideRequests from '../components/RideRequests';
import { AuthContext } from '../Authentication/AuthProvider';

test('renders RideRequests', () => {
  const user = { uid: '123', email: 'test@example.com' };

  render(
    <AuthContext.Provider value={{ currentUser: user }}>
      <RideRequests user={user} />
    </AuthContext.Provider>
  );

  expect(screen.getByText('Ride Requests')).toBeInTheDocument();
});
