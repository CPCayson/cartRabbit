import React from 'react';

const FeatureIcon = ({ feature, icon, label }) => (
  <div className={`flex items-center ${feature ? 'text-green-500' : 'text-gray-400'}`}>
    {icon}
    <span className="ml-2">{label}</span>
  </div>
);

export default FeatureIcon;
