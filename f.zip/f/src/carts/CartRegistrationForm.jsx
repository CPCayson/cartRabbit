import React, { useState } from 'react';
import { getFirestore, collection, addDoc } from 'firebase/firestore';
import { useAuth } from '../Authentication/AuthProvider';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../styles/CartRegistrationForm.css';

const CartRegistrationForm = () => {
  const [cartData, setCartData] = useState({
    cartName: '',
    cartModel: '',
    licensePlate: '',
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const db = getFirestore();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCartData(prevCartData => ({ ...prevCartData, [name]: value }));
    clearError(name);
  };

  const clearError = (name) => {
    setErrors(prevErrors => ({ ...prevErrors, [name]: '' }));
  };

  const validateField = (name, value) => {
    let error = '';
    if (name === 'cartName' && value.trim() === '') {
      error = 'Cart Name is required';
    } else if (name === 'licensePlate' && !/^[A-Z0-9-]{1,7}$/.test(value)) {
      error = 'License Plate must be alphanumeric and up to 7 characters';
    }
    setErrors(prevErrors => ({ ...prevErrors, [name]: error }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (cartData.cartName.trim() === '') {
      newErrors.cartName = 'Cart Name is required';
    }
    if (!/^[A-Z0-9-]{1,7}$/.test(cartData.licensePlate)) {
      newErrors.licensePlate = 'License Plate must be alphanumeric and up to 7 characters';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) {
      toast.error('Please fix the errors in the form');
      return;
    }
    setLoading(true);
    try {
      await addDoc(collection(db, 'carts'), {
        ...cartData,
        ownerId: user.uid,
      });
      toast.success('Cart registered successfully');
      setCartData({ cartName: '', cartModel: '', licensePlate: '' });
    } catch (error) {
      toast.error('Error registering cart: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="cart-registration-form max-w-md mx-auto mt-10 p-6 bg-white rounded-lg shadow-md">
      <ToastContainer />
      <h2 className="text-2xl font-bold text-center mb-4">Register Your Cart</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="form-group">
          <label htmlFor="cartName" className="block text-sm font-semibold mb-1">Cart Name</label>
          <input
            type="text"
            id="cartName"
            name="cartName"
            value={cartData.cartName}
            onChange={handleChange}
            required
            className="w-full p-2 border border-gray-300 rounded-md"
          />
          {errors.cartName && <span className="error-text text-red-500 text-xs" aria-live="polite">{errors.cartName}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="cartModel" className="block text-sm font-semibold mb-1">Cart Model</label>
          <input
            type="text"
            id="cartModel"
            name="cartModel"
            value={cartData.cartModel}
            onChange={handleChange}
            required
            className="w-full p-2 border border-gray-300 rounded-md"
          />
        </div>
        <div className="form-group">
          <label htmlFor="licensePlate" className="block text-sm font-semibold mb-1">License Plate</label>
          <input
            type="text"
            id="licensePlate"
            name="licensePlate"
            value={cartData.licensePlate}
            onChange={handleChange}
            required
            className="w-full p-2 border border-gray-300 rounded-md"
          />
          {errors.licensePlate && <span className="error-text text-red-500 text-xs" aria-live="polite">{errors.licensePlate}</span>}
        </div>
        <button
          type="submit"
          className="w-full p-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition"
          disabled={loading}
        >
          {loading ? 'Registering...' : 'Register Cart'}
        </button>
      </form>
    </div>
  );
};

export default CartRegistrationForm;
