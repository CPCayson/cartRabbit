import React, { useState, useEffect } from 'react';
import { getFirestore, doc, getDoc } from 'firebase/firestore';
import { useAuth } from '../Authentication/AuthProvider';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const CartStats = ({ cartId }) => {
  const [stats, setStats] = useState({
    totalRides: 0,
    totalEarnings: 0,
    averageRating: 0,
  });
  const [loading, setLoading] = useState(false);
  const db = getFirestore();
  const { currentUser } = useAuth();

  useEffect(() => {
    const fetchStats = async () => {
      setLoading(true);
      try {
        const statsDoc = await getDoc(doc(db, 'cartStats', cartId));
        if (statsDoc.exists()) {
          setStats(statsDoc.data());
        } else {
          console.log('No such document!');
        }
      } catch (error) {
        console.error('Error fetching cart stats:', error);
        toast.error('Error fetching cart stats');
      } finally {
        setLoading(false);
      }
    };

    if (cartId) {
      fetchStats();
    }
  }, [cartId, db]);

  if (loading) {
    return <div className="text-center">Loading...</div>;
  }

  return (
    <div className="p-4 border border-gray-300 rounded-lg bg-white shadow-md mb-4">
      <ToastContainer />
      <h2 className="text-2xl font-bold mb-4">Cart Stats</h2>
      <div className="flex flex-col md:flex-row justify-around items-center">
        <div className="text-center mb-4 md:mb-0">
          <p className="font-bold">Total Rides:</p>
          <p className="text-lg">{stats.totalRides}</p>
        </div>
        <div className="text-center mb-4 md:mb-0">
          <p className="font-bold">Total Earnings:</p>
          <p className="text-lg">${stats.totalEarnings}</p>
        </div>
        <div className="text-center">
          <p className="font-bold">Average Rating:</p>
          <p className="text-lg">{stats.averageRating}</p>
        </div>
      </div>
    </div>
  );
};

export default CartStats;
