import React, { useState } from 'react';
import { getFirestore, collection, addDoc } from 'firebase/firestore';
import { useAuth } from '../../Authentication/AuthProvider';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../styles/CartRegistrationForm.css';

const CartRegistrationForm = () => {
  const [cartData, setCartData] = useState({
    cartName: '',
    cartModel: '',
    licensePlate: '',
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const db = getFirestore();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCartData(prevCartData => ({ ...prevCartData, [name]: value }));
    validateField(name, value);
  };

  const validateField = (name, value) => {
    let error = '';
    if (name === 'cartName' && value.trim() === '') {
      error = 'Cart Name is required';
    }
    if (name === 'licensePlate' && !/^[A-Z0-9-]{1,7}$/.test(value)) {
      error = 'License Plate must be alphanumeric and up to 7 characters';
    }
    setErrors(prevErrors => ({ ...prevErrors, [name]: error }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (Object.values(errors).some(error => error)) {
      toast.error('Please fix the errors in the form');
      return;
    }
    setLoading(true);
    try {
      await addDoc(collection(db, 'carts'), {
        ...cartData,
        ownerId: user.uid,
      });
      toast.success('Cart registered successfully');
      setCartData({ cartName: '', cartModel: '', licensePlate: '' });
    } catch (error) {
      toast.error('Error registering cart: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="cart-registration-form">
      <ToastContainer />
      <h2>Register Your Cart</h2>
      <form onSubmit={handleSubmit} className="neon-form">
        <div className="form-group">
          <input type="text" name="cartName" value={cartData.cartName} onChange={handleChange} required />
          <label>Cart Name</label>
          {errors.cartName && <span className="error-text">{errors.cartName}</span>}
        </div>
        <div className="form-group">
          <input type="text" name="cartModel" value={cartData.cartModel} onChange={handleChange} required />
          <label>Cart Model</label>
        </div>
        <div className="form-group">
          <input type="text" name="licensePlate" value={cartData.licensePlate} onChange={handleChange} required />
          <label>License Plate</label>
          {errors.licensePlate && <span className="error-text">{errors.licensePlate}</span>}
        </div>
        <button type="submit" className="save-button">Register Cart</button>
      </form>
    </div>
  );
};

export default CartRegistrationForm;
