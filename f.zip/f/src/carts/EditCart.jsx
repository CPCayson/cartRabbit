import React, { useState, useEffect } from 'react';
import { getFirestore, doc, updateDoc, onSnapshot } from 'firebase/firestore';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import { Save } from 'lucide-react';
import { useAuth } from '../components/Authentication/AuthProvider';
import CartStats from './CartStats';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import '../styles/EditCart.css';
import Pica from 'pica';
import Slider from 'react-slick';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

const pica = Pica();
const MySwal = withReactContent(Swal);

const EditCart = ({ cartId }) => {
  const [cart, setCart] = useState({
    cartName: '',
    cartPlate: '',
    cartCapacity: 2,
    electric: false,
    airConditioner: false,
    radio: false,
    storage: false,
    cartDescription: '',
    cartPhotos: [],
    tagPhoto: null,
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const db = getFirestore();

  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, 'carts', cartId), (doc) => {
      if (doc.exists()) {
        setCart(doc.data());
      }
    }, (error) => {
      toast.error('Error fetching cart data: ' + error.message);
    });

    return () => unsubscribe();
  }, [cartId, db]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const updatedValue = type === 'checkbox' ? checked : value;
    setCart(prevCart => ({ ...prevCart, [name]: updatedValue }));
    validateField(name, updatedValue);
  };

  const handlePhotoChange = (e) => {
    const { name } = e.target;
    const files = Array.from(e.target.files);
    files.forEach(file => resizeImage(file, name));
  };

  const resizeImage = (file, name) => {
    const img = document.createElement('img');
    img.src = URL.createObjectURL(file);

    img.onload = async () => {
      const canvas = document.createElement('canvas');
      const MAX_WIDTH = 150;
      const scaleSize = MAX_WIDTH / img.width;
      canvas.width = MAX_WIDTH;
      canvas.height = img.height * scaleSize;

      await pica.resize(img, canvas);

      canvas.toBlob((blob) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setCart(prevCart => {
            const updatedPhotos = name === 'cartPhotos' ? [...prevCart.cartPhotos, reader.result] : reader.result;
            return { ...prevCart, [name]: updatedPhotos };
          });
        };
        reader.readAsDataURL(blob);
      }, file.type);

      URL.revokeObjectURL(img.src); // Revoke object URL to free memory
    };
  };

  const validateField = (name, value) => {
    let error = '';
    switch (name) {
      case 'cartName':
        if (value.trim() === '') error = 'Cart Name is required';
        break;
      case 'cartPlate':
        if (!/^[A-Z0-9-]{1,7}$/.test(value)) error = 'Cart Plate must be alphanumeric and up to 7 characters';
        break;
      case 'cartCapacity':
        if (!Number(value) || value <= 0) error = 'Cart Capacity must be a positive number';
        break;
      default:
        break;
    }
    setErrors(prevErrors => ({ ...prevErrors, [name]: error }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (Object.values(errors).some(error => error)) {
      MySwal.fire('Error', 'Please fix the errors in the form', 'error');
      return;
    }
    setLoading(true);
    try {
      await updateDoc(doc(db, 'carts', cartId), cart);
      toast.success('Cart updated successfully');
    } catch (error) {
      toast.error('Error updating cart: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading-indicator">Loading...</div>;
  }

  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };

  return (
    <div className="edit-cart-container">
      <ToastContainer />
      <h2 className="title">Edit Cart</h2>
      <form className="neon-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <input type="text" id="cartName" name="cartName" value={cart.cartName} onChange={handleChange} required />
          <label htmlFor="cartName">Cart Name</label>
          {errors.cartName && <span className="error-text">{errors.cartName}</span>}
        </div>
        <div className="form-group">
          <input type="text" id="cartPlate" name="cartPlate" value={cart.cartPlate} onChange={handleChange} required />
          <label htmlFor="cartPlate">Cart Plate</label>
          {errors.cartPlate && <span className="error-text">{errors.cartPlate}</span>}
        </div>
        <div className="form-group">
          <input type="number" id="cartCapacity" name="cartCapacity" value={cart.cartCapacity} onChange={handleChange} required />
          <label htmlFor="cartCapacity">Cart Capacity</label>
          {errors.cartCapacity && <span className="error-text">{errors.cartCapacity}</span>}
        </div>
        <div className="form-group-checkbox">
          <label className="checkbox-container">
            <input type="checkbox" name="electric" checked={cart.electric} onChange={handleChange} />
            <span className="checkmark"></span>
            Electric
          </label>
          <label className="checkbox-container">
            <input type="checkbox" name="airConditioner" checked={cart.airConditioner} onChange={handleChange} />
            <span className="checkmark"></span>
            Air Conditioner
          </label>
          <label className="checkbox-container">
            <input type="checkbox" name="radio" checked={cart.radio} onChange={handleChange} />
            <span className="checkmark"></span>
            Radio
          </label>
          <label className="checkbox-container">
            <input type="checkbox" name="storage" checked={cart.storage} onChange={handleChange} />
            <span className="checkmark"></span>
            Storage
          </label>
        </div>
        <div className="form-group">
          <ReactQuill theme="snow" value={cart.cartDescription} onChange={(value) => handleChange({ target: { name: 'cartDescription', value } })} />
          <label htmlFor="cartDescription">Cart Description</label>
          {errors.cartDescription && <span className="error-text">{errors.cartDescription}</span>}
        </div>
        <div className="form-group file-input">
          <input type="file" id="cartPhotos" name="cartPhotos" onChange={handlePhotoChange} multiple />
          <label htmlFor="cartPhotos">Cart Photos</label>
        </div>
        <div className="form-group file-input">
          <input type="file" id="tagPhoto" name="tagPhoto" onChange={handlePhotoChange} />
          <label htmlFor="tagPhoto">Tag Photo</label>
        </div>
        <Slider {...sliderSettings}>
          {cart.cartPhotos.map((photo, index) => (
            <div key={index}>
              <img src={photo} alt={`Cart Photo ${index + 1}`} className="w-full h-auto" />
            </div>
          ))}
        </Slider>
        <button type="submit" className="save-button">
          <Save size={20} />
          Save Royal Cart
        </button>
      </form>
      <CartStats cartId={cartId} />
    </div>
  );
};

export default EditCart;
