import React from 'react';
import { FaBolt, FaSnowflake, FaMusic, FaBox, FaClock, FaRuler } from 'react-icons/fa';
import FeatureIcon from './FeatureIcon'; // Import the FeatureIcon component

const CartDetails = ({ cart }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-3xl font-bold text-gray-800 mb-4">{cart.cartName}</h2>
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <p className="text-gray-600">Model: {cart.cartModel}</p>
          <p className="text-gray-600">License Plate: {cart.licensePlate}</p>
        </div>
        <div>
          <p className="text-gray-600">Capacity: {cart.capacity} persons</p>
          <p className="text-gray-600">
            <FaClock className="inline mr-2" />
            Estimated Time: {(cart.time * 60).toFixed(0)} mins
          </p>
          <p className="text-gray-600">
            <FaRuler className="inline mr-2" />
            Distance: {cart.distance.toFixed(2)} km
          </p>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-xl font-semibold text-gray-700 mb-2">Description</h3>
        <p className="text-gray-600">{cart.description}</p>
      </div>

      <div className="mb-6">
        <h3 className="text-xl font-semibold text-gray-700 mb-2">Features</h3>
        <div className="grid grid-cols-2 gap-4">
          <FeatureIcon
            feature={cart.features.electric}
            icon={<FaBolt className="text-yellow-500" />}
            label="Electric"
          />
          <FeatureIcon
            feature={cart.features.ac}
            icon={<FaSnowflake className="text-blue-500" />}
            label="Air Conditioning"
          />
          <FeatureIcon
            feature={cart.features.radio}
            icon={<FaMusic className="text-purple-500" />}
            label="Radio"
          />
          <FeatureIcon
            feature={cart.features.storage}
            icon={<FaBox className="text-brown-500" />}
            label="Storage"
          />
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold text-gray-700 mb-2">Location</h3>
        <p className="text-gray-600">Latitude: {cart.position.lat}</p>
        <p className="text-gray-600">Longitude: {cart.position.lng}</p>
      </div>
    </div>
  );
};

export default CartDetails;
