import React, { useState, useEffect } from 'react';
import { getLocalBusinesses } from '../Firebase/firebase'; // Assume this function is implemented in firebase.js

const BusinessAds = () => {
  const [businesses, setBusinesses] = useState([]);

  useEffect(() => {
    const fetchBusinesses = async () => {
      const data = await getLocalBusinesses();
      setBusinesses(data);
    };
    fetchBusinesses();
  }, []);

  return (
    <div className="business-ads">
      <h2>Local Businesses</h2>
      {businesses.map((business) => (
        <div key={business.id} className="business-ad">
          <h3>{business.name}</h3>
          <p>{business.description}</p>
          <p>Rating: {business.rating}</p>
          <p>Reviews: {business.reviews.join(', ')}</p>
        </div>
      ))}
    </div>
  );
};

export default BusinessAds;
