import { useEffect } from 'react';
import { getFirestore, doc, getDoc } from 'firebase/firestore';
import { getAuth, onAuthStateChanged } from 'firebase/auth';

const db = getFirestore();
const auth = getAuth();

const UserLocation = ({ setUserLocation }) => {
  useEffect(() => {
    const fetchUserLocation = async (uid) => {
      try {
        const docRef = doc(db, "users", uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          return docSnap.data().currentLocation || { lat: 30.3085, lng: -89.3304 };
        } else {
          return { lat: 30.3085, lng: -89.3304 };
        }
      } catch (error) {
        console.error("Error getting user document:", error);
        return { lat: 30.3085, lng: -89.3304 };
      }
    };

    onAuthStateChanged(auth, async (user) => {
      if (user) {
        const userLoc = await fetchUserLocation(user.uid);
        setUserLocation(userLoc);
      } else {
        console.log('No user is signed in.');
      }
    });
  }, [setUserLocation]);

  return null;
};

export default UserLocation;
