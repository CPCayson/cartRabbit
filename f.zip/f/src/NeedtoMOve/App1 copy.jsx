import React, { useEffect, useState, useRef } from 'react';
import { initializeApp, getApps } from 'firebase/app';
import { getFirestore, doc, getDoc, addDoc, collection, getDocs } from 'firebase/firestore';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getFunctions } from 'firebase/functions';
import { Loader } from '@googlemaps/js-api-loader';
import { loadStripe } from '@stripe/stripe-js';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import CartList from './Cart/CartList';
import './styles.scss'; // Import the SCSS file


const MySwal = withReactContent(Swal);

const firebaseConfig = {
  apiKey: "AIzaSyCKb8thPtB3e-Z0CRuVrqvlUB8WZJEQnAU",
  authDomain: "rabbit-2ba47.firebaseapp.com",
  databaseURL: "https://rabbit-2ba47-default-rtdb.firebaseio.com",
  projectId: "rabbit-2ba47",
  storageBucket: "rabbit-2ba47.appspot.com",
  messagingSenderId: "415352862345",
  appId: "1:415352862345:web:ee2bc4ef914862215cf858",
  measurementId: "G-8G7908G3CL"
};

if (!getApps().length) {
  initializeApp(firebaseConfig);
}

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY);
const db = getFirestore();
const auth = getAuth();
const functions = getFunctions();

const App1 = () => {
  const [user, setUser] = useState(null);
  const [map, setMap] = useState(null);
  const [userLocation, setUserLocation] = useState({ lat: 30.3085, lng: -89.3304 });
  const [recentDestinations, setRecentDestinations] = useState([]);
  const [carts, setCarts] = useState([]);
  const directionsServiceRef = useRef(null);
  const directionsRendererRef = useRef(null);
  const placesServiceRef = useRef(null);
  const cartMarkersRef = useRef([]);
  const [showMap, setShowMap] = useState(true);
  const [normalizedDistance, setNormalizedDistance] = useState(null);
  const [cost, setCost] = useState(null);

  const handleGoAsGuest = async () => {
    if (cost === null) {
      MySwal.fire({
        title: 'Error',
        text: 'Please calculate the route first to determine the cost.',
        icon: 'error',
        confirmButtonText: 'Close'
      });
      return;
    }

    try {
      const response = await fetch('/create-payment-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
          amount: cost * 100, 
          email: user ? user.email : 'guest@example.com' 
        }) // amount in cents, email is optional
      });

      const data = await response.json();
      const stripe = await stripePromise;
      const { error } = await stripe.redirectToCheckout({
        sessionId: data.sessionId,
      });

      if (error) {
        console.error('Error redirecting to Stripe Checkout:', error);
      } else {
        // Save the paymentIntentId for later capturing
        localStorage.setItem('paymentIntentId', data.paymentIntentId);
      }
    } catch (error) {
      console.error('Error creating payment intent:', error);
    }
  };

  useEffect(() => {
    onAuthStateChanged(auth, async (user) => {
      if (user) {
        const userLoc = await getUserLocation(user.uid);
        setUser({ ...user, currentLocation: userLoc });
        setUserLocation(userLoc);
      } else {
        console.log('No user is signed in.');
      }
    });

    const loader = new Loader({
      apiKey: "AIzaSyAeU7_Y-1gOTgOoQCq_k6nuWn8KUlOeDvM", // Replace with your actual API key
      version: "weekly",
      libraries: ["places"]
    });

    loader.load().then(() => {
      const google = window.google;
      if (google && google.maps) {
        const map = new google.maps.Map(document.getElementById("map"), {
          center: userLocation,
          zoom: 18,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        });

        setMap(map);
        initMap(map);
      } else {
        console.error('Google Maps library failed to load.');
      }
    });

    loadRecentDestinations();
    loadCarts();
  }, []);

  useEffect(() => {
    if (carts.length > 0 && userLocation) {
      updateCartDistances();
    }
  }, [carts, userLocation]);

  const getUserLocation = async (uid) => {
    try {
      const docRef = doc(db, "users", uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return docSnap.data().currentLocation || { lat: 30.3085, lng: -89.3304 };
      } else {
        return { lat: 30.3085, lng: -89.3304 };
      }
    } catch (error) {
      console.error("Error getting user document:", error);
      return { lat: 30.3085, lng: -89.3304 };
    }
  };

  const addOrder = async (user, destinationAddress, destinationLocation) => {
    try {
      const orderData = {
        user_location: user.currentLocation || null,
        user_uid: user.uid,
        driver_location: null,
        driver_uid: null,
        destination_location: destinationLocation,
        destination_address: destinationAddress,
        user_address: user.address || null,
        user_name: user.displayName || 'Anonymous',
        driver_name: null,
        is_driver_assigned: false,
      };

      const docRef = await addDoc(collection(db, "ride"), orderData);
      console.log("Order document written with ID: ", docRef.id);
    } catch (error) {
      console.error("Error adding order document: ", error);
    }
  };

  const loadCarts = async () => {
    try {
      const cartsRef = collection(db, "Carts");
      const cartsSnapshot = await getDocs(cartsRef);
      const fetchedCarts = cartsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        distance: 0,
        time: 0
      }));
      setCarts(fetchedCarts);
    } catch (error) {
      console.error("Error getting carts:", error);
    }
  };

  const loadRecentDestinations = () => {
    const recentDestinations = JSON.parse(localStorage.getItem('recentDestinations')) || [];
    setRecentDestinations(recentDestinations);
  };

  const saveRecentDestination = (destination) => {
    let recentDestinations = JSON.parse(localStorage.getItem('recentDestinations')) || [];
    recentDestinations = [destination, ...recentDestinations.filter(d => d !== destination)].slice(0, 5);
    localStorage.setItem('recentDestinations', JSON.stringify(recentDestinations));
    setRecentDestinations(recentDestinations);
  };

  const initMap = (map) => {
    const google = window.google;
    directionsServiceRef.current = new google.maps.DirectionsService();
    directionsRendererRef.current = new google.maps.DirectionsRenderer();
    directionsRendererRef.current.setMap(map);
    placesServiceRef.current = new google.maps.places.PlacesService(map);

    const circle = new google.maps.Circle({
      center: userLocation,
      radius: 32186.9, // 20 miles in meters
    });

    const input = document.getElementById('destination-input-field');
    const autocomplete = new google.maps.places.Autocomplete(input, {
      bounds: circle.getBounds(),
      strictBounds: true,
      types: ['address']
    });

    carts.forEach(cart => {
      const cartMarker = new google.maps.Marker({
        position: cart.cartLoc,
        map: map,
        icon: {
          url: 'https://i.imgur.com/OPkPGZ3.png',
          scaledSize: new google.maps.Size(32, 32)
        },
        title: `Cart ${cart.id}: ${cart.cartName}`
      });

      const cartInfoWindow = new google.maps.InfoWindow({
        content: `Cart Name: ${cart.cartName}`
      });

      cartMarker.addListener('click', () => {
        cartInfoWindow.open(map, cartMarker);
      });
    });

    const userLocationMarker = new google.maps.Marker({
      position: userLocation,
      map: map,
      icon: 'https://maps.google.com/mapfiles/kml/shapes/man.png',
      title: 'Your Location'
    });

    map.setCenter(userLocation);

    updateCartDistances();
  };

  const calculateDistanceAndTime = (start, end) => {
    const R = 6371; // Radius of the Earth in km
    const dLat = (end.lat - start.lat) * (Math.PI / 180);
    const dLng = (end.lng - start.lng) * (Math.PI / 180);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(start.lat * (Math.PI / 180)) * Math.cos(end.lat * (Math.PI / 180)) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in km

    const speed = 25; // Golf cart speed in km/h
    const time = distance / speed; // Time in hours

    return { distance, time };
  };

  const updateCartDistances = () => {
    const updatedCarts = carts.map(cart => {
      const { distance, time } = calculateDistanceAndTime(cart.cartLoc, userLocation);
      return { ...cart, distance, time };
    });
    setCarts(updatedCarts);
  };

  const searchPlaces = (type) => {
    const google = window.google;
    if (!userLocation || !placesServiceRef.current) {
      alert('User location not available or Places service not initialized.');
      return;
    }

    const request = {
      location: userLocation,
      radius: '32186.9', // 20 miles in meters
      type: [type]
    };

    placesServiceRef.current.nearbySearch(request, (results, status) => {
      if (status === google.maps.places.PlacesServiceStatus.OK) {
        const recentList = document.getElementById('recent-destination-list');
        recentList.innerHTML = '';
        results.forEach(place => {
          const li = document.createElement('li');
          li.textContent = place.name;
          li.onclick = () => {
            document.getElementById('destination-input-field').value = place.name;
            saveRecentDestination(place.name);
            setShowMap(false);
            const { distance, time } = calculateDistanceAndTime(userLocation, {
              lat: place.geometry.location.lat(),
              lng: place.geometry.location.lng()
            });
            const normalizedDistance = normalizeDistance(distance, 0, 40);
            const cost = calculateCost(normalizedDistance);
            setNormalizedDistance(normalizedDistance);
            setCost(cost);
            MySwal.fire({
              title: 'Check-in as Guest',
              text: `Distance: ${distance.toFixed(2)} km, Time: ${(time * 60).toFixed(2)} minutes, Cost: $${cost.toFixed(2)}`,
              icon: 'info',
              confirmButtonText: 'Close'
            });
          };
          recentList.appendChild(li);
        });
      }
    });
  };

  const toggleView = () => {
    setShowMap(!showMap);
  };

  const host = () => {
  };

  const dash = () => {
  };

  const calculateRoute = () => {
    const google = window.google;
    const destination = document.getElementById('destination-input-field').value;

    if (!destination) {
      MySwal.fire({
        title: 'Error',
        text: 'Please enter a destination.',
        icon: 'error',
        confirmButtonText: 'Close'
      });
      return;
    }

    if (!directionsServiceRef.current || !directionsRendererRef.current) {
      console.error('Directions service or renderer not initialized.');
      return;
    }

    const request = {
      origin: userLocation,
      destination: destination,
      travelMode: google.maps.TravelMode.DRIVING, // Assuming driving for the golf cart
    };

    directionsServiceRef.current.route(request, (result, status) => {
      if (status === google.maps.DirectionsStatus.OK) {
        directionsRendererRef.current.setDirections(result);
        const route = result.routes[0];
        const leg = route.legs[0];

        const distance = leg.distance.value / 1000; // Convert to kilometers
        const time = leg.duration.value / 3600; // Convert to hours
        const normalizedDistance = normalizeDistance(distance, 0, 40);
        const cost = calculateCost(normalizedDistance);

        setNormalizedDistance(normalizedDistance);
        setCost(cost);

        MySwal.fire({
          title: 'Route Calculated',
          text: `Distance: ${distance.toFixed(2)} km, Time: ${(time * 60).toFixed(2)} minutes, Cost: $${cost.toFixed(2)}`,
          icon: 'info',
          confirmButtonText: 'Close'
        });
      } else {
        console.error('Directions request failed due to ' + status);
      }
    });
  };

  const normalizeDistance = (distance, minDist, maxDist) => {
    return 1 + ((distance - minDist) / (maxDist - minDist)) * 4;
  };

  const calculateCost = (normalizedValue) => {
    const baseCost = 5;
    return baseCost + (normalizedValue - 1);
  };

  return (
    <div id="app">
      <h1>Golf Cart Ride-Share</h1>
      <input id="destination-input-field" type="text" placeholder="Enter destination" />
      <div className="button-container">
        <button onClick={calculateRoute}>Calculate Route</button>
        <button onClick={toggleView}>{showMap ? "Show Recent Destinations" : "Show Map"}</button>
        <button onClick={handleGoAsGuest}>Go as Guest</button>
        <button onClick={host}>host</button>
        <button onClick={host}>dash</button>


      </div>
      <div id="map" style={{ display: showMap ? 'block' : 'none', height: '50vh' }}></div>
      <div id="recent-destinations" className={showMap ? '' : 'show'}>
        <h2>Recent Destinations</h2>
        <ul id="recent-destination-list">
          {recentDestinations.map((destination, index) => (
            <li key={index} onClick={() => {
              document.getElementById('destination-input-field').value = destination;
              const { distance, time } = calculateDistanceAndTime(userLocation, { lat: 30.3085, lng: -89.3304 }); // replace with real destination coords
              const normalizedDistance = normalizeDistance(distance, 0, 40);
              const cost = calculateCost(normalizedDistance);
              setNormalizedDistance(normalizedDistance);
              setCost(cost);
              setShowMap(true);
              MySwal.fire({
                title: 'Check-in as Guest',
                text: `Distance: ${distance.toFixed(2)} km, Time: ${(time * 60).toFixed(2)} minutes, Cost: $${cost.toFixed(2)}`,
                icon: 'info',
                confirmButtonText: 'Close'
              });
            }}>
              {destination}
            </li>
          ))}
        </ul>
      </div>
      <div className="cart-list">
        {carts.map(cart => (
          <div key={cart.id} className="cart-item">
            <h3>{cart.cartName}</h3>
            <p>Distance: {cart.distance ? cart.distance.toFixed(2) : 'N/A'} km</p>
            <p>Time: {cart.time ? (cart.time * 60).toFixed(2) : 'N/A'} minutes</p>
          </div>
        ))}
      </div>
   
    </div>
  );
};

export default App1;
