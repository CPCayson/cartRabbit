import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Heart, Diamond, Spade, Club, Camera, Save } from "lucide-react";
import { getCartData, saveCartData, uploadImage } from "../Firebase/firebase";
import "../styles/EditCart.css";

const InputField = ({ label, name, value, onChange, type = "text", min }) => (
  <div className="input-group">
    <label className="text-sm text-pink-300 mb-1 block">{label}</label>
    <input
      type={type}
      name={name}
      value={value}
      onChange={onChange}
      className="w-full p-2 bg-opacity-20 bg-white backdrop-filter backdrop-blur-md text-white rounded-md border border-opacity-50 border-white focus:outline-none focus:ring-2 focus:ring-pink-400"
      required
      min={min}
    />
  </div>
);

const CheckboxField = ({ label, name, checked, onChange }) => (
  <div className="flex items-center space-x-2">
    <input
      type="checkbox"
      id={name}
      name={name}
      checked={checked}
      onChange={onChange}
      className="form-checkbox h-5 w-5 text-pink-400 rounded focus:ring-pink-400 border-opacity-50 border-white bg-opacity-20 bg-white"
    />
    <label htmlFor={name} className="text-white">
      {label}
    </label>
  </div>
);

const FileUploadField = ({ label, name, onChange }) => (
  <div className="input-group">
    <label className="text-sm text-pink-300 mb-1 block">{label}</label>
    <div className="flex items-center space-x-2">
      <input
        type="file"
        onChange={e => onChange(e, name)}
        className="hidden"
        id={name}
      />
      <label
        htmlFor={name}
        className="cursor-pointer flex items-center justify-center w-full p-2 bg-opacity-20 bg-white backdrop-filter backdrop-blur-md text-white rounded-md border border-opacity-50 border-white hover:bg-opacity-30 transition duration-300"
      >
        <Camera size={20} className="mr-2" />
        Upload {label}
      </label>
    </div>
  </div>
);

const NeonQueenGlassEditCart = () => {
  const { cartId } = useParams();
  const navigate = useNavigate();
  const [cart, setCart] = useState({
    cartName: "",
    cartPlate: "",
    isElectric: false,
    airConditioner: false,
    radio: false,
    storage: false,
    cartCapacity: 2,
    cartDescription: "",
    cartPhoto: "",
    tagPhoto: "",
  });
  const [cartPhotoFile, setCartPhotoFile] = useState(null);
  const [tagPhotoFile, setTagPhotoFile] = useState(null);

  useEffect(() => {
    if (cartId !== "new") {
      const fetchCart = async () => {
        const cartData = await getCartData(cartId);
        setCart(cartData);
      };
      fetchCart();
    }
  }, [cartId]);

  const handleInputChange = e => {
    const { name, value } = e.target;
    setCart(prevCart => ({ ...prevCart, [name]: value }));
  };

  const handleSwitchChange = e => {
    const { name, checked } = e.target;
    setCart(prevCart => ({ ...prevCart, [name]: checked }));
  };

  const handleFileChange = (e, type) => {
    const file = e.target.files[0];
    if (type === "cartPhoto") {
      setCartPhotoFile(file);
    } else if (type === "tagPhoto") {
      setTagPhotoFile(file);
    }
  };

  const handleSubmit = async e => {
    e.preventDefault();
    let updatedCart = { ...cart };

    if (cartPhotoFile) {
      const cartPhotoUrl = await uploadImage(cartPhotoFile);
      updatedCart.cartPhoto = cartPhotoUrl;
    }

    if (tagPhotoFile) {
      const tagPhotoUrl = await uploadImage(tagPhotoFile);
      updatedCart.tagPhoto = tagPhotoUrl;
    }

    await saveCartData(cartId === "new" ? null : cartId, updatedCart);
    navigate("/host-dashboard");
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-purple-900 via-pink-700 to-blue-900 p-4">
      <div className="w-full max-w-4xl bg-opacity-20 bg-white backdrop-filter backdrop-blur-lg rounded-3xl shadow-2xl overflow-hidden border-2 border-opacity-30 border-white relative">
        <div className="absolute inset-0 bg-gradient-to-br from-pink-500 to-blue-500 opacity-30"></div>

        <div className="relative p-8 space-y-6">
          <h1
            className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-blue-400 tracking-wider mb-2 text-center"
            style={{
              textShadow:
                "0 0 10px rgba(236, 72, 153, 0.7), 0 0 20px rgba(96, 165, 250, 0.7)",
            }}
          >
            {cartId !== "new" ? "EDIT CART" : "ADD CART"}
          </h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <InputField
                label="Cart Name"
                name="cartName"
                value={cart.cartName}
                onChange={handleInputChange}
              />
              <InputField
                label="Cart Plate"
                name="cartPlate"
                value={cart.cartPlate}
                onChange={handleInputChange}
              />
              <InputField
                label="Cart Capacity"
                name="cartCapacity"
                value={cart.cartCapacity}
                onChange={handleInputChange}
                type="number"
                min="1"
              />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <CheckboxField
                label="Electric"
                name="isElectric"
                checked={cart.isElectric}
                onChange={handleSwitchChange}
              />
              <CheckboxField
                label="Air Conditioner"
                name="airConditioner"
                checked={cart.airConditioner}
                onChange={handleSwitchChange}
              />
              <CheckboxField
                label="Radio"
                name="radio"
                checked={cart.radio}
                onChange={handleSwitchChange}
              />
              <CheckboxField
                label="Storage"
                name="storage"
                checked={cart.storage}
                onChange={handleSwitchChange}
              />
            </div>

            <div className="input-group">
              <label className="text-sm text-pink-300 mb-1 block">
                Cart Description
              </label>
              <textarea
                name="cartDescription"
                value={cart.cartDescription}
                onChange={handleInputChange}
                className="w-full p-2 bg-opacity-20 bg-white backdrop-filter backdrop-blur-md text-white rounded-md border border-opacity-50 border-white focus:outline-none focus:ring-2 focus:ring-pink-400"
                rows="4"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FileUploadField
                label="Cart Photo"
                name="cartPhoto"
                onChange={handleFileChange}
              />
              <FileUploadField
                label="Tag Photo"
                name="tagPhoto"
                onChange={handleFileChange}
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-pink-500 to-blue-500 text-white font-bold rounded-full shadow-lg hover:from-pink-600 hover:to-blue-600 transition duration-300 flex items-center justify-center"
              style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.7)" }}
            >
              <Save size={20} className="mr-2" />
              Save Royal Cart
            </button>
          </form>

          <div className="flex justify-between items-center mt-6">
            <Heart size={24} className="text-pink-400" />
            <Diamond size={24} className="text-blue-400" />
            <Spade size={24} className="text-pink-400" />
            <Club size={24} className="text-blue-400" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default NeonQueenGlassEditCart;
