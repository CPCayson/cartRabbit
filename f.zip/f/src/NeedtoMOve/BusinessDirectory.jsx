import React, { useState } from 'react';
import { Star, Phone, MapPin } from 'lucide-react';
import './styles/BusinessDirectory.scss';

const businesses = [
  {
    name: "100 Men Hall",
    type: "Event Venue",
    rating: 4.9,
    description: "Historic venue with great live music and events",
    address: "303 Union St, Bay Saint Louis, MS 39520",
    phone: "+1 228-342-5770"
  },
  {
    name: "200 North Beach Restaurant",
    type: "Restaurant",
    rating: 4.3,
    description: "Excellent dishes, upscale atmosphere",
    address: "200 N Beach Blvd, Bay Saint Louis, MS 39520",
    phone: "+1 228-467-9388"
  },
  {
    name: "Alice Moseley Folk Art & Antique Museum",
    type: "Museum",
    rating: 4.8,
    description: "Folk art museum with informative exhibits",
    address: "1928 Depot Way, Bay Saint Louis, MS 39520",
    phone: "+1 228-467-9223"
  },
  {
    name: "Antique Maison",
    type: "Antique Store",
    rating: 4.5,
    description: "Charming store with wide variety",
    address: "111 N 2nd St, Bay Saint Louis, MS 39520",
    phone: "+1 228-466-4848"
  },
  {
    name: "Bay Elements",
    type: "Gift Shop",
    rating: 4.6,
    description: "Unique gifts and local items",
    address: "112 S 2nd St, Bay Saint Louis, MS 39520",
    phone: "+1 228-466-4970"
  },
  {
    name: "Bay Life Gifts",
    type: "Gift Shop",
    rating: 4.6,
    description: "Local and unique products",
    address: "111 Main St, Bay Saint Louis, MS 39520",
    phone: "+1 228-466-4970"
  },
  {
    name: "Bay St Louis Little Theatre",
    type: "Theater",
    rating: 4.8,
    description: "Local theater with various performances",
    address: "398 Blaize Ave, Bay Saint Louis, MS 39520",
    phone: "+1 228-467-9024"
  },
  {
    name: "Bay Town Inn",
    type: "Hotel",
    rating: 4.9,
    description: "Charming inn with stunning views",
    address: "208 N Beach Blvd, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "Baytique",
    type: "Boutique",
    rating: 4.7,
    description: "Trendy clothing and accessories",
    address: "125 Main St, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "Biz-Zee Bee",
    type: "Toy Store",
    rating: 4.8,
    description: "Wide variety of toys and games",
    address: "111 Court St, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "Blu Bay",
    type: "Restaurant",
    rating: 4.4,
    description: "Delicious seafood and great service",
    address: "111 Main St, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "Bodega Adventure Rentals",
    type: "Recreational Equipment Rental",
    rating: 4.7,
    description: "Bike, kayak, and paddleboard rentals",
    address: "111 Court St, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "Bodega Spirits & Liquor",
    type: "Liquor Store",
    rating: 4.8,
    description: "Well-stocked store with good prices",
    address: "111 Court St, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "Cafe BoneJour",
    type: "Cafe",
    rating: 4.5,
    description: "Charming cafe with great coffee",
    address: "126 Main St, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "California Drawstrings",
    type: "Clothing Store",
    rating: 4.6,
    description: "Trendy clothing store",
    address: "216 Main St, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "Clay Creations",
    type: "Art Gallery",
    rating: 4.7,
    description: "Unique clay art gallery",
    address: "220 Main St, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "Cloud Nin9 Smoke & Co.",
    type: "Smoke Shop",
    rating: 4.5,
    description: "Well-stocked smoke shop",
    address: "100 Sycamore St, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "Coastal Payments Systems",
    type: "Financial Service",
    rating: 4.7,
    description: "Financial services provider",
    address: "600 Central Ave, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "Cotton Exchange",
    type: "Clothing Store",
    rating: 4.6,
    description: "Trendy clothing store",
    address: "112 S 2nd St, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "Creole Creamery",
    type: "Ice Cream Shop",
    rating: 4.8,
    description: "Delicious ice cream shop",
    address: "209 Main St, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  },
  {
    name: "Cuz's Old Town Oyster Bar & Grill",
    type: "Restaurant",
    rating: 4.5,
    description: "Seafood restaurant with great views",
    address: "108 S Beach Blvd, Bay Saint Louis, MS 39520",
    phone: "+1 228-344-3044"
  }
];
const BusinessDirectory = () => {
  const [filteredBusinesses, setFilteredBusinesses] = useState(businesses);

  const filterBy = (type) => {
    if (type === 'all') {
      setFilteredBusinesses(businesses);
    } else {
      setFilteredBusinesses(businesses.filter(business => business.type === type));
    }
  };

  const sortBy = (criteria) => {
    let sorted = [...filteredBusinesses];
    switch(criteria) {
      case 'name':
        sorted.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'rating':
        sorted.sort((a, b) => b.rating - a.rating);
        break;
      case 'type':
        sorted.sort((a, b) => a.type.localeCompare(b.type));
        break;
      default:
        break;
    }
    setFilteredBusinesses(sorted);
  };

  const BusinessTile = ({ business }) => (
    <div className="casino-slot-machine" data-type={business.type}>
      <div className="slot-header">
        <h2>{business.name}</h2>
        <p className="business-type">{business.type}</p>
      </div>
      <div className="slot-reels">
        <div className="reel">
          <Star className="icon" />
          <p>{business.rating.toFixed(1)}</p>
        </div>
        <div className="reel">
          <Phone className="icon" />
          <p>{business.phone}</p>
        </div>
        <div className="reel">
          <MapPin className="icon" />
          <p>{business.address}</p>
        </div>
      </div>
      <div className="slot-description">
        <p>{business.description}</p>
      </div>
    </div>
  );

  return (
    <div className="casino-business-directory">
      <h1 className="neon-text">Bay Saint Louis Business Directory</h1>
      
      <div className="casino-controls">
        <div className="casino-filters">
          <button className="casino-chip" onClick={() => filterBy('all')}>All</button>
          <button className="casino-chip" onClick={() => filterBy('Restaurant')}>Restaurants</button>
          <button className="casino-chip" onClick={() => filterBy('Gift Shop')}>Gift Shops</button>
          <button className="casino-chip" onClick={() => filterBy('Hotel')}>Hotels</button>
          <button className="casino-chip" onClick={() => filterBy('Boutique')}>Boutiques</button>
        </div>

        <div className="casino-sort">
          <button className="casino-button" onClick={() => sortBy('name')}>Sort by Name</button>
          <button className="casino-button" onClick={() => sortBy('rating')}>Sort by Rating</button>
          <button className="casino-button" onClick={() => sortBy('type')}>Sort by Type</button>
        </div>
      </div>

      <div className="casino-grid">
        {filteredBusinesses.map((business, index) => (
          <BusinessTile key={index} business={business} />
        ))}
      </div>
    </div>
  );
};

export default BusinessDirectory;