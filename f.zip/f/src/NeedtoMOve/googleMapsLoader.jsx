import { Loader } from '@googlemaps/js-api-loader';
import firebaseConfig from './firebaseConfig'; // Correctly import the firebaseConfig

let loaderInstance = null;

const getLoaderInstance = () => {
  if (!loaderInstance) {
    loaderInstance = new Loader({
      apiKey: "AIzaSyAeU7_Y-1gOTgOoQCq_k6nuWn8KUlOeDvM"
      ,
      libraries: ["places"]
    });
  }
  return loaderInstance;
};

export default getLoaderInstance;
