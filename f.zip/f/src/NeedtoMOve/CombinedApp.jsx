import React, { useEffect, useState, useRef } from 'react';
import { initializeApp, getApps } from 'firebase/app';
import { getFirestore, doc, getDoc, addDoc, collection, getDocs } from 'firebase/firestore';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getFunctions } from 'firebase/functions';
import { Loader } from '@googlemaps/js-api-loader';
import { loadStripe } from '@stripe/stripe-js';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';


const MySwal = withReactContent(Swal);

const firebaseConfig = {
  apiKey: "AIzaSyCKb8thPtB3e-Z0CRuVrqvlUB8WZJEQnAU",
  authDomain: "rabbit-2ba47.firebaseapp.com",
  databaseURL: "https://rabbit-2ba47-default-rtdb.firebaseio.com",
  projectId: "rabbit-2ba47",
  storageBucket: "rabbit-2ba47.appspot.com",
  messagingSenderId: "415352862345",
  appId: "1:415352862345:web:ee2bc4ef914862215cf858",
  measurementId: "G-8G7908G3CL"
};

if (!getApps().length) {
  initializeApp(firebaseConfig);
}

const stripePromise = loadStripe(process.env.STRIPE_PUBLISHABLE_KEY);
const db = getFirestore();
const auth = getAuth();
const functions = getFunctions();

const CombinedApp = () => {
  const [user, setUser] = useState(null);
  const [map, setMap] = useState(null);
  const [userLocation, setUserLocation] = useState({ lat: 30.3085, lng: -89.3304 });
  const [recentDestinations, setRecentDestinations] = useState([]);
  const [carts, setCarts] = useState([]);
  const [businesses, setBusinesses] = useState([]);
  const [filteredBusinesses, setFilteredBusinesses] = useState([]);
  const directionsServiceRef = useRef(null);
  const directionsRendererRef = useRef(null);
  const placesServiceRef = useRef(null);
  const cartMarkersRef = useRef([]);
  const [showMap, setShowMap] = useState(true);
  const [normalizedDistance, setNormalizedDistance] = useState(null);
  const [cost, setCost] = useState(null);

  const handleGoAsGuest = async () => {
    try {
      const response = await fetch('/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ amount: cost * 100, email: 'guest@example.com' })
      });

      const data = await response.json();
      const stripe = await stripePromise;
      const { error } = await stripe.redirectToCheckout({
        sessionId: data.id,
      });

      if (error) {
        console.error('Error redirecting to Stripe Checkout:', error);
      }
    } catch (error) {
      console.error('Error creating checkout session:', error);
    }
  };

  useEffect(() => {
    onAuthStateChanged(auth, async (user) => {
      if (user) {
        const userLoc = await getUserLocation(user.uid);
        setUser({ ...user, currentLocation: userLoc });
        setUserLocation(userLoc);
      } else {
        console.log('No user is signed in.');
      }
    });

    const loader = new Loader({
      apiKey: "AIzaSyAeU7_Y-1gOTgOoQCq_k6nuWn8KUlOeDvM",
      version: "weekly",
      libraries: ["places"]
    });

    loader.load().then(() => {
      const google = window.google;
      if (google && google.maps) {
        const map = new google.maps.Map(document.getElementById("map"), {
          center: userLocation,
          zoom: 18,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        });

        setMap(map);
        initMap(map);
      } else {
        console.error('Google Maps library failed to load.');
      }
    });

    loadRecentDestinations();
    loadCarts();
    loadBusinesses();
  }, []);

  useEffect(() => {
    if (carts.length > 0 && userLocation) {
      updateCartDistances();
    }
  }, [carts, userLocation]);

  const getUserLocation = async (uid) => {
    try {
      const docRef = doc(db, "users", uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return docSnap.data().currentLocation || { lat: 30.3085, lng: -89.3304 };
      } else {
        return { lat: 30.3085, lng: -89.3304 };
      }
    } catch (error) {
      console.error("Error getting user document:", error);
      return { lat: 30.3085, lng: -89.3304 };
    }
  };

  const addOrder = async (user, destinationAddress, destinationLocation) => {
    try {
      const orderData = {
        user_location: user.currentLocation || null,
        user_uid: user.uid,
        driver_location: null,
        driver_uid: null,
        destination_location: destinationLocation,
        destination_address: destinationAddress,
        user_address: user.address || null,
        user_name: user.displayName || 'Anonymous',
        driver_name: null,
        is_driver_assigned: false,
      };

      const docRef = await addDoc(collection(db, "ride"), orderData);
      console.log("Order document written with ID: ", docRef.id);
    } catch (error) {
      console.error("Error adding order document: ", error);
    }
  };

  const loadCarts = async () => {
    try {
      const cartsRef = collection(db, "Carts");
      const cartsSnapshot = await getDocs(cartsRef);
      const fetchedCarts = cartsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        distance: 0,
        time: 0
      }));
      setCarts(fetchedCarts);
    } catch (error) {
      console.error("Error getting carts:", error);
    }
  };

  const loadRecentDestinations = () => {
    const recentDestinations = JSON.parse(localStorage.getItem('recentDestinations')) || [];
    setRecentDestinations(recentDestinations);
  };

  const saveRecentDestination = (destination) => {
    let recentDestinations = JSON.parse(localStorage.getItem('recentDestinations')) || [];
    recentDestinations = [destination, ...recentDestinations.filter(d => d !== destination)].slice(0, 5);
    localStorage.setItem('recentDestinations', JSON.stringify(recentDestinations));
    setRecentDestinations(recentDestinations);
  };

  const initMap = (map) => {
    const google = window.google;
    directionsServiceRef.current = new google.maps.DirectionsService();
    directionsRendererRef.current = new google.maps.DirectionsRenderer();
    directionsRendererRef.current.setMap(map);
    placesServiceRef.current = new google.maps.places.PlacesService(map);

    const circle = new google.maps.Circle({
      center: userLocation,
      radius: 32186.9, // 20 miles in meters
    });

    const input = document.getElementById('destination-input-field');
    const autocomplete = new google.maps.places.Autocomplete(input, {
      bounds: circle.getBounds(),
      strictBounds: true,
      types: ['address']
    });

    carts.forEach(cart => {
      const cartMarker = new google.maps.Marker({
        position: cart.cartLoc,
        map: map,
        icon: {
          url: 'https://i.imgur.com/OPkPGZ3.png',
          scaledSize: new google.maps.Size(32, 32)
        },
        title: `Cart ${cart.id}: ${cart.cartName}`
      });

      const cartInfoWindow = new google.maps.InfoWindow({
        content: `Cart Name: ${cart.cartName}`
      });

      cartMarker.addListener('click', () => {
        cartInfoWindow.open(map, cartMarker);
      });
    });

    const userLocationMarker = new google.maps.Marker({
      position: userLocation,
      map: map,
      icon: 'https://maps.google.com/mapfiles/kml/shapes/man.png',
      title: 'Your Location'
    });

    map.setCenter(userLocation);

    updateCartDistances();
  };

  const calculateDistanceAndTime = (start, end) => {
    const R = 6371; // Radius of the Earth in km
    const dLat = (end.lat - start.lat) * (Math.PI / 180);
    const dLng = (end.lng - start.lng) * (Math.PI / 180);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(start.lat * (Math.PI / 180)) * Math.cos(end.lat * (Math.PI / 180)) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in km

    const speed = 25; // Golf cart speed in km/h
    const time = distance / speed; // Time in hours

    return { distance, time };
  };

  const updateCartDistances = () => {
    const updatedCarts = carts.map(cart => {
      const { distance, time } = calculateDistanceAndTime(cart.cartLoc, userLocation);
      return { ...cart, distance, time };
    });
    setCarts(updatedCarts);
  };

  const searchPlaces = (type) => {
    const google = window.google;
    if (!userLocation || !placesServiceRef.current) {
      alert('User location not available or Places service not initialized.');
      return;
    }

    const request = {
      location: userLocation,
      radius: '32186.9', // 20 miles in meters
      type: [type]
    };

    placesServiceRef.current.nearbySearch(request, (results, status) => {
      if (status === google.maps.places.PlacesServiceStatus.OK) {
        const recentList = document.getElementById('recent-destination-list');
        recentList.innerHTML = '';
        results.forEach(place => {
          const li = document.createElement('li');
          li.textContent = place.name;
          li.onclick = () => {
            document.getElementById('destination-input-field').value = place.name;
            saveRecentDestination(place.name);
            setShowMap(false);
            const { distance, time } = calculateDistanceAndTime(userLocation, {
              lat: place.geometry.location.lat(),
              lng: place.geometry.location.lng()
            });
            const normalizedDistance = normalizeDistance(distance, 0, 40);
            const cost = calculateCost(normalizedDistance);
            setNormalizedDistance(normalizedDistance);
            setCost(cost);
            MySwal.fire({
              title: 'Check-in as Guest',
              text: `Distance: ${distance.toFixed(2)} km, Time: ${(time * 60).toFixed(2)} minutes, Cost: $${cost.toFixed(2)}`,
              icon: 'info',
              confirmButtonText: 'Close'
            });
          };
          recentList.appendChild(li);
        });
      }
    });
  };

  const toggleView = () => {
    setShowMap(!showMap);
  };

  const calculateRoute = () => {
    const destinationInput = document.getElementById('destination-input-field').value;
    const google = window.google;

    if (!destinationInput) {
      MySwal.fire({
        title: 'Error',
        text: 'Please enter a destination.',
        icon: 'error',
        confirmButtonText: 'Close'
      });
      return;
    }

    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address: destinationInput }, async (results, status) => {
      if (status === google.maps.GeocoderStatus.OK && results[0]) {
        const destinationLocation = {
          lat: results[0].geometry.location.lat(),
          lng: results[0].geometry.location.lng()
        };

        const { distance, time } = calculateDistanceAndTime(userLocation, destinationLocation);
        const normalizedDistance = normalizeDistance(distance, 0, 40);
        const cost = calculateCost(normalizedDistance);

        setNormalizedDistance(normalizedDistance);
        setCost(cost);

        try {
          const response = await fetch('http://localhost:5000/create-checkout-session', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ amount: cost * 100, email: 'guest@example.com' }) // amount in cents, email is optional
          });

          const data = await response.json();
          const stripe = await stripePromise;
          const { error } = await stripe.redirectToCheckout({
            sessionId: data.id,
          });

          if (error) {
            console.error('Error redirecting to Stripe Checkout:', error);
          }
        } catch (error) {
          console.error('Error creating checkout session:', error);
        }

        MySwal.fire({
          title: 'Route Calculated',
          text: `Distance: ${distance.toFixed(2)} km, Time: ${(time * 60).toFixed(2)} minutes, Cost: $${cost.toFixed(2)}`,
          icon: 'info',
          confirmButtonText: 'Close'
        });
      } else {
        MySwal.fire({
          title: 'Error',
          text: 'Geocode was not successful for the following reason: ' + status,
          icon: 'error',
          confirmButtonText: 'Close'
        });
      }
    });
  };

  const normalizeDistance = (distance, minDist, maxDist) => {
    return 1 + ((distance - minDist) / (maxDist - minDist)) * 4;
  };

  const calculateCost = (normalizedValue) => {
    const baseCost = 5;
    return baseCost + (normalizedValue - 1);
  };

  const loadBusinesses = () => {
    const businessesData = [
      {
        name: "100 Men Hall",
        type: "Event Venue",
        rating: 4.9,
        description: "Historic venue with great live music and events",
        address: "303 Union St, Bay Saint Louis, MS 39520",phone: "+1 228-342-5770"
      },
      {
        name: "200 North Beach Restaurant",
        type: "Restaurant",
        rating: 4.3,
        description: "Excellent dishes, upscale atmosphere",
        address: "200 N Beach Blvd, Bay Saint Louis, MS 39520",
        phone: "+1 228-467-9388"
      },
      // Add more businesses here...
    ];
    setBusinesses(businessesData);
    setFilteredBusinesses(businessesData);
  };

  const filterBy = (type) => {
    if (type === 'all') {
      setFilteredBusinesses(businesses);
    } else {
      setFilteredBusinesses(businesses.filter(business => business.type === type));
    }
  };

  const sortBy = (criteria) => {
    let sorted = [...filteredBusinesses];
    switch(criteria) {
      case 'name':
        sorted.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'rating':
        sorted.sort((a, b) => b.rating - a.rating);
        break;
      case 'type':
        sorted.sort((a, b) => a.type.localeCompare(b.type));
        break;
      default:
        break;
    }
    setFilteredBusinesses(sorted);
  };

  const handleBusinessSelect = (business) => {
    document.getElementById('destination-input-field').value = business.address;
    saveRecentDestination(business.name);
    setShowMap(true);
    calculateRoute();
  };

  const BusinessTile = ({ business }) => (
    <div className="tile" data-type={business.type} onClick={() => handleBusinessSelect(business)}>
      <h2>{business.name}</h2>
      <p>{business.type}</p>
      <p className="rating">★ {business.rating.toFixed(1)}</p>
      <p>{business.description}</p>
      <p>{business.address}</p>
      <p>{business.phone}</p>
    </div>
  );

  return (
    <div id="app">
      <h1>Golf Cart Ride-Share & Business Directory</h1>
      <input id="destination-input-field" type="text" placeholder="Enter destination" />
      <div className="button-container">
        <button onClick={calculateRoute}>Calculate Route</button>
        <button onClick={toggleView}>{showMap ? "Show Businesses" : "Show Map"}</button>
        <button onClick={handleGoAsGuest}>Go as Guest</button>
      </div>
      <div id="map" style={{ display: showMap ? 'block' : 'none', height: '50vh' }}></div>
      {!showMap ? (
        <div className="business-directory">
          <h2>Bay Saint Louis Business Directory</h2>
          <div className="filters">
            <button onClick={() => filterBy('all')}>All</button>
            <button onClick={() => filterBy('Restaurant')}>Restaurants</button>
            <button onClick={() => filterBy('Gift Shop')}>Gift Shops</button>
            <button onClick={() => filterBy('Hotel')}>Hotels</button>
            <button onClick={() => filterBy('Event Venue')}>Event Venues</button>
          </div>
          <div className="sort">
            <button onClick={() => sortBy('name')}>Sort by Name</button>
            <button onClick={() => sortBy('rating')}>Sort by Rating</button>
            <button onClick={() => sortBy('type')}>Sort by Type</button>
          </div>
          <div className="grid">
            {filteredBusinesses.map((business, index) => (
              <BusinessTile key={index} business={business} />
            ))}
          </div>
        </div>
      ) : (
        <div id="recent-destinations" className={showMap ? '' : 'show'}>
          <h2>Recent Destinations</h2>
          <ul id="recent-destination-list">
            {recentDestinations.map((destination, index) => (
              <li key={index} onClick={() => {
                document.getElementById('destination-input-field').value = destination;
                const { distance, time } = calculateDistanceAndTime(userLocation, { lat: 30.3085, lng: -89.3304 });
                const normalizedDistance = normalizeDistance(distance, 0, 40);
                const cost = calculateCost(normalizedDistance);
                setNormalizedDistance(normalizedDistance);
                setCost(cost);
                setShowMap(true);
                MySwal.fire({
                  title: 'Check-in as Guest',
                  text: `Distance: ${distance.toFixed(2)} km, Time: ${(time * 60).toFixed(2)} minutes, Cost: $${cost.toFixed(2)}`,
                  icon: 'info',
                  confirmButtonText: 'Close'
                });
              }}>
                {destination}
              </li>
            ))}
          </ul>
        </div>
      )}
      <div className="cart-list">
        {carts.map(cart => (
          <div key={cart.id} className="cart-item">
            <h3>{cart.cartName}</h3>
            <p>Distance: {cart.distance ? cart.distance.toFixed(2) : 'N/A'} km</p>
            <p>Time: {cart.time ? (cart.time * 60).toFixed(2) : 'N/A'} minutes</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CombinedApp;
        