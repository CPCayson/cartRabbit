import React, { useEffect, useState, useCallback } from 'react';
import ReactDOM from 'react-dom'; // Import ReactDOM
import { initializeApp, getApps } from 'firebase/app';
import { getFirestore, doc, getDoc, addDoc, collection, getDocs } from 'firebase/firestore';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import CartList from './Cart/CartList';
import MapComponent from '../components/guests/MapComponent';
import SearchInput from '../components/guests/SearchInput';
import StripeCheckout from './StripeCheckout';
import './styles.scss'; // Import the SCSS file

const MySwal = withReactContent(Swal);

const firebaseConfig = {
  apiKey: "AIzaSyCKb8thPtB3e-Z0CRuVrqvlUB8WZJEQnAU",
  authDomain: "rabbit-2ba47.firebaseapp.com",
  databaseURL: "https://rabbit-2ba47-default-rtdb.firebaseio.com",
  projectId: "rabbit-2ba47",
  storageBucket: "rabbit-2ba47.appspot.com",
  messagingSenderId: "415352862345",
  appId: "1:415352862345:web:ee2bc4ef914862215cf858",
  measurementId: "G-8G7908G3CL"
};

if (!getApps().length) {
  initializeApp(firebaseConfig);
}

const db = getFirestore();
const auth = getAuth();

const App1 = () => {
  const [user, setUser] = useState(null);
  const [userLocation, setUserLocation] = useState({ lat: 30.3085, lng: -89.3304 });
  const [recentDestinations, setRecentDestinations] = useState([]);
  const [carts, setCarts] = useState([]);
  const [showMap, setShowMap] = useState(true);
  const [normalizedDistance, setNormalizedDistance] = useState(null);
  const [cost, setCost] = useState(null);

  const handleGoAsGuest = () => {
    if (cost === null) {
      MySwal.fire({
        title: 'Error',
        text: 'Please calculate the route first to determine the cost.',
        icon: 'error',
        confirmButtonText: 'Close'
      });
      return;
    }

    MySwal.fire({
      title: 'Check-in as Guest',
      html: `
        <p>Distance: ${normalizedDistance} km</p>
        <p>Time: ${(normalizedDistance * 60).toFixed(2)} minutes</p>
        <button id="show-checkout-button" class="swal2-confirm swal2-styled">Pay $${cost.toFixed(2)}</button>
        <div id="stripe-checkout" style="display: none;"></div>
      `,
      didOpen: () => {
        document.getElementById('show-checkout-button').addEventListener('click', () => {
          document.getElementById('stripe-checkout').style.display = 'block';
          ReactDOM.render(<StripeCheckout amount={cost * 100} />, document.getElementById('stripe-checkout'));
        });
      },
      willClose: () => {
        ReactDOM.unmountComponentAtNode(document.getElementById('stripe-checkout'));
      },
      showConfirmButton: false
    });
  };

  useEffect(() => {
    const loadUserAndCarts = async () => {
      onAuthStateChanged(auth, async (user) => {
        if (user) {
          const userLoc = await getUserLocation(user.uid);
          setUser({ ...user, currentLocation: userLoc });
          setUserLocation(userLoc);
        } else {
          console.log('No user is signed in.');
        }
      });

      await loadCarts();
      loadRecentDestinations();
    };

    loadUserAndCarts();
  }, []);

  useEffect(() => {
    if (carts.length > 0 && userLocation) {
      updateCartDistances();
    }
  }, [carts, userLocation]);

  const getUserLocation = async (uid) => {
    try {
      const docRef = doc(db, "users", uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return docSnap.data().currentLocation || { lat: 30.3085, lng: -89.3304 };
      } else {
        return { lat: 30.3085, lng: -89.3304 };
      }
    } catch (error) {
      console.error("Error getting user document:", error);
      return { lat: 30.3085, lng: -89.3304 };
    }
  };

  const addOrder = async (user, destinationAddress, destinationLocation) => {
    try {
      const orderData = {
        user_location: user.currentLocation || null,
        user_uid: user.uid,
        driver_location: null,
        driver_uid: null,
        destination_location: destinationLocation,
        destination_address: destinationAddress,
        user_address: user.address || null,
        user_name: user.displayName || 'Anonymous',
        driver_name: null,
        is_driver_assigned: false,
      };

      const docRef = await addDoc(collection(db, "ride"), orderData);
      console.log("Order document written with ID: ", docRef.id);
    } catch (error) {
      console.error("Error adding order document: ", error);
    }
  };

  const loadCarts = async () => {
    try {
      const cartsRef = collection(db, "Carts");
      const cartsSnapshot = await getDocs(cartsRef);
      const fetchedCarts = cartsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        distance: 0,
        time: 0
      }));
      setCarts(fetchedCarts);
    } catch (error) {
      console.error("Error getting carts:", error);
    }
  };

  const loadRecentDestinations = () => {
    const recentDestinations = JSON.parse(localStorage.getItem('recentDestinations')) || [];
    setRecentDestinations(recentDestinations);
  };

  const saveRecentDestination = (destination) => {
    let recentDestinations = JSON.parse(localStorage.getItem('recentDestinations')) || [];
    recentDestinations = [destination, ...recentDestinations.filter(d => d !== destination)].slice(0, 5);
    localStorage.setItem('recentDestinations', JSON.stringify(recentDestinations));
    setRecentDestinations(recentDestinations);
  };

  const updateCartDistances = useCallback(() => {
    const updatedCarts = carts.map(cart => {
      const { distance, time } = calculateDistanceAndTime(cart.cartLoc, userLocation);
      return { ...cart, distance, time };
    });
    setCarts(updatedCarts);
  }, [carts, userLocation]);

  const calculateDistanceAndTime = (start, end) => {
    const R = 6371; // Radius of the Earth in km
    const dLat = (end.lat - start.lat) * (Math.PI / 180);
    const dLng = (end.lng - start.lng) * (Math.PI / 180);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(start.lat * (Math.PI / 180)) * Math.cos(end.lat * (Math.PI / 180)) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in km

    const speed = 25; // Golf cart speed in km/h
    const time = distance / speed; // Time in hours

    return { distance, time };
  };

  const normalizeDistance = (distance, minDist, maxDist) => {
    return 1 + ((distance - minDist) / (maxDist - minDist)) * 4;
  };

  const calculateCost = (normalizedValue) => {
    const baseCost = 5;
    return baseCost + (normalizedValue - 1);
  };

  const handlePlaceSelected = (place) => {
    const { geometry } = place;
    const destinationLocation = {
      lat: geometry.location.lat(),
      lng: geometry.location.lng()
    };

    const { distance, time } = calculateDistanceAndTime(userLocation, destinationLocation);
    const normalizedDistance = normalizeDistance(distance, 0, 40);
    const cost = calculateCost(normalizedDistance);

    setNormalizedDistance(normalizedDistance);
    setCost(cost);

    MySwal.fire({
      title: 'Check-in as Guest',
      html: `
        <p>Distance: ${distance.toFixed(2)} km</p>
        <p>Time: ${(time * 60).toFixed(2)} minutes</p>
        <button id="show-checkout-button" class="swal2-confirm swal2-styled">Pay $${cost.toFixed(2)}</button>
        <div id="stripe-checkout" style="display: none;"></div>
      `,
      didOpen: () => {
        document.getElementById('show-checkout-button').addEventListener('click', () => {
          document.getElementById('stripe-checkout').style.display = 'block';
          ReactDOM.render(<StripeCheckout amount={cost * 100} />, document.getElementById('stripe-checkout'));
        });
      },
      willClose: () => {
        ReactDOM.unmountComponentAtNode(document.getElementById('stripe-checkout'));
      },
      showConfirmButton: false
    });
  };

  const toggleView = () => {
    setShowMap(!showMap);
  };

  const host = () => {
    // Host functionality here
  };

  const dash = () => {
    // Dash functionality here
  };

  return (
    <div id="app">
      <h1>Golf Cart Ride-Share</h1>
      <SearchInput handlePlaceSelected={handlePlaceSelected} />
      <div className="button-container">
        <button onClick={toggleView}>{showMap ? "Show Recent Destinations" : "Show Map"}</button>
        <button onClick={handleGoAsGuest}>Go as Guest</button>
        <button onClick={host}>Host</button>
        <button onClick={dash}>Dash</button>
      </div>
      {showMap ? (
        <MapComponent
          userLocation={userLocation}
          carts={carts}
        />
      ) : (
        <div id="recent-destinations" className="show">
          <h2>Recent Destinations</h2>
          <ul id="recent-destination-list">
            {recentDestinations.map((destination, index) => (
              <li key={index} onClick={() => {
                const destinationLocation = { lat: 30.3085, lng: -89.3304 }; // replace with real destination coords
                const { distance, time } = calculateDistanceAndTime(userLocation, destinationLocation);
                const normalizedDistance = normalizeDistance(distance, 0, 40);
                const cost = calculateCost(normalizedDistance);
                setNormalizedDistance(normalizedDistance);
                setCost(cost);
                setShowMap(true);
                MySwal.fire({
                  title: 'Check-in as Guest',
                  html: `
                    <p>Distance: ${distance.toFixed(2)} km</p>
                    <p>Time: ${(time * 60).toFixed(2)} minutes</p>
                    <button id="show-checkout-button" class="swal2-confirm swal2-styled">Pay $${cost.toFixed(2)}</button>
                    <div id="stripe-checkout" style="display: none;"></div>
                  `,
                  didOpen: () => {
                    document.getElementById('show-checkout-button').addEventListener('click', () => {
                      document.getElementById('stripe-checkout').style.display = 'block';
                      ReactDOM.render(<StripeCheckout amount={cost * 100} />, document.getElementById('stripe-checkout'));
                    });
                  },
                  willClose: () => {
                    ReactDOM.unmountComponentAtNode(document.getElementById('stripe-checkout'));
                  },
                  showConfirmButton: false
                });
              }}>
                {destination}
              </li>
            ))}
          </ul>
        </div>
      )}
      <CartList carts={carts} />
    </div>
  );
};

export default App1;
