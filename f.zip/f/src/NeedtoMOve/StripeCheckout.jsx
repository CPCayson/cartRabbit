import React, { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

// Load your Stripe public key
const stripePromise = loadStripe('pk_test_51KVWLuCox373OxMXkU9dlTZBMHJkmV9z8XCguTm4iSNaoxGFkhZ2UjcjaiHoJmvljbqqV0vm1XTk2W108Ep8ExxL00VSEiwo7V');

const CheckoutForm = ({ clientSecret }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [errorMessage, setErrorMessage] = useState(null);
  const [userEmail, setUserEmail] = useState('');
  const [userPhone, setUserPhone] = useState('');

  useEffect(() => {
    // Check if user email and phone are stored in local storage
    const storedEmail = localStorage.getItem('userEmail');
    const storedPhone = localStorage.getItem('userPhone');
    if (storedEmail) setUserEmail(storedEmail);
    if (storedPhone) setUserPhone(storedPhone);
  }, []);

  const handleEmailChange = (event) => {
    setUserEmail(event.target.value);
    localStorage.setItem('userEmail', event.target.value);
  };

  const handlePhoneChange = (event) => {
    setUserPhone(event.target.value);
    localStorage.setItem('userPhone', event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    const result = await stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: elements.getElement(CardElement),
        billing_details: {
          email: userEmail,
          phone: userPhone
        },
      }
    });

    if (result.error) {
      setErrorMessage(result.error.message);
    } else {
      if (result.paymentIntent.status === 'succeeded') {
        alert('Payment successful!');
      }
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="email"
        name="email"
        placeholder="Email"
        value={userEmail}
        onChange={handleEmailChange}
        autoComplete="email"
      />
      <input
        type="tel"
        name="phone"
        placeholder="Phone Number"
        value={userPhone}
        onChange={handlePhoneChange}
        autoComplete="tel"
      />
      <CardElement />
      <button type="submit" disabled={!stripe}>Submit Payment</button>
      {errorMessage && <div>{errorMessage}</div>}
    </form>
  );
};

const StripeCheckout = ({ amount }) => {
  const [clientSecret, setClientSecret] = useState('');

  useEffect(() => {
    const fetchClientSecret = async () => {
      const response = await fetch('/create-payment-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ amount }) // Amount in cents
      });
      const { clientSecret } = await response.json();
      setClientSecret(clientSecret);
    };

    fetchClientSecret();
  }, [amount]);

  return (
    <Elements stripe={stripePromise}>
      <CheckoutForm clientSecret={clientSecret} />
    </Elements>
  );
};

export default StripeCheckout;
