import React, { useEffect, useState } from 'react';
import { getLocalBusinesses } from '../Firebase/firebase'; // Function to fetch local businesses

const LocalBusinessPopups = () => {
  const [businesses, setBusinesses] = useState([]);

  useEffect(() => {
    const fetchBusinesses = async () => {
      const data = await getLocalBusinesses();
      setBusinesses(data);
    };
    fetchBusinesses();
  }, []);

  return (
    <div className="local-business-popups">
      <h2>Local Businesses</h2>
      <div className="business-list">
        {businesses.map((business, index) => (
          <div key={index} className="business-popup">
            <h3>{business.name}</h3>
            <p>{business.description}</p>
            <p>Rating: {business.rating}</p>
            <p>Reviews: {business.reviews.join(', ')}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LocalBusinessPopups;
