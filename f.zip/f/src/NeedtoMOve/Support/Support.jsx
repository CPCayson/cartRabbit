import React from 'react';
import '../styles/Support.css';

const Support = () => {
  return (
    <div className="support">
      <h2>Support</h2>
      <div className="support-section">
        <h3>Contact Us</h3>
        <p>If you have any questions or need assistance, please contact our support team at support@example.com or call us at 123-456-7890.</p>
      </div>
      <div className="support-section">
        <h3>Dispute a Charge</h3>
        <p>If you want to dispute a charge, please fill out the dispute form and our team will get back to you as soon as possible.</p>
        <button>Dispute Form</button>
      </div>
      <div className="support-section">
        <h3>Request a Refund</h3>
        <p>If you are not satisfied with a service, you can request a refund. Please fill out the refund request form.</p>
        <button>Refund Request Form</button>
      </div>
    </div>
  );
};

export default Support;
