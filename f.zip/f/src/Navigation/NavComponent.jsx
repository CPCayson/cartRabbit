// src/Navigation/NavComponent.js
import React from 'react';
import { FaMap, FaList, FaColumns, FaStore } from 'react-icons/fa';

const NavComponent = ({ setViewMode }) => {
  return (
    <nav className="bg-gray-800 p-4 flex justify-between">
      <div className="text-white text-2xl">Golf Cart Ride-Share</div>
      <div className="flex space-x-4">
        <button className="text-white" onClick={() => setViewMode('map')}><FaMap /> Map</button>
        <button className="text-white" onClick={() => setViewMode('list')}><FaList /> List</button>
        <button className="text-white" onClick={() => setViewMode('split')}><FaColumns /> Split</button>
        <button className="text-white" onClick={() => setViewMode('businesses')}><FaStore /> Businesses</button>
      </div>
    </nav>
  );
};

export default NavComponent;
