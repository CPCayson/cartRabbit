import React, { useState, useEffect, useMemo } from 'react';
import { GoogleMap, useJsApiLoader, Marker } from '@react-google-maps/api';
import { FaMap, FaList, FaColumns, FaStore, FaSortAmountDown, FaSortAmountUp } from 'react-icons/fa';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';

// Components
import SearchInput from './components/guests/SearchInput';
import CartList from './components/guests/CartList';
import BusinessList from './components/guests/BusinessList'; // New component for businesses
import MapComponent from './components/guests/MapComponent';
import ViewModeButton from './components/ViewModeButton';
import Chat from './components/hosts/Chat';
import PaymentComponent from './components/PaymentComponent';
import { AuthProvider } from './components/Authentication/AuthProvider';
import NavComponent from './Navigation/NavComponent';
import CarrotRating from './CarrotRating';

const stripePromise = loadStripe('your_publishable_key');

const CartView = () => {
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: "YOUR_GOOGLE_MAPS_API_KEY",
    libraries: ['places']
  });

  const [viewMode, setViewMode] = useState('split');
  const [selectedCart, setSelectedCart] = useState(null);
  const [carts, setCarts] = useState([]);
  const [filters, setFilters] = useState({
    electric: false,
    ac: false,
    radio: false,
    storage: false
  });
  const [sortBy, setSortBy] = useState('distance');
  const [sortDirection, setSortDirection] = useState('asc');
  const [userLocation, setUserLocation] = useState(null);
  const [destination, setDestination] = useState(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  useEffect(() => {
    // Fetch carts data
    // Replace with actual API call
    const fakeCarts = [
      {
        id: 1,
        cartName: "Speedy Lightning",
        cartModel: "ElectroCart 2000",
        capacity: 4,
        licensePlate: "EC2001",
        features: { electric: true, ac: true, radio: true, storage: true },
        distance: 2.5,
        time: 6
      },
      // Add more cart data
    ];
    setCarts(fakeCarts);
  }, []);

  const filteredCarts = useMemo(() => {
    return carts.filter(cart => {
      return Object.entries(filters).every(([key, value]) => {
        return !value || cart.features[key];
      });
    });
  }, [carts, filters]);

  const sortedCarts = useMemo(() => {
    return [...filteredCarts].sort((a, b) => {
      if (sortDirection === 'asc') {
        return a[sortBy] - b[sortBy];
      } else {
        return b[sortBy] - a[sortBy];
      }
    });
  }, [filteredCarts, sortBy, sortDirection]);

  const toggleFilter = (filterName) => {
    setFilters(prev => ({ ...prev, [filterName]: !prev[filterName] }));
  };

  const toggleSort = (sortKey) => {
    if (sortBy === sortKey) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(sortKey);
      setSortDirection('asc');
    }
  };

  const handleCartClick = (cart) => {
    setSelectedCart(cart);
    setViewMode('split');
  };

  const handlePayment = () => {
    setShowPaymentModal(true);
  };

  return (
    <AuthProvider>
      <div className="h-screen flex flex-col">
        <NavComponent setViewMode={setViewMode} />
        <header className="bg-gray-800 text-white p-4">
          <h1 className="text-2xl font-bold">Golf Cart Ride-Share</h1>
          <div className="flex justify-between mt-2">
            <div>
              {/* Filter buttons */}
              <button onClick={() => toggleFilter('electric')} className="mr-2">Electric</button>
              <button onClick={() => toggleFilter('ac')} className="mr-2">AC</button>
              <button onClick={() => toggleFilter('radio')} className="mr-2">Radio</button>
              <button onClick={() => toggleFilter('storage')}>Storage</button>
            </div>
            <div>
              {/* Sort buttons */}
              <button onClick={() => toggleSort('distance')} className="mr-2">
                Distance {sortBy === 'distance' && (sortDirection === 'asc' ? <FaSortAmountUp /> : <FaSortAmountDown />)}
              </button>
              <button onClick={() => toggleSort('time')}>
                Time {sortBy === 'time' && (sortDirection === 'asc' ? <FaSortAmountUp /> : <FaSortAmountDown />)}
              </button>
            </div>
          </div>
        </header>

        <div className="flex-grow flex">
          {viewMode !== 'map' && (
            <div className={`${viewMode === 'split' ? 'w-1/2' : 'w-full'} overflow-y-auto`}>
              {selectedCart ? (
                <CartDetails cart={selectedCart} />
              ) : (
                <CartList carts={sortedCarts} onCartClick={handleCartClick} />
              )}
            </div>
          )}
          {viewMode !== 'list' && (
            <div className={`${viewMode === 'split' ? 'w-1/2' : 'w-full'}`}>
              {isLoaded ? (
                <GoogleMap
                  mapContainerStyle={{ width: '100%', height: '100%' }}
                  center={{ lat: 30.3085, lng: -89.3304 }}
                  zoom={14}
                >
                  {sortedCarts.map(cart => (
                    <Marker
                      key={cart.id}
                      position={cart.position}
                      onClick={() => handleCartClick(cart)}
                    />
                  ))}
                </GoogleMap>
              ) : (
                <div>Loading map...</div>
              )}
            </div>
          )}
          {viewMode === 'businesses' && (
            <>
              <div className="w-1/2">
                <MapComponent
                  userLocation={userLocation}
                  destination={destination}
                  carts={sortedCarts}
                  onCartClick={handleCartClick}
                />
              </div>
              <div className="w-1/2 overflow-y-auto">
                <BusinessList />
              </div>
            </>
          )}
        </div>

        {selectedCart && (
          <div className="fixed bottom-0 right-0 w-1/4 h-1/2 bg-white shadow-lg">
            <Chat cartId={selectedCart.id} />
          </div>
        )}

        {showPaymentModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <div className="bg-white p-4 rounded">
              <Elements stripe={stripePromise}>
                <PaymentComponent onClose={() => setShowPaymentModal(false)} />
              </Elements>
            </div>
          </div>
        )}

        <div className="fixed bottom-4 left-4">
          <button onClick={() => setViewMode('map')} className="mr-2">Map</button>
          <button onClick={() => setViewMode('list')} className="mr-2">List</button>
          <button onClick={() => setViewMode('split')}>Split</button>
          <button onClick={() => setViewMode('businesses')}>Businesses</button>
        </div>
      </div>
    </AuthProvider>
  );
};

export default CartView;
