import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App';
import { AuthProvider } from './components/Authentication/AuthProvider';
import Chat from './components/hosts/Chat';
import ErrorBoundary from './components/hosts/ErrorBoundary';

const root = createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <AuthProvider>
      <App />
      <ErrorBoundary>
      </ErrorBoundary>
    </AuthProvider>
  </React.StrictMode>
);



