// PaymentComponent.js
import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

const stripePromise = loadStripe('pk_test_51PKXFdLZTLOaKlNslmwEPt9pWm5uS9ZyOsr5gXeJKCmLal5nT1gofFJm2icRtOJgxEhs5265M6LRpSGPHEHydRna00CVialgWd'); // Replace with your Stripe publishable key

const PaymentComponent = ({ amount, connectedAccountId }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [paymentIntentId, setPaymentIntentId] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);

    const response = await fetch('http://localhost:5000/create-payment-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ amount, currency: 'usd', connectedAccountId }),
    });

    const { error: backendError, clientSecret, id } = await response.json();

    if (backendError) {
      setError(backendError);
      setLoading(false);
      return;
    }

    setPaymentIntentId(id);

    if (!stripe || !elements) {
      setError('Stripe has not been properly initialized.');
      setLoading(false);
      return;
    }

    const cardElement = elements.getElement(CardElement);
    if (!cardElement) {
      setError('Card element is not found.');
      setLoading(false);
      return;
    }

    const { error: stripeError, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: cardElement,
      },
    });

    if (stripeError) {
      setError(stripeError.message);
      setLoading(false);
      return;
    }

    alert(`Payment authorized! PaymentIntent ID: ${paymentIntent.id}`);
    setLoading(false);
  };

  const handleCapture = async () => {
    if (!paymentIntentId) {
      setError('No payment intent to capture.');
      return;
    }

    const response = await fetch('http://localhost:5000/capture-payment-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ paymentIntentId }),
    });

    const { error: captureError, paymentIntent } = await response.json();

    if (captureError) {
      setError(captureError);
      return;
    }

    alert(`Payment captured! PaymentIntent ID: ${paymentIntent.id}`);
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <CardElement />
        <button type="submit" disabled={!stripe || loading}>
          {loading ? 'Processing...' : 'Pay'}
        </button>
        {error && <div>{error}</div>}
      </form>
      {paymentIntentId && (
        <button onClick={handleCapture}>Capture Payment</button>
      )}
    </div>
  );
};

const PaymentPage = ({ amount, connectedAccountId }) => (
  <Elements stripe={stripePromise}>
    <PaymentComponent amount={amount} connectedAccountId={connectedAccountId} />
  </Elements>
);

export default PaymentPage;
// PaymentComponent.js
import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

const stripePromise = loadStripe('pk_test_51PKXFdLZTLOaKlNslmwEPt9pWm5uS9ZyOsr5gXeJKCmLal5nT1gofFJm2icRtOJgxEhs5265M6LRpSGPHEHydRna00CVialgWd'); // Replace with your Stripe publishable key

const PaymentComponent = ({ amount, connectedAccountId }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [paymentIntentId, setPaymentIntentId] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);

    const response = await fetch('http://localhost:5000/create-payment-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ amount, currency: 'usd', connectedAccountId }),
    });

    const { error: backendError, clientSecret, id } = await response.json();

    if (backendError) {
      setError(backendError);
      setLoading(false);
      return;
    }

    setPaymentIntentId(id);

    if (!stripe || !elements) {
      setError('Stripe has not been properly initialized.');
      setLoading(false);
      return;
    }

    const cardElement = elements.getElement(CardElement);
    if (!cardElement) {
      setError('Card element is not found.');
      setLoading(false);
      return;
    }

    const { error: stripeError, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: cardElement,
      },
    });

    if (stripeError) {
      setError(stripeError.message);
      setLoading(false);
      return;
    }

    alert(`Payment authorized! PaymentIntent ID: ${paymentIntent.id}`);
    setLoading(false);
  };

  const handleCapture = async () => {
    if (!paymentIntentId) {
      setError('No payment intent to capture.');
      return;
    }

    const response = await fetch('http://localhost:5000/capture-payment-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ paymentIntentId }),
    });

    const { error: captureError, paymentIntent } = await response.json();

    if (captureError) {
      setError(captureError);
      return;
    }

    alert(`Payment captured! PaymentIntent ID: ${paymentIntent.id}`);
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <CardElement />
        <button type="submit" disabled={!stripe || loading}>
          {loading ? 'Processing...' : 'Pay'}
        </button>
        {error && <div>{error}</div>}
      </form>
      {paymentIntentId && (
        <button onClick={handleCapture}>Capture Payment</button>
      )}
    </div>
  );
};

const PaymentPage = ({ amount, connectedAccountId }) => (
  <Elements stripe={stripePromise}>
    <PaymentComponent amount={amount} connectedAccountId={connectedAccountId} />
  </Elements>
);

export default PaymentPage;

// PaymentComponent.js
import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

const stripePromise = loadStripe('pk_test_51PKXFdLZTLOaKlNslmwEPt9pWm5uS9ZyOsr5gXeJKCmLal5nT1gofFJm2icRtOJgxEhs5265M6LRpSGPHEHydRna00CVialgWd'); // Replace with your Stripe publishable key

const PaymentComponent = ({ amount, connectedAccountId }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [paymentIntentId, setPaymentIntentId] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);

    const response = await fetch('http://localhost:5000/create-payment-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ amount, currency: 'usd', connectedAccountId }),
    });

    const { error: backendError, clientSecret, id } = await response.json();

    if (backendError) {
      setError(backendError);
      setLoading(false);
      return;
    }

    setPaymentIntentId(id);

    if (!stripe || !elements) {
      setError('Stripe has not been properly initialized.');
      setLoading(false);
      return;
    }

    const cardElement = elements.getElement(CardElement);
    if (!cardElement) {
      setError('Card element is not found.');
      setLoading(false);
      return;
    }

    const { error: stripeError, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: cardElement,
      },
    });

    if (stripeError) {
      setError(stripeError.message);
      setLoading(false);
      return;
    }

    alert(`Payment authorized! PaymentIntent ID: ${paymentIntent.id}`);
    setLoading(false);
  };

  const handleCapture = async () => {
    if (!paymentIntentId) {
      setError('No payment intent to capture.');
      return;
    }

    const response = await fetch('http://localhost:5000/capture-payment-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ paymentIntentId }),
    });

    const { error: captureError, paymentIntent } = await response.json();

    if (captureError) {
      setError(captureError);
      return;
    }

    alert(`Payment captured! PaymentIntent ID: ${paymentIntent.id}`);
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <CardElement />
        <button type="submit" disabled={!stripe || loading}>
          {loading ? 'Processing...' : 'Pay'}
        </button>
        {error && <div>{error}</div>}
      </form>
      {paymentIntentId && (
        <button onClick={handleCapture}>Capture Payment</button>
      )}
    </div>
  );
};

const PaymentPage = ({ amount, connectedAccountId }) => (
  <Elements stripe={stripePromise}>
    <PaymentComponent amount={amount} connectedAccountId={connectedAccountId} />
  </Elements>
);

export default PaymentPage;
// PaymentComponent.js
import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

const stripePromise = loadStripe('pk_test_51PKXFdLZTLOaKlNslmwEPt9pWm5uS9ZyOsr5gXeJKCmLal5nT1gofFJm2icRtOJgxEhs5265M6LRpSGPHEHydRna00CVialgWd'); // Replace with your Stripe publishable key

const PaymentComponent = ({ amount, connectedAccountId }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [paymentIntentId, setPaymentIntentId] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);

    const response = await fetch('http://localhost:5000/create-payment-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ amount, currency: 'usd', connectedAccountId }),
    });

    const { error: backendError, clientSecret, id } = await response.json();

    if (backendError) {
      setError(backendError);
      setLoading(false);
      return;
    }

    setPaymentIntentId(id);

    if (!stripe || !elements) {
      setError('Stripe has not been properly initialized.');
      setLoading(false);
      return;
    }

    const cardElement = elements.getElement(CardElement);
    if (!cardElement) {
      setError('Card element is not found.');
      setLoading(false);
      return;
    }

    const { error: stripeError, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: cardElement,
      },
    });

    if (stripeError) {
      setError(stripeError.message);
      setLoading(false);
      return;
    }

    alert(`Payment authorized! PaymentIntent ID: ${paymentIntent.id}`);
    setLoading(false);
  };

  const handleCapture = async () => {
    if (!paymentIntentId) {
      setError('No payment intent to capture.');
      return;
    }

    const response = await fetch('http://localhost:5000/capture-payment-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ paymentIntentId }),
    });

    const { error: captureError, paymentIntent } = await response.json();

    if (captureError) {
      setError(captureError);
      return;
    }

    alert(`Payment captured! PaymentIntent ID: ${paymentIntent.id}`);
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <CardElement />
        <button type="submit" disabled={!stripe || loading}>
          {loading ? 'Processing...' : 'Pay'}
        </button>
        {error && <div>{error}</div>}
      </form>
      {paymentIntentId && (
        <button onClick={handleCapture}>Capture Payment</button>
      )}
    </div>
  );
};

const PaymentPage = ({ amount, connectedAccountId }) => (
  <Elements stripe={stripePromise}>
    <PaymentComponent amount={amount} connectedAccountId={connectedAccountId} />
  </Elements>
);

export default PaymentPage;


require('dotenv').config();
const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const bodyParser = require('body-parser');
const cors = require('cors');
const admin = require('firebase-admin');
const { initializeApp } = require('firebase/app');
const { getAuth } = require('firebase/auth');

const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY,
  authDomain: process.env.FIREBASE_AUTH_DOMAIN,
  databaseURL: process.env.FIREBASE_DATABASE_URL,
  projectId: process.env.FIREBASE_PROJECT_ID,
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.FIREBASE_APP_ID,
  measurementId: process.env.FIREBASE_MEASUREMENT_ID,
};

// Initialize Firebase
initializeApp(firebaseConfig);
const auth = getAuth();

admin.initializeApp({
  credential: admin.credential.cert({
    projectId: process.env.FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
  }),
  databaseURL: process.env.FIREBASE_DATABASE_URL,
});

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

const authenticateUser = async (req, res, next) => {
  const idToken = req.headers.authorization?.split('Bearer ')[1];

  if (!idToken) {
    return res.status(401).send('Unauthorized');
  }

  try {
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    req.user = decodedToken;
    next();
  } catch (error) {
    console.error('Error verifying ID token:', error);
    res.status(401).send('Unauthorized');
  }
};

// Define your Stripe routes here...

// Handle webhook events
const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

app.post('/webhook', bodyParser.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
  } catch (err) {
    res.status(400).send(`Webhook Error: ${err.message}`);
    return;
  }

  switch (event.type) {
    case 'payment_intent.succeeded':
      console.log('PaymentIntent was successful!');
      break;
    case 'payment_intent.canceled':
      console.log('PaymentIntent was canceled!');
      break;
    case 'payment_intent.payment_failed':
      console.log('PaymentIntent failed!');
      break;
    default:
      console.log(`Unhandled event type ${event.type}`);
  }

  res.json({ received: true });
});

app.post('/create-connected-account', authenticateUser, async (req, res) => {
  const { email, businessWebsite } = req.body;
  try {
    const account = await stripe.accounts.create({
      type: 'express',
      business_type: 'individual',
      business_profile: { url: businessWebsite },
      email: email,
      country: 'US',
    });

    const accountLink = await stripe.accountLinks.create({
      account: account.id,
      refresh_url: 'https://your-website.com/reauth',
      return_url: 'https://your-website.com/return',
      type: 'account_onboarding',
    });

    res.send({ url: accountLink.url, accountId: account.id });
  } catch (error) {
    console.error('Error creating express account:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/create-checkout-session', authenticateUser, async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: { name: 'Golf Cart Ride' },
          unit_amount: 1000,
        },
        quantity: 1,
      }],
      mode: 'payment',
      success_url: 'https://your-domain.com/success',
      cancel_url: 'https://your-domain.com/cancel',
      customer_email: req.user.email,
    });

    res.json({ id: session.id });
  } catch (error) {
    console.error('Error creating checkout session:', error);
    res.status(500).json({ error: 'Failed to create checkout session' });
  }
});

app.post('/create-payment-intent', authenticateUser, async (req, res) => {
  const { paymentMethodId, amount } = req.body;
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency: 'usd',
      payment_method: paymentMethodId,
      confirmation_method: 'manual',
      confirm: true,
    });

    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (error) {
    res.status(500).send({ error: error.message });
  }
});

app.post('/capture-payment', authenticateUser, async (req, res) => {
  const { paymentIntentId } = req.body;
  try {
    const paymentIntent = await stripe.paymentIntents.capture(paymentIntentId);
    res.json(paymentIntent);
  } catch (error) {
    console.error('Error capturing payment:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/cancel-payment', authenticateUser, async (req, res) => {
  const { paymentIntentId } = req.body;
  try {
    const canceledPaymentIntent = await stripe.paymentIntents.cancel(paymentIntentId);
    res.json(canceledPaymentIntent);
  } catch (error) {
    console.error('Error canceling payment:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/create-setup-intent', authenticateUser, async (req, res) => {
  const setupIntent = await stripe.setupIntents.create({ customer: req.user.stripeCustomerId });
  res.send({ clientSecret: setupIntent.client_secret });
});

app.post('/create-customer', authenticateUser, async (req, res) => {
  const { email, phone, role } = req.body;
  try {
    const customer = await stripe.customers.create({
      email,
      phone,
      metadata: { role },
    });
    res.send({ customerId: customer.id });
  } catch (error) {
    console.error('Error creating customer:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/create-payout', authenticateUser, async (req, res) => {
  const { amount, currency } = req.body;
  try {
    const payout = await stripe.payouts.create({
      amount,
      currency,
      destination: req.user.stripeAccountId,
    });
    res.json(payout);
  } catch (error) {
    console.error('Error creating payout:', error);
    res.status(500).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
