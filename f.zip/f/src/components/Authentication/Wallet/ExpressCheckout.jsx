import React, { useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe('pk_live_51PKXFdLZTLOaKlNsNVEQo1fsChWHuTEJULjZDi1WUtdXFQhCEMOqs17QWhXIdeEp4KOEdjwRixHtactWCjxu7gSX00Jec3cw4y');

const ExpressCheckout = () => {
  useEffect(() => {
    const initializeStripe = async () => {
      const stripe = await stripePromise;
      const appearance = {
        /* appearance */
      };
      const options = {
        /* options */
      };

      const elements = stripe.elements({
        mode: 'payment',
        amount: 1099,
        currency: 'usd',
        appearance,
      });

      const expressCheckoutElement = elements.create('expressCheckout', options);
      expressCheckoutElement.mount('#express-checkout-element');
    };

    initializeStripe();
  }, []);

  return <div id="express-checkout-element"></div>;
};

export default ExpressCheckout;
