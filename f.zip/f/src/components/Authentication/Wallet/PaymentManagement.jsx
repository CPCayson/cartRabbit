import React, { useState, useEffect } from 'react';
import { auth, db } from '../Firebase/firebase';
import { collection, query, where, getDocs } from "firebase/firestore";
import '../styles/PaymentManagement.css';

const PaymentManagement = () => {
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    const fetchTransactions = async () => {
      const user = auth.currentUser;
      if (user) {
        const transactionsQuery = query(collection(db, 'transactions'), where('userId', '==', user.uid));
        const querySnapshot = await getDocs(transactionsQuery);
        const transactionsList = querySnapshot.docs.map(doc => doc.data());
        setTransactions(transactionsList);
      }
    };

    fetchTransactions();
  }, []);

  return (
    <div className="payment-management">
      <div className="payment-section">
        <h3 className="section-title">Transaction History</h3>
        {transactions.length > 0 ? (
          <ul className="transaction-list">
            {transactions.map((transaction, index) => (
              <li key={index}>
                <div>{transaction.date}</div>
                <div>{transaction.description}</div>
                <div>${transaction.amount / 100}</div>
              </li>
            ))}
          </ul>
        ) : (
          <p>No transactions found.</p>
        )}
      </div>
    </div>
  );
};

export default PaymentManagement;
