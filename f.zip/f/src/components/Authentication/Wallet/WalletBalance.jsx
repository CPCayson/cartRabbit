import React, { useState } from 'react';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';

import TopUpModal from './TopUpModal';

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY);

const WalletBalance = ({ balance, transactions, userId }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleTopUpSuccess = async () => {
    // Update wallet balance in Firebase
    await fetch('/api/update-wallet-balance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, amount: 1000 }), // Example amount: $10.00
    });

    alert('Top-up successful!');
  };

  return (
    <div className="wallet-balance">
      <h2>Wallet Balance</h2>
      <p>${balance}</p>
      <button onClick={() => setIsModalOpen(true)}>Top Up</button>
      <h3>Recent Transactions</h3>
      <ul>
        {transactions.length > 0 ? (
          transactions.map((transaction, index) => (
            <li key={index}>
              {transaction.date}: ${transaction.amount} - {transaction.status}
            </li>
          ))
        ) : (
          <li>No recent transactions</li>
        )}
      </ul>
      <Elements stripe={stripePromise}>
        <TopUpModal
          isOpen={isModalOpen}
          onRequestClose={() => setIsModalOpen(false)}
          onSuccess={handleTopUpSuccess}
        />
      </Elements>
    </div>
  );
};

export default WalletBalance;
