import React, { useState, useEffect } from 'react';
import {loadStripe} from "@stripe/stripe-js";
import {Elements} from "@stripe/react-stripe-js";
import TopUpModal from './TopUpModal';
import '../styles/WalletComponent.css';

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY);

const WalletComponent = ({ balance: initialBalance = 0, transactions: initialTransactions = [], userId }) => {
  const [balance, setBalance] = useState(initialBalance);
  const [transactions, setTransactions] = useState(initialTransactions);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    fetchBalance();
  }, []);

  const fetchBalance = async () => {
    try {
      const response = await fetch('http://localhost:5000/get-balance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await response.json();
      setBalance(data.available[0].amount / 100); // Assuming USD and converting from cents
    } catch (error) {
      console.error('Error fetching balance:', error);
    }
  };

  const handleTopUpSuccess = async () => {
    await fetchBalance();
    alert('Top-up successful!');
  };

  const handlePayout = async () => {
    try {
      const response = await fetch('http://localhost:5000/payout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: 500, destination: 'destination_id' }), // Adjust as needed
      });
      const data = await response.json();
      console.log('Payout successful:', data);
      fetchBalance();
    } catch (error) {
      console.error('Error processing payout:', error);
    }
  };

  return (
    <div className="wallet-container">
      <div className="wallet-card">
        <div className="balance">
          <div className="balance-amount">${balance}</div>
          <div className="balance-card-info">
            <span>**** 0149</span>
            <span>05/25</span>
          </div>
        </div>
        <div className="card-image">
          <img src="path_to_your_image.png" alt="Card" />
        </div>
      </div>

      <div className="wallet-actions">
        <button className="wallet-button" onClick={() => setIsModalOpen(true)}>Top Up</button>
        <button className="wallet-button" onClick={handlePayout}>Payout</button>
        <button className="wallet-button">Send</button>
        <button className="wallet-button">Stripe</button>
      </div>

      <div className="transaction-history">
        <h3>Transaction History</h3>
        <p>A list of historical transactions</p>
        <div className="transaction-filters">
          <button className="filter-button">All</button>
          <button className="filter-button">Income</button>
          <button className="filter-button">Expenses</button>
        </div>
        <div className="transactions">
          {transactions.map((transaction) => (
            <div key={transaction.id} className="transaction">
              <div className="transaction-icon">$</div>
              <div className="transaction-details">
                <div>{transaction.name}</div>
                <div className="transaction-card">{transaction.card}</div>
              </div>
              <div className="transaction-amount">{transaction.amount}</div>
            </div>
          ))}
        </div>
      </div>

      <Elements stripe={stripePromise}>
        <TopUpModal
          isOpen={isModalOpen}
          onRequestClose={() => setIsModalOpen(false)}
          onSuccess={handleTopUpSuccess}
        />
      </Elements>
    </div>
  );
};

export default WalletComponent;
