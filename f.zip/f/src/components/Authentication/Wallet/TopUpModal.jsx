import React, { useState } from 'react';
import Modal from 'react-modal';
import { useStripe, useElements, CardElement } from '@stripe/react-stripe-js';

const TopUpModal = ({ isOpen, onRequestClose, onSuccess }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleTopUp = async (event) => {
    event.preventDefault();

    // Ensure Stripe and elements are loaded
    if (!stripe || !elements) {
      setError('Payment service is currently unavailable.');
      return;
    }

    setLoading(true);
    setError('');

    // Create Payment Method
    const cardElement = elements.getElement(CardElement);
    const { error: stripeError, paymentMethod } = await stripe.createPaymentMethod({
      type: 'card',
      card: cardElement,
    });

    // Handle errors in creating payment method
    if (stripeError) {
      setError(stripeError.message);
      setLoading(false);
      return;
    }

    try {
      // Attempt to create a payment intent on the server
      const response = await fetch('/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paymentMethodId: paymentMethod.id, amount: 1000 }), // Example amount
      });

      if (!response.ok) throw new Error('Network response was not ok.');

      const { clientSecret } = await response.json();

      // Attempt to confirm the card payment
      const result = await stripe.confirmCardPayment(clientSecret);

      if (result.error) {
        setError(result.error.message);
      } else if (result.paymentIntent && result.paymentIntent.status === 'succeeded') {
        onSuccess();
        onRequestClose(); // Close the modal on successful payment
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onRequestClose}
      contentLabel="Top Up Wallet"
      ariaHideApp={false} // Proper handling for screen readers
    >
      <h2>Top Up Wallet</h2>
      <form onSubmit={handleTopUp}>
        <CardElement />
        {error && <div style={{ color: 'red', marginTop: '10px' }}>{error}</div>}
        <button type="submit" disabled={loading || !stripe}>
          {loading ? 'Processing...' : 'Top Up'}
        </button>
      </form>
      <button onClick={onRequestClose}>Close</button>
    </Modal>
  );
};

export default TopUpModal;
