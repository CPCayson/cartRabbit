import React, { useState } from 'react';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import { auth, db } from '../../Firebase/firebase';
import { RecaptchaVerifier, signInWithPhoneNumber } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import axios from 'axios';
import { BeatLoader } from 'react-spinners';

const MySwal = withReactContent(Swal);

const Auth = () => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [userId, setUserId] = useState('');
  const [role, setRole] = useState('guest');
  const [userDetails, setUserDetails] = useState({
    firstName: '',
    middleInitial: '',
    lastName: '',
    birthdate: '',
    phone: '',
  });
  const [loading, setLoading] = useState(false);

  const sendVerificationCode = (phoneNumber) => {
    setLoading(true);
    const recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
      size: 'invisible',
      callback: () => {
        console.log('Recaptcha resolved');
      }
    });

    signInWithPhoneNumber(auth, phoneNumber, recaptchaVerifier)
      .then((confirmationResult) => {
        window.confirmationResult = confirmationResult;
        setLoading(false);
        MySwal.fire({
          title: 'Enter Verification Code',
          html: `
            <input id="verification-code" class="swal2-input" placeholder="Enter verification code">
          `,
          preConfirm: () => {
            return document.getElementById('verification-code').value;
          }
        }).then(result => {
          if (result.isConfirmed) {
            verifyCode(result.value);
          }
        });
      })
      .catch((error) => {
        console.error("SMS not sent", error);
        setLoading(false);
      });
  };

  const verifyCode = (code) => {
    setLoading(true);
    window.confirmationResult.confirm(code)
      .then((result) => {
        setUserId(result.user.uid);
        saveUserData(result.user);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Code verification failed", error);
        setLoading(false);
      });
  };

  const saveUserData = async (user) => {
    setLoading(true);
    try {
      const fullName = `${userDetails.firstName} ${userDetails.middleInitial} ${userDetails.lastName}`.trim();
      const dob = {
        day: userDetails.birthdate.getDate(),
        month: userDetails.birthdate.getMonth() + 1,
        year: userDetails.birthdate.getFullYear(),
      };
      const userData = {
        uid: user.uid,
        phoneNumber: user.phoneNumber,
        name: fullName,
        birthdate: dob,
        role,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        phone: userDetails.phone,
      };
      await setDoc(doc(db, "users", user.uid), userData);

      // Create Stripe connected account if user is a host
      if (role === 'host') {
        await axios.post('http://localhost:5000/create-connected-account', {
          email: user.email,
          name: fullName,
          dob,
          phone: userDetails.phone,
        });
      }

      console.log('User data saved to Firestore');
      setLoading(false);
    } catch (error) {
      console.error('Error saving user data to Firestore', error);
      setLoading(false);
    }
  };

  const handlePhoneNumberChange = (value) => {
    setPhoneNumber(value);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUserDetails(prevDetails => ({ ...prevDetails, [name]: value }));
  };

  const handleDateChange = (date) => {
    setUserDetails(prevDetails => ({ ...prevDetails, birthdate: date }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const { firstName, lastName, birthdate } = userDetails;
    if (phoneNumber && firstName && lastName && birthdate) {
      sendVerificationCode(phoneNumber);
    } else {
      MySwal.fire('Error', 'Please fill out all required fields.', 'error');
    }
  };

  return (
    <div className="auth-container" style={{ textAlign: 'center', padding: '20px' }}>
      <div id="recaptcha-container"></div>
      {loading ? (
        <BeatLoader color="#ff8c00" loading={loading} />
      ) : (
        <div className="auth-form" style={{ margin: '0 auto', maxWidth: '400px', border: '1px solid #ddd', borderRadius: '10px', padding: '20px' }}>
          <div style={{ marginBottom: '20px' }}>
            <img src="assets/cartRabbit_resized.png" alt="cartRABBIT Logo" style={{ maxWidth: '100px' }} />
          </div>
          <h2 className="cartRABBIT" style={{ fontSize: '2em', marginBottom: '20px' }}>
            <span style={{ color: '#5bc0be' }}>cart</span>
            <span style={{ color: '#5bc0be' }}>RABBIT</span>
          </h2>
          <p style={{ marginBottom: '20px' }}>We'll text a code to verify your phone</p>
          <div style={{ marginBottom: '20px' }}>
            <label className="inline-flex items-center">
              <input type="radio" className="form-radio" name="role" value="guest" checked={role === 'guest'} onChange={() => setRole('guest')} />
              <span className="ml-2">Guest</span>
            </label>
            <label className="inline-flex items-center ml-6">
              <input type="radio" className="form-radio" name="role" value="host" checked={role === 'host'} onChange={() => setRole('host')} />
              <span className="ml-2">Host</span>
            </label>
          </div>
          <form onSubmit={handleSubmit} style={{ marginBottom: '20px' }}>
            <PhoneInput
              country={'us'}
              value={phoneNumber}
              onChange={handlePhoneNumberChange}
              inputStyle={{ width: '100%', padding: '10px', fontSize: '1em', borderRadius: '5px', border: '1px solid #ccc', marginBottom: '10px' }}
              containerStyle={{ marginBottom: '10px' }}
            />
            <input
              type="text"
              name="firstName"
              value={userDetails.firstName}
              onChange={handleInputChange}
              placeholder="First Name"
              required
              style={{ width: '100%', padding: '10px', marginBottom: '10px', borderRadius: '5px', border: '1px solid #ccc' }}
            />
            <input
              type="text"
              name="middleInitial"
              value={userDetails.middleInitial}
              onChange={handleInputChange}
              placeholder="Middle Initial (Optional)"
              style={{ width: '100%', padding: '10px', marginBottom: '10px', borderRadius: '5px', border: '1px solid #ccc' }}
            />
            <input
              type="text"
              name="lastName"
              value={userDetails.lastName}
              onChange={handleInputChange}
              placeholder="Last Name"
              required
              style={{ width: '100%', padding: '10px', marginBottom: '10px', borderRadius: '5px', border: '1px solid #ccc' }}
            />
            <DatePicker
              selected={userDetails.birthdate}
              onChange={handleDateChange}
              placeholderText="Select your birthdate"
              className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              required
            />
            <input
              type="text"
              name="phone"
              value={userDetails.phone}
              onChange={handleInputChange}
              placeholder="Phone Number"
              required
              style={{ width: '100%', padding: '10px', marginBottom: '10px', borderRadius: '5px', border: '1px solid #ccc' }}
            />
            <button type="submit" style={{ backgroundColor: '#ff8c00', color: '#fff', padding: '10px 20px', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>
              <span style={{ marginRight: '10px' }}>start hopping</span>
              <span>&#10140;</span>
            </button>
          </form>
          <button onClick={() => {}} style={{ backgroundColor: '#5bc0be', color: '#fff', padding: '10px 20px', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>
            Oauth
          </button>
        </div>
      )}
    </div>
  );
};

export default Auth;
