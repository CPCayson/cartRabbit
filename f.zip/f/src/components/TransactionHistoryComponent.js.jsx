import React, { useEffect, useState } from "react";

const TransactionHistoryComponent = () => {
  const [transactions, setTransactions] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const response = await fetch(
          "http://localhost:5000/api/stripe/payment-history",
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        );
        const data = await response.json();
        setTransactions(data.data);
      } catch (error) {
        setError(error.message);
      }
    };

    fetchTransactions();
  }, []);

  return (
    <div>
      <h2>Transaction History</h2>
      {error && <div>{error}</div>}
      <ul>
        {transactions.map(transaction => (
          <li key={transaction.id}>
            {transaction.amount} {transaction.currency} - {transaction.status}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TransactionHistoryComponent;
