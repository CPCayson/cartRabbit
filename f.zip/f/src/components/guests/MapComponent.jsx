import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { GoogleMap, useJsApiLoader, Marker } from '@react-google-maps/api';
import SearchInput from './SearchInput';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import styled, { keyframes } from 'styled-components';

const stripePromise = loadStripe('your_publishable_key'); // Replace with your actual publishable key

const glowAnimation = keyframes`
  0% { box-shadow: 0 0 5px #ff6b00, 0 0 10px #ff6b00, 0 0 15px #ff6b00, 0 0 20px #ff6b00; }
  50% { box-shadow: 0 0 10px #ff6b00, 0 0 20px #ff6b00, 0 0 30px #ff6b00, 0 0 40px #ff6b00; }
  100% { box-shadow: 0 0 5px #ff6b00, 0 0 10px #ff6b00, 0 0 15px #ff6b00, 0 0 20px #ff6b00; }
`;

const GlowingInput = styled(SearchInput)`
  animation: ${glowAnimation} 2s infinite;
`;

const CheckoutForm = ({ amount, onSuccess }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [errorMessage, setErrorMessage] = useState(null);
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  useEffect(() => {
    const storedEmail = localStorage.getItem('userEmail');
    const storedPhone = localStorage.getItem('userPhone');
    if (storedEmail) setEmail(storedEmail);
    if (storedPhone) setPhone(storedPhone);
  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!stripe || !elements) {
      return;
    }

    try {
      const response = await fetch('/create-payment-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('idToken')}` // Assuming you store the idToken in localStorage
        },
        body: JSON.stringify({
          amount: Math.round(amount * 100), // Convert to cents
          email,
          phone
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create payment intent');
      }

      const { clientSecret } = await response.json();

      const result = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement),
          billing_details: { email, phone }
        }
      });

      if (result.error) {
        setErrorMessage(result.error.message);
      } else if (result.paymentIntent.status === 'succeeded') {
        onSuccess();
      }
    } catch (error) {
      console.error('Error:', error);
      setErrorMessage(error.message);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <input
        type="email"
        value={email}
        onChange={(e) => {
          setEmail(e.target.value);
          localStorage.setItem('userEmail', e.target.value);
        }}
        placeholder="Email"
        className="w-full p-2 border border-gray-300 rounded"
        required
      />
      <input
        type="tel"
        value={phone}
        onChange={(e) => {
          setPhone(e.target.value);
          localStorage.setItem('userPhone', e.target.value);
        }}
        placeholder="Phone"
        className="w-full p-2 border border-gray-300 rounded"
        required
      />
      <div className="p-4 bg-blue-600 rounded">
        <CardElement
          options={{
            style: {
              base: {
                fontSize: '16px',
                color: '#ffffff',
                '::placeholder': {
                  color: '#aab7c4',
                },
              },
              invalid: {
                color: '#9e2146',
              },
            },
          }}
        />
      </div>
      <button type="submit" disabled={!stripe} className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600 transition duration-200">
        Pay ${amount.toFixed(2)}
      </button>
      {errorMessage && <div className="text-red-500">{errorMessage}</div>}
    </form>
  );
};

const MapComponent = ({ initialUserLocation }) => {
  const { isLoaded, loadError } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: "AIzaSyAeU7_Y-1gOTgOoQCq_k6nuWn8KUlOeDvM",
    libraries: ['places']
  });

  const [map, setMap] = useState(null);
  const [userLocation, setUserLocation] = useState(initialUserLocation);
  const [destination, setDestination] = useState(null);
  const [showUserLocationInput, setShowUserLocationInput] = useState(false);
  const [showPaymentPopup, setShowPaymentPopup] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState(0);

  const mapCenter = useMemo(() => userLocation || { lat: 0, lng: 0 }, [userLocation]);

  const onLoad = useCallback((map) => {
    setMap(map);
  }, []);

  const onUnmount = useCallback(() => {
    setMap(null);
  }, []);

  const calculateDistanceAndTime = (start, end) => {
    const R = 6371;
    const dLat = (end.lat - start.lat) * (Math.PI / 180);
    const dLng = (end.lng - start.lng) * (Math.PI / 180);
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(start.lat * (Math.PI / 180)) * Math.cos(end.lat * (Math.PI / 180)) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c;
    const speed = 25;
    const time = distance / speed;
    return { distance, time };
  };

  const normalizeDistance = (distance, minDist = 0, maxDist = 40) => {
    return 1 + ((distance - minDist) / (maxDist - minDist)) * 4;
  };

  const calculateCost = (normalizedValue) => {
    const baseCost = 5;
    return baseCost + (normalizedValue - 1);
  };

  const handleDestinationSelected = (place) => {
    if (!place.geometry) return;

    const location = {
      lat: place.geometry.location.lat(),
      lng: place.geometry.location.lng(),
    };
    setDestination(location);

    if (userLocation) {
      const { distance, time } = calculateDistanceAndTime(userLocation, location);
      const normalizedDistance = normalizeDistance(distance);
      const cost = calculateCost(normalizedDistance);
      console.log(`Distance: ${distance.toFixed(2)} km, Normalized Distance: ${normalizedDistance.toFixed(2)}`);
      setPaymentAmount(cost);
      setShowPaymentPopup(true);
    } else {
      setShowUserLocationInput(true);
    }
  };

  const handleUserLocationSelected = (place) => {
    if (!place.geometry) return;

    const location = {
      lat: place.geometry.location.lat(),
      lng: place.geometry.location.lng(),
    };
    setUserLocation(location);
    setShowUserLocationInput(false);

    if (destination) {
      const { distance, time } = calculateDistanceAndTime(location, destination);
      const normalizedDistance = normalizeDistance(distance);
      const cost = calculateCost(normalizedDistance);
      console.log(`Distance: ${distance.toFixed(2)} km, Normalized Distance: ${normalizedDistance.toFixed(2)}`);
      setPaymentAmount(cost);
      setShowPaymentPopup(true);
    }
  };

  const handlePaymentSuccess = () => {
    alert('Payment successful!');
    setShowPaymentPopup(false);
    // Additional logic after successful payment
  };

  if (loadError) return <div>Error loading maps</div>;
  if (!isLoaded) return <div>Loading map...</div>;

  return (
    <div className="relative w-full h-screen">
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-10 w-full max-w-md px-4">
        <GlowingInput 
          handlePlaceSelected={handleDestinationSelected} 
          placeholder="Enter destination"
          className="shadow-md"
        />
      </div>
      {showUserLocationInput && (
        <div className="absolute top-16 left-1/2 transform -translate-x-1/2 z-10 w-full max-w-md px-4 mt-4">
          <SearchInput 
            handlePlaceSelected={handleUserLocationSelected} 
            placeholder="Enter your location"
            className="shadow-md"
          />
        </div>
      )}
      <GoogleMap
        mapContainerClassName="w-full h-full"
        center={mapCenter}
        zoom={14}
        onLoad={onLoad}
        onUnmount={onUnmount}
      >
        {userLocation && (
          <Marker
            position={userLocation}
            icon="https://maps.google.com/mapfiles/kml/shapes/man.png"
          />
        )}
        {destination && (
          <Marker
            position={destination}
            icon="https://maps.google.com/mapfiles/kml/shapes/flag.png"
          />
        )}
      </GoogleMap>
      {showPaymentPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-8 rounded-lg max-w-md w-full">
            <h2 className="text-2xl mb-4">Complete Your Payment</h2>
            <Elements stripe={stripePromise}>
              <CheckoutForm amount={paymentAmount} onSuccess={handlePaymentSuccess} />
            </Elements>
            <button onClick={() => setShowPaymentPopup(false)} className="mt-4 bg-red-500 text-white px-4 py-2 rounded">Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default MapComponent;