import React, { useEffect, useRef, useState } from 'react';

const placeTypeEmojis = {
  'locality': '🏙️',
  'sublocality': '🏘️',
  'neighborhood': '🏡',
  'route': '🛣️',
  'premise': '🏢',
  'airport': '✈️',
  'park': '🏞️',
  'point_of_interest': '🎯',
  'establishment': '🏛️',
};

const SearchInput = ({
  handlePlaceSelected,
  inputId = 'destination-input-field',
  placeholder = "Enter location",
  className = ""
}) => {
  const inputRef = useRef(null);
  const autocompleteRef = useRef(null);
  const [predictions, setPredictions] = useState([]);

  useEffect(() => {
    if (!window.google) return;

    autocompleteRef.current = new window.google.maps.places.AutocompleteService();

    const autocompleteListener = new window.google.maps.places.Autocomplete(inputRef.current, {
      types: ['geocode']
    });

    autocompleteListener.addListener('place_changed', () => {
      const place = autocompleteListener.getPlace();
      handlePlaceSelected(place);
      setPredictions([]); // Clear predictions when a place is selected
    });

    return () => {
      if (autocompleteListener) {
        window.google.maps.event.clearInstanceListeners(autocompleteListener);
      }
    };
  }, [handlePlaceSelected]);

  const handleInputChange = (e) => {
    const input = e.target.value;
    if (input.length > 0 && autocompleteRef.current) {
      autocompleteRef.current.getPlacePredictions({ input }, (predictions, status) => {
        if (status === window.google.maps.places.PlacesServiceStatus.OK && predictions) {
          const predictionsWithEmojis = predictions.map(prediction => {
            const emoji = placeTypeEmojis[prediction.types[0]] || '📍';
            return { ...prediction, description: `${emoji} ${prediction.description}` };
          });
          setPredictions(predictionsWithEmojis);
        } else {
          setPredictions([]);
        }
      });
    } else {
      setPredictions([]);
    }
  };

  const handlePredictionClick = (prediction) => {
    inputRef.current.value = prediction.description.substring(3); // Remove emoji
    setPredictions([]);
    const placesService = new window.google.maps.places.PlacesService(document.createElement('div'));
    placesService.getDetails({ placeId: prediction.place_id }, (place, status) => {
      if (status === window.google.maps.places.PlacesServiceStatus.OK) {
        handlePlaceSelected(place);
      }
    });
  };

  return (
    <div className="relative">
      <input
        ref={inputRef}
        id={inputId}
        type="text"
        placeholder={placeholder}
        onChange={handleInputChange}
        className={`w-full pl-10 pr-10 py-2 rounded-full border border-gray-300 focus:border-green-500 focus:ring-green-500 focus:outline-none transition duration-300 bg-gray-900 text-green-400 ${className}`}
        style={{ boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)', color: 'rgb(0, 204, 136)' }}
      />
      {predictions.length > 0 && (
        <ul className="absolute z-20 w-full bg-gray-800 border border-gray-300 rounded-md shadow-lg mt-1 max-h-60 overflow-y-auto">
          {predictions.map((prediction) => (
            <li
              key={prediction.place_id}
              onClick={() => handlePredictionClick(prediction)}
              className="px-4 py-2 hover:bg-gray-700 cursor-pointer text-green-400"
            >
              {prediction.description}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SearchInput;
