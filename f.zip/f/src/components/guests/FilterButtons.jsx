import React from 'react';

const FilterButtons = ({ filters, onFilterChange }) => {
  return (
    <div className="flex space-x-4 mb-6">
      {filters.map(filter => (
        <button
          key={filter.value}
          className={`px-4 py-2 rounded-full ${filter.isActive ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'} hover:bg-blue-400 transition-colors duration-200`}
          onClick={() => onFilterChange(filter.value)}
        >
          {filter.label}
        </button>
      ))}
    </div>
  );
};

export default FilterButtons;
