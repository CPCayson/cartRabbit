import React from 'react';
import styled, { keyframes } from 'styled-components';
import SearchInput from './SearchInput';

const glowAnimation = keyframes`
  0% { box-shadow: 0 0 5px #ff6b00, 0 0 10px #ff6b00, 0 0 15px #ff6b00, 0 0 20px #ff6b00; }
  50% { box-shadow: 0 0 10px #ff6b00, 0 0 20px #ff6b00, 0 0 30px #ff6b00, 0 0 40px #ff6b00; }
  100% { box-shadow: 0 0 5px #ff6b00, 0 0 10px #ff6b00, 0 0 15px #ff6b00, 0 0 20px #ff6b00; }
`;

const GlowingInput = styled(SearchInput)`
  animation: ${glowAnimation} 2s infinite;
`;

export default GlowingInput;
