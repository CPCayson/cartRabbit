import React, { useState, useEffect } from 'react';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, doc, onSnapshot } from 'firebase/firestore';
import HostDashboard from './HostDashboard';
import '../styles/AppHost.css';

const AppHost = () => {
  const [host, setHost] = useState(null);
  const [activeRide, setActiveRide] = useState(null);

  useEffect(() => {
    const auth = getAuth();
    onAuthStateChanged(auth, (user) => {
      if (user) {
        const db = getFirestore();
        const hostRef = doc(db, 'users', user.uid);
        onSnapshot(hostRef, (doc) => {
          setHost({ id: doc.id, ...doc.data() });
        });

        const activeRideRef = doc(db, 'activeRides', user.uid);
        onSnapshot(activeRideRef, (doc) => {
          setActiveRide(doc.data());
        });
      } else {
        setHost(null);
      }
    });
  }, []);

  if (!host) return <div>Loading...</div>;

  return (
    <div className="app-host">
      <HostDashboard host={host} activeRide={activeRide} />
    </div>
  );
};

export default AppHost;
