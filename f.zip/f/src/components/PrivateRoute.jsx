import React, { useContext } from 'react';
import { Route, Navigate } from 'react-router-dom';
import { AuthContext } from './Authentication/AuthProvider';

const PrivateRoute = ({ element: Component, ...rest }) => {
  const { currentUser } = useContext(AuthContext);

  return (
    <Route
      {...rest}
      element={currentUser ? <Component /> : <Navigate to="/auth" />}
    />
  );
};

export default PrivateRoute;
