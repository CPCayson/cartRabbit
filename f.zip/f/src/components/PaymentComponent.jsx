import React, { useState } from "react";
import { loadStripe } from "@stripe/stripe-js";
import {
  Elements,
  CardElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY);

const PaymentComponent = ({ amount, connectedAccountId }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [paymentIntentId, setPaymentIntentId] = useState(null);

  const handleSubmit = async event => {
    event.preventDefault();
    setLoading(true);

    const response = await fetch(
      "http://localhost:5000/api/stripe/create-payment-intent",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify({ amount, currency: "usd", connectedAccountId }),
      }
    );

    const { error: backendError, clientSecret, id } = await response.json();

    if (backendError) {
      setError(backendError);
      setLoading(false);
      return;
    }

    setPaymentIntentId(id);

    if (!stripe || !elements) {
      setError("Stripe has not been properly initialized.");
      setLoading(false);
      return;
    }

    const cardElement = elements.getElement(CardElement);
    if (!cardElement) {
      setError("Card element is not found.");
      setLoading(false);
      return;
    }

    const { error: stripeError, paymentIntent } =
      await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: cardElement,
        },
      });

    if (stripeError) {
      setError(stripeError.message);
      setLoading(false);
      return;
    }

    alert(`Payment authorized! PaymentIntent ID: ${paymentIntent.id}`);
    setLoading(false);
  };

  const handleCapture = async () => {
    if (!paymentIntentId) {
      setError("No payment intent to capture.");
      return;
    }

    const response = await fetch(
      "http://localhost:5000/api/stripe/capture-payment",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify({ paymentIntentId }),
      }
    );

    const { error: captureError, paymentIntent } = await response.json();

    if (captureError) {
      setError(captureError);
      return;
    }

    alert(`Payment captured! PaymentIntent ID: ${paymentIntent.id}`);
  };

  const handleRefund = async amount => {
    if (!paymentIntentId) {
      setError("No payment intent to refund.");
      return;
    }

    const response = await fetch(
      "http://localhost:5000/api/stripe/refund-payment",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify({ paymentIntentId, amount }),
      }
    );

    const { error: refundError, refund } = await response.json();

    if (refundError) {
      setError(refundError);
      return;
    }

    alert(`Payment refunded! Refund ID: ${refund.id}`);
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <CardElement />
        <button type="submit" disabled={!stripe || loading}>
          {loading ? "Processing..." : "Pay"}
        </button>
        {error && <div>{error}</div>}
      </form>
      {paymentIntentId && (
        <div>
          <button onClick={handleCapture}>Capture Payment</button>
          <button onClick={() => handleRefund(500)}>Refund $5.00</button>
        </div>
      )}
    </div>
  );
};

const PaymentPage = ({ amount, connectedAccountId }) => (
  <Elements stripe={stripePromise}>
    <PaymentComponent amount={amount} connectedAccountId={connectedAccountId} />
  </Elements>
);

export default PaymentPage;
