import React, { useState, useEffect, useContext } from 'react';
import { getFirestore, doc, onSnapshot } from 'firebase/firestore';
import { AuthContext } from '../Authentication/AuthProvider';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Tab, Tabs, Accordion, AccordionSummary, AccordionDetails, Dialog, DialogTitle, DialogContent, DialogActions, Button } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import CartManagement from './CartManagement';
import RideRequests from './RideRequests';
import ProfileSettings from './ProfileSettings';
import EarningsPayouts from './EarningsPayouts';
import RideHistory from './RideHistory';
import ActiveRide from './ActiveRide';
import CartStats from './CartStats';
import UpcomingRides from './UpcomingRides';
import RideManagement from './RideManagement';
import RideConfirmation from './RideConfirmation';
import RideBooking from './RideBooking';

const HostDashboard = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const { currentUser } = useContext(AuthContext);
  const db = getFirestore();

  const [selectedTab, setSelectedTab] = useState(0);
  const [openDialog, setOpenDialog] = useState(false);
  const [dialogContent, setDialogContent] = useState(null);

  useEffect(() => {
    if (currentUser) {
      const unsubscribeProfile = onSnapshot(doc(db, 'hosts', currentUser.uid), (doc) => {
        if (doc.exists()) {
          setProfile(doc.data());
          setLoading(false);
        } else {
          toast.error('Profile data not found');
          setLoading(false);
        }
      }, (error) => {
        toast.error('Error fetching profile data: ' + error.message);
        setLoading(false);
      });

      return () => unsubscribeProfile();
    }
  }, [currentUser, db]);

  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
  };

  const handleDialogOpen = (content) => {
    setDialogContent(content);
    setOpenDialog(true);
  };

  const handleDialogClose = () => {
    setOpenDialog(false);
    setDialogContent(null);
  };

  if (loading) {
    return <div className="text-center">Loading...</div>;
  }

  if (!currentUser) {
    return <div className="text-center">Please log in to access the host dashboard.</div>;
  }

  return (
    <div className="p-4">
      <ToastContainer />
      <h1 className="text-3xl font-bold mb-4">Host Dashboard</h1>
      <Tabs value={selectedTab} onChange={handleTabChange} aria-label="Host Dashboard Tabs">
        <Tab label="Profile Settings" />
        <Tab label="Cart Management" />
        <Tab label="Ride Requests" />
        <Tab label="Earnings & Payouts" />
        <Tab label="Ride History" />
        <Tab label="Active Ride" />
        <Tab label="Cart Stats" />
        <Tab label="Upcoming Rides" />
        <Tab label="Ride Management" />
        <Tab label="Ride Confirmation" />
        <Tab label="Ride Booking" />
      </Tabs>
      {selectedTab === 0 && <ProfileSettings user={currentUser} profile={profile} />}
      {selectedTab === 1 && <CartManagement user={currentUser} />}
      {selectedTab === 2 && <RideRequests user={currentUser} />}
      {selectedTab === 3 && <EarningsPayouts user={currentUser} />}
      {selectedTab === 4 && <RideHistory user={currentUser} />}
      {selectedTab === 5 && <ActiveRide user={currentUser} />}
      {selectedTab === 6 && <CartStats user={currentUser} />}
      {selectedTab === 7 && <UpcomingRides user={currentUser} />}
      {selectedTab === 8 && <RideManagement user={currentUser} />}
      {selectedTab === 9 && <RideConfirmation user={currentUser} />}
      {selectedTab === 10 && <RideBooking user={currentUser} />}

      <Dialog open={openDialog} onClose={handleDialogClose} aria-labelledby="dialog-title">
        <DialogTitle id="dialog-title">Details</DialogTitle>
        <DialogContent>
          {dialogContent}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDialogClose}>Close</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default HostDashboard;
