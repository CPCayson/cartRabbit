import React, { useState, useEffect, useContext } from 'react';
import { getFirestore, collection, onSnapshot } from 'firebase/firestore';
import { AuthContext } from '../Authentication/AuthProvider';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../styles/EarningsPayouts.css';

const EarningsPayouts = () => {
  const [earnings, setEarnings] = useState([]);
  const { currentUser } = useContext(AuthContext);
  const db = getFirestore();

  useEffect(() => {
    if (currentUser) {
      const earningsRef = collection(db, 'earnings');
      const unsubscribe = onSnapshot(earningsRef, (snapshot) => {
        const earningsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setEarnings(earningsData);
        toast.success('Earnings updated');
      }, (error) => {
        toast.error('Error fetching earnings: ' + error.message);
      });

      return () => unsubscribe();
    }
  }, [currentUser, db]);

  return (
    <div className="earnings-payouts">
      <ToastContainer />
      <h2>Earnings & Payouts</h2>
      <ul>
        {earnings.map(earning => (
          <li key={earning.id}>
            <p><strong>Amount:</strong> ${earning.amount}</p>
            <p><strong>Date:</strong> {new Date(earning.date.seconds * 1000).toLocaleDateString()}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default EarningsPayouts;