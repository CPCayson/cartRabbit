import React, { useState, useEffect } from 'react';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import { getProfileData, saveProfileData } from '../../Firebase/firebase';
import Pica from 'pica';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../styles/UserProfile.css';
import axios from 'axios';

const pica = Pica();
const MySwal = withReactContent(Swal);

const UserProfile = ({ profileType }) => {
  const [user, setUser] = useState({
    name: '',
    birthdate: '',
    email: '',
    bio: '',
    photo: null,
    stripeAccountId: '',
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchProfile = async () => {
      setLoading(true);
      try {
        const profileData = await getProfileData(profileType);
        setUser(profileData);
      } catch (error) {
        toast.error('Error fetching profile data: ' + error.message);
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, [profileType]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUser(prevUser => ({ ...prevUser, [name]: value }));
    validateField(name, value);
  };

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      resizeImage(file);
    }
  };

  const resizeImage = async (file) => {
    const img = document.createElement('img');
    img.src = URL.createObjectURL(file);

    img.onload = async () => {
      const canvas = document.createElement('canvas');
      const MAX_WIDTH = 150;
      const scaleSize = MAX_WIDTH / img.width;
      canvas.width = MAX_WIDTH;
      canvas.height = img.height * scaleSize;

      await pica.resize(img, canvas);

      canvas.toBlob((blob) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setUser(prevUser => ({ ...prevUser, photo: reader.result }));
        };
        reader.readAsDataURL(blob);
      }, file.type);
    };
  };

  const validateField = (name, value) => {
    let error = '';
    if (name === 'email' && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(value)) {
      error = 'Invalid email address';
    }
    if (name === 'birthdate' && !value) {
      error = 'Birthdate cannot be empty';
    }
    setErrors(prevErrors => ({ ...prevErrors, [name]: error }));
  };

  const handleSubmit = async () => {
    if (Object.values(errors).some(error => error)) {
      MySwal.fire('Error', 'Please fix the errors in the form', 'error');
      return;
    }
    setLoading(true);
    try {
      if (!user.stripeAccountId) {
        const response = await axios.post('http://localhost:5000/create-connected-account', { email: user.email });
        user.stripeAccountId = response.data.id;
      }
      await saveProfileData(profileType, user);
      toast.success('Profile updated successfully');
    } catch (error) {
      toast.error('Error updating profile: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const openEditProfilePopup = () => {
    MySwal.fire({
      title: 'Edit Profile',
      html: (
        <div className="profile-form">
          <div className="input-group">
            <label>Your Name</label>
            <input type="text" name="name" value={user.name} onChange={handleInputChange} className="input-text" />
            {errors.name && <span className="error-text">{errors.name}</span>}
          </div>
          <div className="input-group">
            <label>Birthdate</label>
            <input type="text" name="birthdate" value={user.birthdate} onChange={handleInputChange} className="input-text" />
            {errors.birthdate && <span className="error-text">{errors.birthdate}</span>}
          </div>
          <div className="input-group">
            <label>Email</label>
            <input type="email" name="email" value={user.email} onChange={handleInputChange} className="input-text" />
            {errors.email && <span className="error-text">{errors.email}</span>}
          </div>
          <div className="input-group">
            <label>Bio</label>
            <textarea name="bio" value={user.bio} onChange={handleInputChange} className="input-text" />
            {errors.bio && <span className="error-text">{errors.bio}</span>}
          </div>
          <div className="photo-section">
            <img src={user.photo || '../assets/profilepic.png'} alt="Profile" className="profile-photo" />
            <input type="file" accept="image/*" onChange={handlePhotoChange} id="photo-upload" className="hidden" />
            <label htmlFor="photo-upload" className="change-photo-btn">Change Photo</label>
          </div>
        </div>
      ),
      preConfirm: handleSubmit,
      showCancelButton: true,
      confirmButtonText: 'Save Changes',
      footer: '<a href="mailto:support@example.com">Contact Support</a>'
    });
  };

  return (
    <div className="min-h-screen flex justify-center items-center bg-gray-900 text-white">
      <ToastContainer />
      {loading ? (
        <div className="loading-indicator text-center">Loading...</div>
      ) : (
        <div className="profile-card bg-gray-800 p-8 rounded-lg shadow-lg text-center w-96">
          <h2 className="text-4xl font-bold text-green-400 mb-2">Edit Profile</h2>
          <p className="text-lg text-green-300 mb-4">Below are your profile details</p>
          <div className="flex justify-center mb-4">
            <div className="w-24 h-24 rounded-full border-4 border-green-400 p-1 bg-gray-800 relative">
              <img
                src={user.photo || '../assets/profilepic.png'}
                alt="Profile"
                className="w-full h-full rounded-full object-cover"
              />
            </div>
          </div>
          <button
            className="px-4 py-2 bg-red-500 hover:bg-red-600 text-xl rounded-full font-semibold"
            onClick={openEditProfilePopup}
          >
            Change Photo
          </button>
          <div className="date-info text-green-300 mt-4">
            <p>Created On: {new Date().toLocaleDateString()}</p>
            <p>Last Active: Just Now</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserProfile;
