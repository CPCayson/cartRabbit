import React from 'react';

const ViewModeButton = ({ icon, onClick, isActive }) => (
  <button
    onClick={onClick}
    className={`p-2 rounded-full ${isActive ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'} hover:bg-blue-400 transition-colors duration-200`}
  >
    {icon}
  </button>
);

export default ViewModeButton;
