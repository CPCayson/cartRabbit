import React, { useState, useEffect, useRef } from 'react';
import { getFirestore, collection, addDoc, orderBy, query, onSnapshot } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import '../styles/chat.css';

const Chat = ({ userId, hostId }) => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef(null);
  const auth = getAuth();
  const db = getFirestore();

  useEffect(() => {
    const chatId = [userId, hostId].sort().join('_');
    const messagesRef = collection(db, 'chats', chatId, 'messages');
    const q = query(messagesRef, orderBy('timestamp', 'asc'));

    const unsubscribe = onSnapshot(q, snapshot => {
      const fetchedMessages = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setMessages(fetchedMessages);
      setLoading(false);

      const lastMessage = fetchedMessages[fetchedMessages.length - 1];
      if (lastMessage && lastMessage.sender !== auth.currentUser.uid) {
        new Audio('/path/to/notification/sound.mp3').play();
      }
    });

    return () => unsubscribe();
  }, [db, userId, hostId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (event) => {
    event.preventDefault();
    if (!input.trim()) return;

    const chatId = [userId, hostId].sort().join('_');

    try {
      await addDoc(collection(db, 'chats', chatId, 'messages'), {
        text: input.trim(),
        sender: auth.currentUser.uid,
        timestamp: new Date()
      });
      setInput('');
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  if (loading) {
    return <div className="loading-indicator">Loading chat...</div>;
  }

  return (
    <div className="alice-chat bg-white/30 backdrop-blur-lg p-4 rounded-lg shadow-lg">
      <div className="chat-header bg-blue-500 text-white p-2 rounded-t-lg">
        <h2 className="text-lg font-bold">Mad Tea Party Chat</h2>
      </div>
      <div className="chat-messages h-60 overflow-y-auto p-2">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`chat-message ${
              message.sender === auth.currentUser.uid ? 'chat-message-sender' : 'chat-message-receiver'
            } mb-2`}
          >
            <div className="message-bubble bg-white p-2 rounded-lg shadow">
              <p>{message.text}</p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      <form onSubmit={sendMessage} className="chat-input flex">
        <input
          className="flex-grow p-2 rounded-l-lg border border-gray-300"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type a curious message..."
        />
        <button
          type="submit"
          className="bg-blue-500 text-white px-4 py-2 rounded-r-lg"
          disabled={!input.trim()}
        >
          Send
        </button>
      </form>
    </div>
  );
};

export default Chat;
