const firebaseConfig = {
  apiKey: "AIzaSyCKb8thPtB3e-Z0CRuVrqvlUB8WZJEQnAU",
  authDomain: "rabbit-2ba47.firebaseapp.com",
  databaseURL: "https://rabbit-2ba47-default-rtdb.firebaseio.com",
  projectId: "rabbit-2ba47",
  storageBucket: "rabbit-2ba47.appspot.com",
  messagingSenderId: "415352862345",
  appId: "1:415352862345:web:ee2bc4ef914862215cf858",
  measurementId: "G-8G7908G3CL"
};

export default firebaseConfig;
