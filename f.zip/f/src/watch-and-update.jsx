const fs = require('fs-extra');
const replace = require('replace-in-file');
const chokidar = require('chokidar');

// Define your file moves and watch directories
const moves = [
  { from: 'src/AppHost.js', to: 'src/components/Shared/AppHost.js' },
  { from: 'src/coffee.js', to: 'src/components/Shared/coffee.js' },
  { from: 'src/MySwal.js', to: 'src/components/Shared/MySwal.js' },
  { from: 'src/PaymentComponent.js', to: 'src/components/Shared/PaymentComponent.js' },
  { from: 'src/PrivateRoute.js', to: 'src/components/Shared/PrivateRoute.js' },
  { from: 'src/TransactionHistoryComponent.js', to: 'src/components/Shared/TransactionHistoryComponent.js' },
  { from: 'src/ViewModeButton.js', to: 'src/components/Shared/ViewModeButton.js' },
  { from: 'src/CheckoutForm.js', to: 'src/components/guests/CheckoutForm.js' },
  { from: 'src/MapComponent.js', to: 'src/components/guests/MapComponent.js' },
  { from: 'src/SearchInput.js', to: 'src/components/guests/SearchInput.js' },
  { from: 'src/GlowingInput.js', to: 'src/components/guests/GlowingInput.js' },
  { from: 'src/FilterButtons.js', to: 'src/components/guests/FilterButtons.js' },
  { from: 'src/CartList.js', to: 'src/components/guests/CartList.js' },
  { from: 'src/firebaseConfig.js', to: 'src/Firebase/firebaseConfig.js' },
  { from: 'src/NavComponent.js', to: 'src/Navigation/NavComponent.js' },
  { from: 'src/App1 copy 2.js', to: 'src/NeedtoMOve/App1 copy 2.js' },
  { from: 'src/App1 copy.js', to: 'src/NeedtoMOve/App1 copy.js' },
  { from: 'src/BusinessAds.js', to: 'src/NeedtoMOve/BusinessAds.js' },
  { from: 'src/BusinessDirectory.js', to: 'src/NeedtoMOve/BusinessDirectory.js' },
  { from: 'src/CombinedApp.js', to: 'src/NeedtoMOve/CombinedApp.js' },
  { from: 'src/googleMapsLoader.js', to: 'src/NeedtoMOve/googleMapsLoader.js' },
  { from: 'src/LocalBusinessPopups.js', to: 'src/NeedtoMOve/LocalBusinessPopups.js' },
  { from: 'src/NeonQueenGlassEditCart.js', to: 'src/NeedtoMOve/NeonQueenGlassEditCart.js' },
  { from: 'src/StripeCheckout.js', to: 'src/NeedtoMOve/StripeCheckout.js' },
  { from: 'src/ThemeProvider.js', to: 'src/NeedtoMOve/ThemeProvider.js' },
  { from: 'src/UserLocation.js', to: 'src/NeedtoMOve/UserLocation.js' },
  { from: 'src/Support.js', to: 'src/NeedtoMOve/Support/Support.js' },
  { from: 'src/ExpressCheckout.js', to: 'src/NeedtoMOve/Wallet/ExpressCheckout.js' },
  { from: 'src/PaymentManagement.js', to: 'src/NeedtoMOve/Wallet/PaymentManagement.js' },
  { from: 'src/WalletBalance.js', to: 'src/NeedtoMOve/Wallet/WalletBalance.js' },
  { from: 'src/WalletComponent.js', to: 'src/NeedtoMOve/Wallet/WalletComponent.js' },
  { from: 'src/TopUpModal.js', to: 'src/NeedtoMOve/Wallet/TopUpModal.js' },
  { from: 'src/PaymentComponent.js', to: 'src/NeedtoMOve/Wallet/PaymentComponent.js' },
  { from: 'src/BusinessDirectory.js', to: 'src/Onboarding/BusinessDirectory.js' },
  { from: 'src/TermsPage.js', to: 'src/Onboarding/TermsPage.js' },
];

// Function to update imports
const updateImports = async (oldPath, newPath) => {
  const options = {
    files: 'src/**/*.js',
    from: new RegExp(`(${oldPath.replace('.', '\\.')})`, 'g'),
    to: newPath,
  };
  await replace(options);
};

// Function to move files and update imports
const moveFileAndUpdateImports = async (move) => {
  try {
    await fs.move(move.from, move.to);
    await updateImports(move.from, move.to);
    console.log(`Moved ${move.from} to ${move.to} and updated imports.`);
  } catch (error) {
    console.error(`Error moving ${move.from} to ${move.to}:`, error);
  }
};

// Watch for changes and execute moves
const watcher = chokidar.watch('src/**/*.{js,jsx}', {
  persistent: true,
  ignoreInitial: true,
});

watcher.on('add', async (path) => {
  const move = moves.find((move) => move.from === path);
  if (move) {
    await moveFileAndUpdateImports(move);
  }
});

watcher.on('change', async (path) => {
  const move = moves.find((move) => move.from === path);
  if (move) {
    await moveFileAndUpdateImports(move);
  }
});

watcher.on('unlink', async (path) => {
  const move = moves.find((move) => move.from === path);
  if (move) {
    console.log(`File ${path} was removed, please check your moves configuration.`);
  }
});

console.log('Watching for file changes...');
