import React from 'react';
import { FaBolt, FaSnowflake, FaMusic, FaBox } from 'react-icons/fa';

const CartItem = ({ cart, onCartClick }) => (
  <div 
    className="bg-white rounded-lg shadow-md p-4 mb-4 hover:shadow-lg transition-shadow duration-300 cursor-pointer"
    onClick={() => onCartClick(cart)}
  >
    <h3 className="text-xl font-semibold text-gray-800">{cart.cartName}</h3>
    <p className="text-gray-600">{cart.cartModel}</p>
    <div className="flex justify-between items-center mt-2">
      <div className="flex space-x-2">
        {cart.features.electric && <FaBolt className="text-yellow-500" title="Electric" />}
        {cart.features.ac && <FaSnowflake className="text-blue-500" title="Air Conditioning" />}
        {cart.features.radio && <FaMusic className="text-purple-500" title="Radio" />}
        {cart.features.storage && <FaBox className="text-brown-500" title="Storage" />}
      </div>
      <div className="text-right">
        <p className="text-sm text-gray-500">{cart.distance.toFixed(1)} km</p>
        <p className="text-sm text-gray-500">{(cart.time * 60).toFixed(0)} mins</p>
      </div>
    </div>
  </div>
);

const CartList = ({ carts, onCartClick }) => (
  <div className="p-4">
    <h2 className="text-2xl font-bold text-gray-800 mb-4">Available Carts</h2>
    {carts.map(cart => (
      <div 
        key={cart.id}
        className="bg-white rounded-lg shadow-md p-4 mb-4 hover:shadow-lg transition-shadow duration-300 cursor-pointer"
        onClick={() => onCartClick(cart)}
      >
        <h3 className="text-xl font-semibold text-gray-800">{cart.cartName}</h3>
        <p className="text-gray-600">{cart.cartModel}</p>
        <div className="flex justify-between items-center mt-2">
          <div className="flex space-x-2">
            {cart.features.electric && <FaBolt className="text-yellow-500" title="Electric" />}
            {cart.features.ac && <FaSnowflake className="text-blue-500" title="Air Conditioning" />}
            {cart.features.radio && <FaMusic className="text-purple-500" title="Radio" />}
            {cart.features.storage && <FaBox className="text-brown-500" title="Storage" />}
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500">{cart.distance.toFixed(1)} km</p>
            <p className="text-sm text-gray-500">{(cart.time * 60).toFixed(0)} mins</p>
          </div>
        </div>
      </div>
    ))}
  </div>
);

export default CartList;
