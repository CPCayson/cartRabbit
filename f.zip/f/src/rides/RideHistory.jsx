import React, { useState, useEffect, useContext } from 'react';
import { getFirestore, collection, onSnapshot } from 'firebase/firestore';
import { AuthContext } from '../../Authentication/AuthProvider';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const RideHistory = () => {
  const [rides, setRides] = useState([]);
  const { currentUser } = useContext(AuthContext);
  const db = getFirestore();

  useEffect(() => {
    if (currentUser) {
      const ridesRef = collection(db, 'rides', currentUser.uid, 'rideHistory');
      const unsubscribe = onSnapshot(ridesRef, (snapshot) => {
        const ridesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setRides(ridesData);
        toast.success('Ride history updated');
      }, (error) => {
        toast.error('Error fetching ride history: ' + error.message);
      });

      return () => unsubscribe();
    }
  }, [currentUser, db]);

  return (
    <div className="p-6 border border-gray-300 rounded-lg bg-white bg-opacity-30 backdrop-blur-md shadow-md mb-4">
      <ToastContainer />
      <h2 className="text-3xl font-bold mb-4 text-gray-800">Ride History</h2>
      <ul className="list-none p-0">
        {rides.map(ride => (
          <li key={ride.id} className="p-4 border-b last:border-b-0">
            <p><strong>Ride ID:</strong> {ride.id}</p>
            <p><strong>Pickup Location:</strong> {ride.pickupLocation}</p>
            <p><strong>Dropoff Location:</strong> {ride.dropoffLocation}</p>
            <p><strong>Passenger Name:</strong> {ride.passengerName}</p>
            <p><strong>Status:</strong> {ride.status}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RideHistory;
