import React, { useState, useEffect } from 'react';
import { getRideRequests, confirmRide } from '../../../Firebase/firebase'; // Assume these functions are implemented in firebase.js

const RideConfirmation = () => {
  const [rideRequests, setRideRequests] = useState([]);

  useEffect(() => {
    const fetchRideRequests = async () => {
      const requests = await getRideRequests();
      setRideRequests(requests);
    };
    fetchRideRequests();
  }, []);

  const handleConfirm = async (rideId) => {
    await confirmRide(rideId);
    // Update ride requests after confirming a ride
    const updatedRequests = rideRequests.filter(request => request.id !== rideId);
    setRideRequests(updatedRequests);
  };

  return (
    <div className="ride-confirmation">
      <h2>Confirm Ride Requests</h2>
      {rideRequests.map((request) => (
        <div key={request.id} className="ride-request">
          <h3>{request.riderName}</h3>
          <p>{request.locationDetails}</p>
          <button onClick={() => handleConfirm(request.id)}>Confirm Ride</button>
        </div>
      ))}
    </div>
  );
};

export default RideConfirmation;
