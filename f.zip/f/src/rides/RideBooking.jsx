import React from 'react';

const RideBooking = () => {
  return (
    <div className="ride-booking">
      <h2>Ride Booking</h2>
      <p>Ride booking interface goes here.</p>
    </div>
  );
};

export default RideBooking;

