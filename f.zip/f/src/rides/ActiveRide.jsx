import React, { useState, useEffect, useContext } from 'react';
import { getFirestore, doc, onSnapshot, updateDoc } from 'firebase/firestore';
import { AuthContext } from '../components/Authentication/AuthProvider';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const ActiveRide = () => {
  const [activeRide, setActiveRide] = useState(null);
  const [loading, setLoading] = useState(true);
  const { currentUser } = useContext(AuthContext);
  const db = getFirestore();

  useEffect(() => {
    if (currentUser) {
      const rideRef = doc(db, 'activeRides', currentUser.uid);
      const unsubscribe = onSnapshot(rideRef, (doc) => {
        if (doc.exists()) {
          setActiveRide(doc.data());
          toast.success('Active ride data updated');
        } else {
          setActiveRide(null);
          toast.info('No active ride found');
        }
        setLoading(false);
      }, (error) => {
        toast.error('Error fetching active ride: ' + error.message);
        setLoading(false);
      });

      return () => unsubscribe();
    }
  }, [currentUser, db]);

  const handleEndRide = async (rideId) => {
    const rideRef = doc(db, 'activeRides', rideId);

    try {
      await updateDoc(rideRef, { status: 'completed' });
      toast.success('Ride ended successfully');
    } catch (error) {
      toast.error('Error ending ride: ' + error.message);
    }
  };

  if (loading) {
    return <div className="text-center">Loading...</div>;
  }

  if (!activeRide) {
    return <div className="text-center">No active ride</div>;
  }

  return (
    <div className="p-4 border border-gray-300 rounded-lg bg-gray-100 mb-4">
      <ToastContainer />
      <h2 className="text-2xl font-bold mb-4">Active Ride</h2>
      <div className="space-y-4">
        <div>
          <p><strong>Ride ID:</strong> {activeRide.rideId}</p>
          <p><strong>Pickup Location:</strong> {activeRide.pickupLocation}</p>
          <p><strong>Dropoff Location:</strong> {activeRide.dropoffLocation}</p>
          <p><strong>Passenger Name:</strong> {activeRide.passengerName}</p>
          <p><strong>Status:</strong> {activeRide.status}</p>
        </div>
        <div className="text-right">
          <button
            className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-700"
            onClick={() => handleEndRide(activeRide.rideId)}
          >
            End Ride
          </button>
        </div>
      </div>
    </div>
  );
};

export default ActiveRide;
