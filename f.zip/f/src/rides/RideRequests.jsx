import React, { useState, useEffect, useContext } from 'react';
import { getFirestore, collection, query, where, onSnapshot, updateDoc, doc } from 'firebase/firestore';
import { AuthContext } from '../../Authentication/AuthProvider';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const RideRequests = () => {
  const [requests, setRequests] = useState([]);
  const { currentUser } = useContext(AuthContext);
  const db = getFirestore();

  useEffect(() => {
    if (currentUser) {
      const q = query(collection(db, 'rideRequests'), where('status', '==', 'pending'));
      const unsubscribe = onSnapshot(q, (querySnapshot) => {
        const requestsArray = [];
        querySnapshot.forEach((doc) => {
          requestsArray.push({ ...doc.data(), id: doc.id });
        });
        setRequests(requestsArray);
        toast.info('New ride requests updated!');
      });

      return () => unsubscribe();
    }
  }, [currentUser, db]);

  const handleAcceptRequest = async (requestId) => {
    try {
      await updateDoc(doc(db, 'rideRequests', requestId), {
        status: 'accepted',
        driverId: currentUser.uid
      });
      toast.success('Ride request accepted!');
    } catch (error) {
      toast.error('Error accepting ride request!');
      console.error('Error accepting ride request:', error);
    }
  };

  const handleRejectRequest = async (requestId) => {
    try {
      await updateDoc(doc(db, 'rideRequests', requestId), {
        status: 'rejected'
      });
      toast.error('Ride request rejected!');
    } catch (error) {
      toast.error('Error rejecting ride request!');
      console.error('Error rejecting ride request:', error);
    }
  };

  return (
    <div className="p-4 border border-gray-300 rounded-lg bg-gray-100 mb-4">
      <ToastContainer />
      <h2 className="text-2xl font-bold mb-4">Ride Requests</h2>
      {requests.length === 0 ? (
        <p>No ride requests at the moment.</p>
      ) : (
        <ul className="list-none p-0">
          {requests.map((request) => (
            <li key={request.id} className="p-4 border-b last:border-b-0">
              <div className="space-y-2">
                <p><strong>From:</strong> {request.pickupLocation}</p>
                <p><strong>To:</strong> {request.dropoffLocation}</p>
                <p><strong>Time:</strong> {new Date(request.requestTime.seconds * 1000).toLocaleString()}</p>
              </div>
              <div className="flex gap-4 mt-4">
                <button
                  className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-700"
                  onClick={() => handleAcceptRequest(request.id)}
                >
                  Accept
                </button>
                <button
                  className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-700"
                  onClick={() => handleRejectRequest(request.id)}
                >
                  Reject
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default RideRequests;
