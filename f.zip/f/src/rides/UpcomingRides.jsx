import React, { useState, useEffect } from 'react';
import { auth, db } from '../Firebase/firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import 'react-toastify/dist/ReactToastify.css';

const UpcomingRides = () => {
  const [rides, setRides] = useState([]);

  useEffect(() => {
    const fetchRides = async () => {
      const user = auth.currentUser;
      if (user) {
        const ridesQuery = query(collection(db, 'rides'), where('userId', '==', user.uid), where('status', '==', 'upcoming'));
        const querySnapshot = await getDocs(ridesQuery);
        const ridesList = querySnapshot.docs.map(doc => doc.data());
        setRides(ridesList);
      }
    };

    fetchRides();
  }, []);

  return (
    <div className="p-6 border border-gray-300 rounded-lg bg-white bg-opacity-30 backdrop-blur-md shadow-md mb-4">
      <h2 className="text-3xl font-bold mb-4 text-gray-800">Upcoming Rides</h2>
      <ul className="list-none p-0">
        {rides.length > 0 ? (
          rides.map((ride, index) => (
            <li key={index} className="p-4 border-b last:border-b-0">
              <p><strong>Date:</strong> {new Date(ride.date.seconds * 1000).toLocaleString()}</p>
              <p><strong>Destination:</strong> {ride.destination}</p>
              <p><strong>Status:</strong> {ride.status}</p>
            </li>
          ))
        ) : (
          <p>No upcoming rides.</p>
        )}
      </ul>
    </div>
  );
};

export default UpcomingRides;
