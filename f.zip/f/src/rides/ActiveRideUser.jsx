import React, { useState, useEffect, useContext } from 'react';
import { getFirestore, doc, onSnapshot } from 'firebase/firestore';
import { AuthContext } from '../components/Authentication/AuthProvider';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const ActiveRideUser = () => {
  const [activeRide, setActiveRide] = useState(null);
  const [loading, setLoading] = useState(true);
  const [distance, setDistance] = useState(null);
  const [timeAway, setTimeAway] = useState(null);
  const { currentUser } = useContext(AuthContext);
  const db = getFirestore();

  useEffect(() => {
    if (currentUser) {
      console.log("Fetching active ride data for user:", currentUser.uid);
      const rideRef = doc(db, 'activeRides', currentUser.uid);

      const unsubscribe = onSnapshot(rideRef, (doc) => {
        if (doc.exists()) {
          console.log("Active ride data:", doc.data());
          const rideData = doc.data();
          setActiveRide(rideData);
          calculateDistanceAndTime(rideData.driver_location, rideData.user_location);
          toast.success('Active ride data updated');
        } else {
          console.log("No active ride found for user:", currentUser.uid);
          setActiveRide(null);
          toast.info('No active ride found');
        }
        setLoading(false);
      }, (error) => {
        console.error("Error fetching active ride:", error);
        toast.error('Error fetching active ride: ' + error.message);
        setLoading(false);
      });

      return () => unsubscribe();
    }
  }, [currentUser, db]);

  const calculateDistanceAndTime = (driverLocation, userLocation) => {
    const toRadians = (degrees) => degrees * (Math.PI / 180);

    const lat1 = driverLocation.latitude;
    const lon1 = driverLocation.longitude;
    const lat2 = userLocation.latitude;
    const lon2 = userLocation.longitude;

    const R = 3958.8; // Radius of the Earth in miles
    const dLat = toRadians(lat2 - lat1);
    const dLon = toRadians(lon2 - lon1);
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c;

    setDistance(distance);

    const speedMph = 20; // Golf cart speed in mph
    const time = distance / speedMph;
    setTimeAway(time);
  };

  if (loading) {
    return <div className="text-center">Loading...</div>;
  }

  if (!activeRide) {
    return <div className="text-center">No active ride</div>;
  }

  return (
    <div className="p-6 border border-gray-300 rounded-lg bg-white bg-opacity-30 backdrop-blur-md shadow-md mb-4">
      <ToastContainer />
      <h2 className="text-3xl font-bold mb-4 text-gray-800">Active Ride</h2>
      <div className="space-y-4 text-gray-700">
        <div>
          <p><strong>Ride ID:</strong> {activeRide.rideId}</p>
          <p><strong>Driver Name:</strong> {activeRide.driver_name}</p>
          <p><strong>Pickup Location:</strong> {activeRide.pickupLocation}</p>
          <p><strong>Dropoff Location:</strong> {activeRide.dropoffLocation}</p>
          <p><strong>Status:</strong> {activeRide.status}</p>
          {distance && (
            <p><strong>Distance to Pickup:</strong> {distance.toFixed(2)} miles</p>
          )}
          {timeAway && (
            <p><strong>Estimated Time to Pickup:</strong> {Math.round(timeAway * 60)} minutes</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ActiveRideUser;
