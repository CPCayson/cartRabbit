import React, { useState, useEffect, useContext } from 'react';
import { getCurrentRides, getPendingRequests, acceptRide, rejectRide } from '../../../Firebase/firebase';
import { AuthContext } from '../../Authentication/AuthProvider';

const RideManagement = () => {
  const [currentRides, setCurrentRides] = useState([]);
  const [pendingRequests, setPendingRequests] = useState([]);
  const { currentUser } = useContext(AuthContext);

  useEffect(() => {
    const fetchRideData = async () => {
      if (currentUser) {
        const current = await getCurrentRides(currentUser);
        const pending = await getPendingRequests(currentUser);
        setCurrentRides(current);
        setPendingRequests(pending);
      }
    };
    fetchRideData();
  }, [currentUser]);

  const handleAccept = async (requestId) => {
    await acceptRide(requestId);
    setPendingRequests(prev => prev.filter(request => request.id !== requestId));
  };

  const handleReject = async (requestId) => {
    await rejectRide(requestId);
    setPendingRequests(prev => prev.filter(request => request.id !== requestId));
  };

  return (
    <div className="p-4 border border-gray-300 rounded-lg bg-gray-100 mb-4">
      <h2 className="text-2xl font-bold mb-4">Current Rides</h2>
      <div className="space-y-4">
        {currentRides.map(ride => (
          <div key={ride.id} className="p-4 border-b last:border-b-0">
            <p><strong>Rider:</strong> {ride.riderName}</p>
            <p><strong>Destination:</strong> {ride.destination}</p>
            <p><strong>Pickup:</strong> {ride.pickupLocation}</p>
            <p><strong>ETA:</strong> {ride.eta}</p>
          </div>
        ))}
      </div>
      <h2 className="text-2xl font-bold mt-6 mb-4">Pending Requests</h2>
      <div className="space-y-4">
        {pendingRequests.map(request => (
          <div key={request.id} className="p-4 border-b last:border-b-0">
            <p><strong>Rider:</strong> {request.riderName}</p>
            <p><strong>Pickup:</strong> {request.pickupLocation}</p>
            <div className="flex gap-4 mt-4">
              <button
                className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-700"
                onClick={() => handleAccept(request.id)}
              >
                Accept
              </button>
              <button
                className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-700"
                onClick={() => handleReject(request.id)}
              >
                Reject
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RideManagement;
