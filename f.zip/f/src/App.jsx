// src/App.jsx
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import { AuthProvider } from './components/Authentication/AuthProvider';
import { auth } from './Firebase/firebase';
import NavComponent from './components/Navigation/NavComponent';
import CheckoutForm from './components/Wallet/CheckoutForm';
import WalletComponent from './components/Wallet/WalletComponent';
import PaymentPage from './components/Wallet/PaymentComponent';
import CreateAccountComponent from './components/Onboarding/CreateAccountComponent';
import CapturePaymentComponent from './components/Wallet/CapturePaymentComponent';
import UserDashboard from './components/Dashboard/UserDashboard';
import Auth from './components/Authentication/Auth';
import CartView from './CartView'; // Updated import
import HostDashboard from './components/Dashboard/HostDashboard';
import EditCart from './components/Cart/EditCart';
import CartManagement from './components/Cart/CartManagement';
import './App1.css';

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY);

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [isHost, setIsHost] = useState(false);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async user => {
      if (user) {
        setLoggedIn(true);
        setCurrentUser(user);

        const token = await user.getIdTokenResult();
        setIsHost(token.claims.role === 'host');
      } else {
        setLoggedIn(false);
        setCurrentUser(null);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleLogout = () => {
    auth.signOut();
    setLoggedIn(false);
    setCurrentUser(null);
  };

  const toggleRole = () => {
    setIsHost(!isHost);
  };

  return (
    <AuthProvider>
      <Router>
        <div className="app-container">
          <NavComponent 
            loggedIn={loggedIn} 
            currentUser={currentUser} 
            isHost={isHost} 
            onLogout={handleLogout}
            toggleRole={toggleRole}
          />
          <div className="main-content">
            <Routes>
              <Route path="/" element={<Auth />} />
              <Route path="/cart-view" element={<CartView />} />
              <Route path="/dashboard" element={<HostDashboard />} />
              <Route path="/host-dashboard" element={<HostDashboard />} />
              <Route path="/cart-management" element={<CartManagement />} />
              <Route path="/edit-cart/:cartId" element={<EditCart />} />
              <Route 
                path="/payment" 
                element={
                  <PaymentPage 
                    amount={5000} 
                    connectedAccountId="acct_1PZDslPx4MHnStzl" 
                  />
                } 
              />
              <Route path="/create-account" element={<CreateAccountComponent />} />
              <Route path="/capture-payment" element={<CapturePaymentComponent />} />
              <Route 
                path="/checkout" 
                element={
                  <Elements stripe={stripePromise}>
                    <CheckoutForm />
                  </Elements>
                } 
              />
              <Route path="/wallet" element={<WalletComponent />} />
              <Route path="/user-dashboard" element={<UserDashboard />} />
            </Routes>
          </div>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
