// src/components/guests/BusinessList.jsx
import React from 'react';

const BusinessList = () => {
  const businesses = [
    {
      name: "200 North Beach Restaurant",
      type_of_place: "Restaurant",
      address: "200 N Beach Blvd, Bay Saint Louis, MS 39520",
      phone_number: "+1 228-467-9388",
      rating: 4.3,
      hours: "Monday: 11:00 AM – 9:00 PM, Tuesday: 11:00 AM – 9:00 PM, Wednesday: 11:00 AM – 9:00 PM, Thursday: 11:00 AM – 9:00 PM, Friday: 11:00 AM – 10:00 PM, Saturday: 11:00 AM – 10:00 PM, Sunday: 11:00 AM – 9:00 PM",
      description: "Excellent dishes, upscale atmosphere, and attentive staff. Variety of menu options and competitive prices."
    },
    {
      name: "Alice Moseley Folk Art & Antique Museum",
      type_of_place: "Museum",
      address: "1928 Depot Way, Bay Saint Louis, MS 39520",
      phone_number: "+1 228-467-9223",
      rating: 4.8,
      hours: "Monday: 10:00 AM – 4:00 PM, Tuesday: 10:00 AM – 4:00 PM, Wednesday: 10:00 AM – 4:00 PM, Thursday: 10:00 AM – 4:00 PM, Friday: 10:00 AM – 4:00 PM, Saturday: 10:00 AM – 4:00 PM, Sunday: Closed",
      description: "Charming museum dedicated to the folk art of Alice Moseley. Friendly staff and informative exhibits."
    },
    {
      name: "Antique Maison",
      type_of_place: "Antique Store",
      address: "111 N 2nd St, Bay Saint Louis, MS 39520",
      phone_number: "+1 228-466-4848",
      rating: 4.5,
      hours: "Monday: 10:00 AM – 5:00 PM, Tuesday: 10:00 AM – 5:00 PM, Wednesday: 10:00 AM – 5:00 PM, Thursday: 10:00 AM – 5:00 PM, Friday: 10:00 AM – 5:00 PM, Saturday: 10:00 AM – 5:00 PM, Sunday: 11:00 AM – 5:00 PM",
      description: "Charming antique store with a wide variety of items. Friendly staff and a cozy atmosphere."
    },
    {
      name: "Bay Elements",
      type_of_place: "Gift Shop",
      address: "112 S 2nd St, Bay Saint Louis, MS 39520",
      phone_number: "+1 228-466-4970",
      rating: 4.6,
      hours: "Monday: 10:00 AM – 5:00 PM, Tuesday: 10:00 AM – 5:00 PM, Wednesday: 10:00 AM – 5:00 PM, Thursday: 10:00 AM – 5:00 PM, Friday: 10:00 AM – 5:00 PM, Saturday: 10:00 AM – 5:00 PM, Sunday: Closed",
      description: "Unique gift shop with a variety of local and handmade items. Friendly staff and a welcoming atmosphere."
    }
  ];

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Available Businesses</h2>
      {businesses.map(business => (
        <div key={business.name} className="bg-white rounded-lg shadow-md p-4 mb-4">
          <h3 className="text-xl font-semibold text-gray-800">{business.name}</h3>
          <p className="text-gray-600">{business.type_of_place}</p>
          <p className="text-gray-600">{business.address}</p>
          <p className="text-gray-600">{business.phone_number}</p>
          <p className="text-gray-600">{business.rating} / 5</p>
          <p className="text-gray-600">{business.hours}</p>
          <p className="text-gray-600">{business.description}</p>
        </div>
      ))}
    </div>
  );
};

export default BusinessList;
