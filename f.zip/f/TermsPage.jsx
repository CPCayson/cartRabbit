import React from 'react';

const TermsPage = () => {
  return (
    <div>
      <h1>Terms Page</h1>
      <p>This is the Terms page.</p>
    </div>
  );
};

export default TermsPage;
