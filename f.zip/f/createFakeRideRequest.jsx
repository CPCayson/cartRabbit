const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json'); // Path to your service account key

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://rabbit-2ba47-default-rtdb.firebaseio.com"
});

const db = admin.firestore();
const createFakeRideRequest = async () => {
    const fakeRequest = {
      driver_location: "117 Fort Evans Rd NE, Leesburg, VA 20176, USA",
      cart_id: "",
      createdAt: new Date(),
      destination_address: new admin.firestore.GeoPoint(30.38464, 0),
      destination_location: new admin.firestore.GeoPoint(30.3038464, 80.3038464),
      driver_name: "Fake Driver",
      driver_uid: "fakeDriverUid",
      is_driver_assigned: false,
      rideFee: 4,
      status: "pending",
      updatedAt: new Date(),
      user_location: new admin.firestore.GeoPoint(30.3038464, 89.3517824),
      user_name: "Fake User",
      user_uid: "fakeUserUid"
    };
    
    try {
      const docRef = await db.collection('rideRequests').add(fakeRequest);
      console.log('Fake ride request created with ID:', docRef.id);
    } catch (error) {
      console.error('Error adding fake ride request:', error);
    }
  };
  
  createFakeRideRequest();
  