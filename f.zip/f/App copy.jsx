import React, { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { GoogleMap, useJsApiLoader, Marker } from '@react-google-maps/api';
import { FaMap, FaList, FaColumns, FaSortAmountDown, FaSortAmountUp, FaTimes } from 'react-icons/fa';
import Isotope from 'isotope-layout';
import CartDetails from './components/CartDetails'; // You'll need to create this component
// Components
import SearchInput from './components/guests/SearchInput';
import GlowingInput from './components/guests/GlowingInput';
import CartList from './components/guests/CartList';
import MapComponent from './components/guests/MapComponent';
import ViewModeButton from './components/ViewModeButton';
import Chat from './components/hosts/Chat';


const stripePromise = loadStripe('your_publishable_key');

const ViewModeButton = ({ icon, onClick, isActive }) => (
  <button
    onClick={onClick}
    className={`p-2 rounded-md ${isActive ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'} hover:bg-blue-500 hover:text-white transition-colors duration-200`}
  >
    {icon}
  </button>
);

const FilterButton = ({ label, color, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`px-3 py-1 rounded-full ${isActive ? `bg-${color}-500 text-white` : `bg-${color}-200 text-${color}-700`} hover:bg-${color}-400 transition-colors duration-200`}
  >
    {label}
  </button>
);

const App1 = () => {
  const { isLoaded, loadError } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: "AIzaSyAeU7_Y-1gOTgOoQCq_k6nuWn8KUlOeDvM",
    libraries: ['places']
  });

  const [map, setMap] = useState(null);
  const [userLocation, setUserLocation] = useState(null);
  const [destination, setDestination] = useState(null);
  const [showUserLocationInput, setShowUserLocationInput] = useState(false);
  const [viewMode, setViewMode] = useState('split');
  const [carts, setCarts] = useState([]);
  const [filters, setFilters] = useState({
    electric: false,
    ac: false,
    radio: false,
    storage: false
  });
  const [sortBy, setSortBy] = useState('distance');
  const [sortDirection, setSortDirection] = useState('asc');
  const [selectedCart, setSelectedCart] = useState(null);
  const [showChat, setShowChat] = useState(false);
  const isotope = useRef(null);
  const cartListRef = useRef(null);

  const mapCenter = useMemo(() => userLocation || { lat: 0, lng: 0 }, [userLocation]);

  useEffect(() => {
    // Fake cart data
    const fakeCarts = [
      {
        id: 1,
        cartName: "Speedy",
        cartModel: "ElectroCart 2000",
        capacity: 4,
        licensePlate: "EC2000",
        description: "Fast and eco-friendly",
        features: { electric: true, ac: true, radio: true, storage: false },
        distance: 2.5,
        time: 0.1,
        position: { lat: 30.3085, lng: -89.3304 }
      },
      {
        id: 2,
        cartName: "Comfort Cruiser",
        cartModel: "LuxCart",
        capacity: 6,
        licensePlate: "LC6000",
        description: "Luxury ride for groups",
        features: { electric: false, ac: true, radio: true, storage: true },
        distance: 3.7,
        time: 0.15,
        position: { lat: 30.3095, lng: -89.3314 }
      },
      {
        id: 3,
        cartName: "Eco Rider",
        cartModel: "GreenGo",
        capacity: 2,
        licensePlate: "GG1234",
        description: "Compact and environmentally friendly",
        features: { electric: true, ac: false, radio: false, storage: true },
        distance: 1.8,
        time: 0.07,
        position: { lat: 30.3075, lng: -89.3294 }
      }
    ];
    setCarts(fakeCarts);
  }, []);

  useEffect(() => {
    if (cartListRef.current) {
      isotope.current = new Isotope(cartListRef.current, {
        itemSelector: '.cart-item',
        layoutMode: 'vertical',
        getSortData: {
          distance: '.distance parseFloat',
          time: '.time parseFloat'
        }
      });
    }
  }, [carts]);

  useEffect(() => {
    if (isotope.current) {
      isotope.current.arrange({ sortBy: sortBy, sortAscending: sortDirection === 'asc' });
    }
  }, [sortBy, sortDirection]);

  const filteredCarts = useMemo(() => {
    return carts.filter(cart => {
      return Object.entries(filters).every(([key, value]) => {
        return !value || cart.features[key];
      });
    });
  }, [carts, filters]);

  const onLoad = useCallback((map) => {
    setMap(map);
  }, []);

  const onUnmount = useCallback(() => {
    setMap(null);
  }, []);

  const toggleFilter = (filterName) => {
    setFilters(prev => ({ ...prev, [filterName]: !prev[filterName] }));
  };

  const toggleSort = (sortKey) => {
    if (sortBy === sortKey) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(sortKey);
      setSortDirection('asc');
    }
  };

  const handleCartClick = (cart) => {
    setSelectedCart(cart);
    setShowChat(true);
    setViewMode('split');
  };

  const closeExpandedView = () => {
    setSelectedCart(null);
    setShowChat(false);
  };

  if (loadError) return <div>Error loading maps</div>;
  if (!isLoaded) return <div>Loading map...</div>;

  return (
    <div className="h-screen flex flex-col">
      <header className="bg-gray-800 text-white p-4 flex flex-col space-y-2">
        {/* Header content (same as before) */}
      </header>

      <div className="flex-grow flex overflow-hidden relative">
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-30 w-full max-w-md px-4">
          <GlowingInput 
            handlePlaceSelected={(place) => {
              // Handle destination selection
              console.log("Destination selected:", place);
            }} 
            placeholder="Enter destination"
            className="shadow-md"
          />
        </div>

        {showUserLocationInput && (
          <div className="absolute top-20 left-1/2 transform -translate-x-1/2 z-30 w-full max-w-md px-4">
            <SearchInput 
              handlePlaceSelected={(place) => {
                // Handle user location selection
                console.log("User location selected:", place);
              }} 
              placeholder="Enter your location"
              className="shadow-md"
            />
          </div>
        )}

        <div className="flex-grow flex overflow-hidden">
          {selectedCart ? (
            <>
              <div className="w-1/2 overflow-y-auto p-4">
                <button onClick={closeExpandedView} className="mb-4">
                  <FaTimes /> Close
                </button>
                <CartDetails cart={selectedCart} />
              </div>
              <div className="w-1/2 overflow-y-auto">
                <Chat cartId={selectedCart.id} />
              </div>
            </>
          ) : (
            <>
              {(viewMode === 'list' || viewMode === 'split') && (
                <div className={`${viewMode === 'split' ? 'w-1/2' : 'w-full'} overflow-y-auto`}>
                  <CartList carts={filteredCarts} ref={cartListRef} onCartClick={handleCartClick} />
                </div>
              )}
              {(viewMode === 'map' || viewMode === 'split') && (
                <div className={`${viewMode === 'split' ? 'w-1/2' : 'w-full'}`}>
                  <GoogleMap
                    mapContainerClassName="w-full h-full"
                    center={mapCenter}
                    zoom={14}
                    onLoad={onLoad}
                    onUnmount={onUnmount}
                  >
                    {userLocation && (
                      <Marker
                        position={userLocation}
                        icon="https://maps.google.com/mapfiles/kml/shapes/man.png"
                      />
                    )}
                    {destination && (
                      <Marker
                        position={destination}
                        icon="https://maps.google.com/mapfiles/kml/shapes/flag.png"
                      />
                    )}
                    {filteredCarts.map(cart => (
                      <Marker
                        key={cart.id}
                        position={cart.position}
                        onClick={() => handleCartClick(cart)}
                      />
                    ))}
                  </GoogleMap>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default App1;